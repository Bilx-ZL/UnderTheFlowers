import {
  Button,
  ForEach,
  Group,
  HStack,
  Image,
  List,
  Menu,
  NavigationDestination,
  NavigationStack,
  Section,
  Spacer,
  Text,
  VStack,
  useEffect,
  useObservable,
  useState,
} from "scripting"
import { Mount, FileEntry } from "../types"
import { baseName, displayPath, loadMounts, newId, resolveMountPath, saveMounts } from "../services/mounts"
import { ExitBehavior } from "../services/settings"
import { CloseButton } from "../components/CloseButton"
import { DetailsSheet } from "../components/DetailsSheet"
import { SettingsMenu } from "../components/SettingsMenu"
import { TransferStatusButton } from "../components/TransferStatusButton"
import { debugLog } from "../services/debug"
import { subscribeTabBarHidden } from "../services/uiState"
import { BrowserPage } from "./BrowserPage"
import { decodeRoute, encodeRoute } from "../services/routes"
import { createLocalSource } from "../services/source"

function normalizePath(path: string): string {
  return path.replace(/\/+$/, "")
}

type BookmarkInfo = { name: string; path: string }

export function MountsPage({
  onClose,
}: {
  onClose: (behavior: ExitBehavior) => void
}) {
  const [mounts, setMounts] = useState<Mount[] | undefined>(undefined)
  const [tabBarHidden, setTabBarHidden] = useState(false)
  const navPath = useObservable<string[]>([])
  const [detailEntry, setDetailEntry] = useState<FileEntry | null>(null)
  const [sorting, setSorting] = useState(false)
  // 排序时就地把列表切成可拖动的 ForEach，进/出排序只翻 editMode
  const editMode = useObservable(EditMode.inactive())
  const orderObs = useObservable<Mount[]>([])

  async function updateMounts(next: Mount[]) {
    await withAnimation(Animation.default(), () => setMounts(next))
  }

  useEffect(() => {
    return subscribeTabBarHidden(setTabBarHidden)
  }, [])

  useEffect(() => {
    loadMounts().then(list => {
      debugLog("mount", `loaded ${list.length}`)
      setMounts(list)
    })
  }, [])

  async function addMount() {
    try {
      const picked = await DocumentPicker.pickDirectoryBookmark()
      if (!picked) {
        debugLog("mount", "add cancelled")
        return
      }

      const fullPath = normalizePath(picked.path)
      const alreadyMounted = (mounts ?? []).find(
        item =>
          item.bookmarkName === picked.bookmarkName ||
          (item.lastPath != null && normalizePath(item.lastPath) === fullPath)
      )
      if (alreadyMounted) {
        await Dialog.alert({
          title: "已经挂载",
          message: `「${alreadyMounted.name}」已经挂载过了。`,
        })
        return
      }

      const mount: Mount = {
        id: newId(),
        kind: "local",
        name: baseName(picked.path),
        bookmarkName: picked.bookmarkName,
        lastPath: picked.path,
        createdAt: Date.now(),
      }
      const next = [...(mounts ?? []), mount]
      await saveMounts(next)
      await updateMounts(next)
      debugLog("mount", `added ${mount.name} (bookmark=${picked.bookmarkName})`)
    } catch (error) {
      debugLog("mount", `add failed: ${String(error)}`)
      await Dialog.alert({ title: "添加失败", message: String(error) })
    }
  }

  function availableBookmarks(): BookmarkInfo[] {
    if (!mounts) return []
    try {
      const usedNames = new Set(
        mounts.map(item => item.bookmarkName).filter((name): name is string => !!name)
      )
      const usedPaths = new Set(
        mounts
          .map(item => item.lastPath)
          .filter((path): path is string => !!path)
          .map(normalizePath)
      )
      return FileManager.getAllFileBookmarks().filter(item => {
        if (usedNames.has(item.name)) return false
        if (usedPaths.has(normalizePath(item.path))) return false
        return typeof FileManager.bookmarkedPath(item.name) === "string"
      })
    } catch (error) {
      debugLog("mount", `bookmark list failed: ${String(error)}`)
      return []
    }
  }

  async function addExisting(bookmark: BookmarkInfo) {
    try {
      const path = FileManager.bookmarkedPath(bookmark.name)
      if (typeof path !== "string" || path.length === 0) {
        await Dialog.alert({
          title: "书签不可用",
          message: "这个书签当前无法访问，请在 App 设置里重新授权。",
        })
        return
      }

      const already = (mounts ?? []).find(
        item =>
          item.bookmarkName === bookmark.name ||
          (item.lastPath != null && normalizePath(item.lastPath) === normalizePath(path))
      )
      if (already) {
        await Dialog.alert({
          title: "已经挂载",
          message: `「${already.name}」已经挂载过了。`,
        })
        return
      }

      const mount: Mount = {
        id: newId(),
        kind: "local",
        name: baseName(path) || bookmark.name,
        bookmarkName: bookmark.name,
        lastPath: path,
        createdAt: Date.now(),
      }
      const next = [...(mounts ?? []), mount]
      await saveMounts(next)
      await updateMounts(next)
      debugLog("mount", `added existing ${bookmark.name}`)
    } catch (error) {
      debugLog("mount", `add existing failed: ${String(error)}`)
      await Dialog.alert({ title: "添加失败", message: String(error) })
    }
  }

  async function chooseExisting() {
    const list = availableBookmarks()
    if (list.length === 0) {
      await Dialog.alert({
        title: "没有可用的书签",
        message: "App 里没有可用的文件书签，或者它们都已经挂载了。",
      })
      return
    }

    const index = await Dialog.actionSheet({
      title: "添加已有的挂载",
      message: "选择App中已经挂载的目录",
      actions: list.map(item => ({ label: item.name })),
    })
    if (index == null) return
    await addExisting(list[index])
  }

  async function renameMount(mount: Mount) {
    const value = await Dialog.prompt({
      title: "重命名挂载目录标签",
      message: "只修改显示标签，不会改动书签或目录名。",
      defaultValue: mount.name,
      placeholder: "目录标签",
      selectAll: true,
      confirmLabel: "保存",
      cancelLabel: "取消",
    })
    if (value == null) return

    const name = value.trim()
    if (!name) {
      await Dialog.alert({ title: "名称不能为空", message: "请输入一个标签名称。" })
      return
    }
    if (name === mount.name) return

    const next = (mounts ?? []).map(item =>
      item.id === mount.id ? { ...item, name } : item
    )
    await saveMounts(next)
    await updateMounts(next)
    debugLog("mount", `renamed ${mount.id} -> ${name}`)
  }

  async function removeMount(mount: Mount) {
    const confirmed = await Dialog.confirm({
      title: "移除挂载",
      message: `确定移除「${mount.name}」吗？不会删除其中的文件。\n\n脚本不能移除App的挂载，请以后在Scripting App设置里移除。`,
      confirmLabel: "移除",
      cancelLabel: "取消",
    })

    if (!confirmed) {
      debugLog("mount", `remove cancelled: ${mount.id}`)
      return
    }

    debugLog("mount", `remove confirmed: ${mount.id}`)

    // removeFileBookmark 在部分运行时版本中不存在，做能力检测
    try {
      const fm = FileManager as any
      if (mount.bookmarkName && typeof fm.removeFileBookmark === "function") {
        fm.removeFileBookmark(mount.bookmarkName)
      }
    } catch (error) {
      debugLog("mount", `remove bookmark failed: ${String(error)}`)
    }

    const next = (mounts ?? []).filter(item => item.id !== mount.id)
    try {
      await saveMounts(next)
    } catch (error) {
      debugLog("mount", `save failed: ${String(error)}`)
      await Dialog.alert({ title: "移除失败", message: String(error) })
      return
    }
    debugLog("mount", `removed ${mount.id}, left ${next.length}`)
    await updateMounts(next)
  }

  function showMountDetails(mount: Mount) {
    const root = resolveMountPath(mount)
    if (!root) {
      Dialog.alert({
        title: "挂载不可用",
        message: "目录可能已被移动、删除，或文件书签已失效。",
      })
      return
    }
    setDetailEntry({
      name: mount.name,
      path: root,
      isDirectory: true,
      size: 0,
      modifiedAt: 0,
    })
  }

  function startSorting() {
    orderObs.setValue([...(mounts ?? [])])
    editMode.setValue(EditMode.active())
    setSorting(true)
  }

  async function finishSorting() {
    const ids = orderObs.value.map(item => item.id)
    const list = mounts ?? []
    const next = ids
      .map(id => list.find(item => item.id === id))
      .filter((item): item is Mount => item != null)
    editMode.setValue(EditMode.inactive())
    setSorting(false)
    await saveMounts(next)
    setMounts(next)
    debugLog("mount", `reordered -> ${next.map(item => item.name).join(" | ")}`)
  }

  function mountRow(mount: Mount) {
    return (
      <HStack spacing={12} frame={{ maxWidth: "infinity" }} contentShape="rect">
        <Image systemName="folder.fill" font="title3" foregroundStyle="systemBlue" />
        <VStack alignment="leading" spacing={2}>
          <Text lineLimit={1}>{mount.name}</Text>
          <Text
            font="caption"
            foregroundStyle="secondaryLabel"
            lineLimit={1}
            truncationMode="head"
          >
            {displayPath(mount)}
          </Text>
        </VStack>
        <Spacer />
      </HStack>
    )
  }

  return (
    <NavigationStack
      path={navPath}
      tabBarVisibility={tabBarHidden ? "hidden" : "visible"}
    >
      <List
        navigationTitle="文件"
        navigationBarTitleDisplayMode="inline"
        listStyle="insetGroup"
        environments={{ editMode }}
        sheet={{
          isPresented: detailEntry != null,
          onChanged: open => {
            if (!open) setDetailEntry(null)
          },
          content: detailEntry ? (
            <DetailsSheet
              entry={detailEntry}
              onClose={() => setDetailEntry(null)}
            />
          ) : (
            <Text> </Text>
          ),
        }}
        navigationDestination={
          <NavigationDestination>
            {value => {
              const route = decodeRoute(value)
              const target =
                route == null
                  ? undefined
                  : (mounts ?? []).find(item => item.id === route.mountId)
              if (!target) {
                return (
                  <VStack spacing={10} padding={24} frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
                    <Text font="headline">挂载不可用</Text>
                    <Text font="footnote" foregroundStyle="secondaryLabel">
                      目录可能已被移除。
                    </Text>
                  </VStack>
                )
              }
              return (
                <BrowserPage
                  source={createLocalSource(target)}
                  path={route?.path}
                  navPath={navPath}
                  onClose={onClose}
                />
              )
            }}
          </NavigationDestination>
        }
        toolbar={{
          topBarLeading: [
            <CloseButton onClose={onClose} />,
            ...(sorting
              ? []
              : [
                  <Menu label={<Image systemName="plus" />}>
                    <Button
                      title="挂载新目录"
                      systemImage="folder.badge.plus"
                      action={addMount}
                    />
                    <Button
                      title="添加已有的挂载"
                      systemImage="bookmark"
                      action={chooseExisting}
                    />
                  </Menu>,
                ]),
          ],
          topBarTrailing: sorting ? (
            <Button title="完成" action={finishSorting} />
          ) : (
            <HStack spacing={8}>
              <TransferStatusButton />
              <SettingsMenu onSort={startSorting} />
            </HStack>
          ),
        }}
      >
        {mounts === undefined ? null : (
          <Section header={<Text>挂载目录</Text>}>
            {mounts.length === 0 ? (
              <VStack spacing={10} padding={{ vertical: 28 }} frame={{ maxWidth: "infinity" }}>
                <Image
                  systemName="folder.badge.plus"
                  font="largeTitle"
                  foregroundStyle="secondaryLabel"
                />
                <Text font="headline">还没有挂载文件夹</Text>
                <Text font="footnote" foregroundStyle="secondaryLabel">
                  点左上角的加号，挂载一个目录。
                </Text>
              </VStack>
            ) : sorting ? (
              <ForEach
                data={orderObs}
                editActions="move"
                builder={mount => mountRow(mount)}
              />
            ) : (
              mounts.map(mount => (
              <Button
                key={mount.id}
                buttonStyle="plain"
                contentShape="rect"
                action={() => navPath.setValue([encodeRoute(mount.id)])}
                contextMenu={{
                  menuItems: (
                    <Group>
                      <Button
                        title="重命名"
                        systemImage="pencil"
                        action={() => renameMount(mount)}
                      />
                      <Button
                        title="详情"
                        systemImage="info.circle"
                        action={() => showMountDetails(mount)}
                      />
                      <Button
                        title="移除挂载"
                        systemImage="trash"
                        tint="red"
                        action={() => removeMount(mount)}
                      />
                    </Group>
                  ),
                }}
                frame={{ maxWidth: "infinity" }}
              >
                {mountRow(mount)}
              </Button>
              ))
            )}
          </Section>
        )}
      </List>
    </NavigationStack>
  )
}
