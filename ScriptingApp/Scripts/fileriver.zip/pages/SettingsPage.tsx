import {
  Button,
  LabeledContent,
  List,
  NavigationLink,
  NavigationStack,
  Picker,
  Script,
  Section,
  Text,
  Toggle,
  useEffect,
  useState,
} from "scripting"
import { CloseButton } from "../components/CloseButton"
import {
  ExitBehavior,
  FTP_PREVIEW_CACHE_LIMIT_OPTIONS,
  FtpPreviewCacheLimit,
  THUMBNAIL_CACHE_LIMIT_OPTIONS,
  ThumbnailCacheLimit,
  getExitBehavior,
  getFtpPreviewCacheLimit,
  getKeepAwakeDuringTasks,
  getRecursiveFtpFolderStats,
  getThumbnailCacheLimit,
  setExitBehavior,
  setFtpPreviewCacheLimit,
  setKeepAwakeDuringTasks,
  setRecursiveFtpFolderStats,
  setThumbnailCacheLimit,
} from "../services/settings"
import {
  clearThumbnailCache,
  clearThumbnailMemoryCache,
  enforceCacheLimit,
  getThumbnailCacheSize,
} from "../services/thumbnails"
import {
  clearFtpPreviewCache,
  enforceFtpPreviewCacheLimit,
  getFtpPreviewCacheSize,
} from "../services/ftp"
import { formatSize } from "../services/localfs"
import { clearDebugLog, debugLog, isDebugEnabled, setDebugLogEnabled } from "../services/debug"
import { DebugLogPage } from "./DebugLogPage"
import { AboutPage } from "./AboutPage"
import { refreshWakeLock } from "../services/wakeLock"

export function SettingsPage({
  onClose,
  active,
}: {
  onClose: (behavior: ExitBehavior) => void
  /** 当前是否在设置 Tab（每次切过来时刷新缓存大小） */
  active: boolean
}) {
  const [behavior, setBehavior] = useState<ExitBehavior>(getExitBehavior())
  const [debugEnabled, setDebugEnabled] = useState(isDebugEnabled())
  const [keepAwakeDuringTasks, setKeepAwake] = useState(getKeepAwakeDuringTasks())
  const [cacheLimit, setCacheLimit] = useState<ThumbnailCacheLimit>(getThumbnailCacheLimit())
  const [ftpCacheLimit, setFtpCacheLimit] = useState<FtpPreviewCacheLimit>(
    getFtpPreviewCacheLimit()
  )
  const [recursiveFtpStats, setRecursiveFtpStats] = useState(getRecursiveFtpFolderStats())
  const [cacheSize, setCacheSize] = useState<number | null>(null)
  const [ftpCacheSize, setFtpCacheSize] = useState<number | null>(null)
  const [clearing, setClearing] = useState(false)
  const [ftpClearing, setFtpClearing] = useState(false)

  async function refreshCacheSizes() {
    try {
      setCacheSize(await getThumbnailCacheSize())
    } catch {
      setCacheSize(null)
    }
    try {
      setFtpCacheSize(await getFtpPreviewCacheSize())
    } catch {
      setFtpCacheSize(null)
    }
  }

  useEffect(() => {
    if (active) refreshCacheSizes()
  }, [active])

  function changeBehavior(value: string) {
    const next: ExitBehavior = value === "minimize" ? "minimize" : "exit"
    setBehavior(next)
    setExitBehavior(next)
    debugLog("settings", `exit behavior -> ${next}`)
  }

  async function changeDebug(value: boolean) {
    setDebugEnabled(value)
    await setDebugLogEnabled(value)
    debugLog("settings", `debug log ${value ? "enabled" : "disabled"}`)
  }

  function changeKeepAwake(value: boolean) {
    setKeepAwake(value)
    setKeepAwakeDuringTasks(value)
    refreshWakeLock()
    debugLog("settings", `keep awake during tasks -> ${value}`)
  }

  function changeRecursiveFtpStats(value: boolean) {
    setRecursiveFtpStats(value)
    setRecursiveFtpFolderStats(value)
    debugLog("settings", `recursive FTP folder stats -> ${value}`)
  }

  async function changeCacheLimit(value: string) {
    const next = value as ThumbnailCacheLimit
    setCacheLimit(next)
    await setThumbnailCacheLimit(next)
    if (next === "off") clearThumbnailMemoryCache()
    debugLog("settings", `thumbnail cache limit -> ${next}`)
    await enforceCacheLimit()
    await refreshCacheSizes()
  }

  async function changeFtpCacheLimit(value: string) {
    const next = value as FtpPreviewCacheLimit
    setFtpCacheLimit(next)
    await setFtpPreviewCacheLimit(next)
    debugLog("settings", `FTP preview cache limit -> ${next}`)
    if (next === "immediate") {
      await clearFtpPreviewCache()
    } else {
      await enforceFtpPreviewCacheLimit()
    }
    await refreshCacheSizes()
  }

  async function clearThumbnailCachePressed() {
    if (clearing) return
    setClearing(true)
    try {
      const freed = await clearThumbnailCache()
      setCacheSize(0)
      debugLog("settings", `thumbnail cache cleared: ${freed} bytes`)
    } finally {
      setClearing(false)
    }
  }

  async function clearFtpPreviewCachePressed() {
    if (ftpClearing) return
    setFtpClearing(true)
    try {
      const freed = await clearFtpPreviewCache()
      setFtpCacheSize(0)
      debugLog("settings", `FTP preview cache cleared: ${freed} bytes`)
    } finally {
      setFtpClearing(false)
    }
  }

  async function clearLog() {
    const confirmed = await Dialog.confirm({
      title: "清理日志",
      message: "确定清空调试日志吗？",
      confirmLabel: "清理",
      cancelLabel: "取消",
    })
    if (!confirmed) return
    await clearDebugLog()
    debugLog("settings", "debug log cleared")
  }

  return (
    <NavigationStack>
      <List
        navigationTitle="设置"
        navigationBarTitleDisplayMode="inline"
        listStyle="insetGroup"
        toolbar={{ topBarLeading: <CloseButton onClose={onClose} /> }}
      >
        <Section header={<Text>关闭按钮</Text>}>
          <Picker
            title="点击左上角叉号时"
            pickerStyle="segmented"
            value={behavior}
            onChanged={changeBehavior}
          >
            <Text tag="minimize">最小化</Text>
            <Text tag="exit">退出</Text>
          </Picker>
        </Section>

        <Section header={<Text>传输</Text>}>
          <Toggle
            title="任务进行中不锁屏"
            systemImage="sun.max.fill"
            value={keepAwakeDuringTasks}
            onChanged={changeKeepAwake}
          />
        </Section>
        <Section
          header={<Text>详情</Text>}
          footer={
            <Text>
              默认关闭。开启后，详情页会逐层读取 FTP 服务器目录来统计文件夹大小；目录很大或网络较慢时可能需要较长时间。最多递归 32 层。
            </Text>
          }
        >
          <Toggle
            title="详情对 FTP 目录递归统计"
            value={recursiveFtpStats}
            onChanged={changeRecursiveFtpStats}
          />
        </Section>

        <Section header={<Text>预览</Text>}>
          <Picker
            title="缩略图缓存"
            pickerStyle="menu"
            value={cacheLimit}
            onChanged={changeCacheLimit}
          >
            {THUMBNAIL_CACHE_LIMIT_OPTIONS.map(option => (
              <Text tag={option.value}>{option.label}</Text>
            ))}
          </Picker>
          <Picker
            title="FTP预览缓存"
            pickerStyle="menu"
            value={ftpCacheLimit}
            onChanged={changeFtpCacheLimit}
          >
            {FTP_PREVIEW_CACHE_LIMIT_OPTIONS.map(option => (
              <Text tag={option.value}>{option.label}</Text>
            ))}
          </Picker>
          <LabeledContent
            title="缩略图缓存"
            value={
              cacheSize == null
                ? "读取中…"
                : cacheSize > 0
                  ? formatSize(cacheSize)
                  : "0 B"
            }
          />
          <LabeledContent
            title="FTP预览缓存"
            value={
              ftpCacheSize == null
                ? "读取中…"
                : ftpCacheSize > 0
                  ? formatSize(ftpCacheSize)
                  : "0 B"
            }
          />
          <Button
            title={clearing ? "正在清理…" : "清理缩略图缓存"}
            role="destructive"
            action={clearThumbnailCachePressed}
          />
          <Button
            title={ftpClearing ? "正在清理…" : "清理 FTP 预览缓存"}
            role="destructive"
            action={clearFtpPreviewCachePressed}
          />
        </Section>

        <Section header={<Text>关于</Text>}>
          <NavigationLink destination={<AboutPage />}>
            <LabeledContent title="版本" value={Script.metadata.version ?? "1.0.0"} />
          </NavigationLink>
        </Section>

        <Section header={<Text>调试</Text>}>
          <Toggle title="记录调试日志" value={debugEnabled} onChanged={changeDebug} />
          <NavigationLink destination={<DebugLogPage onClose={onClose} />}>
            <Text>查看日志</Text>
          </NavigationLink>
          <Button title="清理日志" role="destructive" action={clearLog} />
        </Section>
      </List>
    </NavigationStack>
  )
}
