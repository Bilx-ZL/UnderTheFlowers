import {
  Button,
  Group,
  HStack,
  Image,
  List,
  NavigationDestination,
  NavigationStack,
  ProgressView,
  Section,
  Spacer,
  Text,
  VStack,
  useEffect,
  useObservable,
  useRef,
  useState,
} from "scripting"
import { FileEntry, Mount } from "../types"
import { loadMounts, resolveMountPath } from "../services/mounts"
import {
  formatDate,
  formatSize,
  iconForEntry,
  listDirectory,
} from "../services/localfs"
import { getShowHiddenFiles } from "../services/settings"
import { validateDestinations } from "../services/transfers"

const READ_TIMEOUT = 10000
const PAGE_SIZE = 200

type Page = {
  mount: Mount
  path: string
}

function encodePage(page: Page): string {
  return JSON.stringify(page)
}

function decodePage(value: string): Page | null {
  try {
    const page = JSON.parse(value)
    if (
      page &&
      typeof page.path === "string" &&
      page.mount &&
      typeof page.mount.id === "string" &&
      typeof page.mount.name === "string"
    ) {
      return page as Page
    }
  } catch {
    // ignore malformed page
  }
  return null
}

function normalizePath(path: string): string {
  if (!path) return ""
  return path.length > 1 && path.endsWith("/") ? path.replace(/\/+$/, "") : path
}

function basename(path: string): string {
  return normalizePath(path).split("/").filter(Boolean).pop() ?? path
}

function displayName(path: string, fallback: string): string {
  return basename(path) || fallback
}

/** 返回相对挂载根的路径，根目录返回空串；不在根下返回 null。 */
function relativeToMount(path: string, root: string): string | null {
  const normalizedPath = normalizePath(path)
  const normalizedRoot = normalizePath(root)
  if (normalizedPath === normalizedRoot) return ""
  const prefix = normalizedRoot === "/" ? "/" : normalizedRoot + "/"
  if (!normalizedPath.startsWith(prefix)) return null
  return "/" + normalizedPath.slice(prefix.length)
}

function parentDirectory(path: string): string {
  const normalized = normalizePath(path)
  const index = normalized.lastIndexOf("/")
  return index <= 0 ? "/" : normalized.slice(0, index)
}

/** 只显示挂载名 + 相对挂载根的路径，绝不回退到私有绝对路径。 */
function pathLocation(mount: Mount, path: string): string {
  const mountName = mount.name.trim() || mount.name
  const root = resolveMountPath(mount)
  if (!root) return mountName
  const relative = relativeToMount(path, root)
  return relative == null ? mountName : mountName + relative
}

function buildInitialPath(mount: Mount, startPath: string): string[] {
  const root = resolveMountPath(mount)
  if (!root) return []

  const normalizedRoot = normalizePath(root)
  const start = normalizePath(startPath || root)
  const prefix = normalizedRoot === "/" ? "/" : normalizedRoot + "/"

  if (start === normalizedRoot) {
    return [encodePage({ mount, path: normalizedRoot })]
  }
  if (!start.startsWith(prefix)) {
    // 路径和挂载根对不上（可能是符号链接），只放当前页，返回到挂载列表，绝不向上越界
    return [encodePage({ mount, path: start })]
  }

  const pages: string[] = [encodePage({ mount, path: normalizedRoot })]
  let current = normalizedRoot
  const segments = start.slice(prefix.length).split("/").filter(Boolean)
  for (const segment of segments) {
    current = current === "/" ? "/" + segment : current + "/" + segment
    pages.push(encodePage({ mount, path: current }))
  }
  return pages
}

function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    let settled = false
    const timer = setTimeout(() => {
      if (settled) return
      settled = true
      reject(new Error("读取超时，目录可能已离线"))
    }, ms)
    promise.then(
      value => {
        if (settled) return
        settled = true
        clearTimeout(timer)
        resolve(value)
      },
      error => {
        if (settled) return
        settled = true
        clearTimeout(timer)
        reject(error)
      }
    )
  })
}

function DirectoryPage({
  page,
  path,
  sources,
  startMount,
  onClose,
  onConfirm,
}: {
  page: Page
  path: ReturnType<typeof useObservable<string[]>>
  sources: FileEntry[]
  startMount: Mount
  onClose: () => void
  onConfirm: (kind: "copy" | "move", sources: FileEntry[], destination: string) => void
}) {
  const [entries, setEntries] = useState<FileEntry[] | undefined>(undefined)
  const [error, setError] = useState<string | null>(null)
  const [reloadKey, setReloadKey] = useState(0)
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE)
  const previewing = useRef(false)

  useEffect(() => {
    let cancelled = false
    setEntries(undefined)
    setError(null)

    withTimeout(
      listDirectory(page.path, getShowHiddenFiles()),
      READ_TIMEOUT
    )
      .then(list => {
        if (!cancelled) setEntries(list)
      })
      .catch(e => {
        if (!cancelled) setError(e instanceof Error ? e.message : String(e))
      })

    return () => {
      cancelled = true
    }
  }, [page.path, reloadKey])

  useEffect(() => {
    setVisibleCount(PAGE_SIZE)
  }, [page.path, reloadKey])

  function enterFolder(entry: FileEntry) {
    path.setValue([
      ...path.value,
      encodePage({ mount: page.mount, path: entry.path }),
    ])
  }

  async function previewFile(entry: FileEntry) {
    if (previewing.current) return
    previewing.current = true
    try {
      await QuickLook.previewURLs([entry.path])
    } catch (e) {
      await Dialog.alert({
        title: "无法预览",
        message: e instanceof Error ? e.message : String(e),
      })
    } finally {
      previewing.current = false
    }
  }

  function openEntry(entry: FileEntry) {    if (entry.isDirectory) {
      enterFolder(entry)
    } else {
      previewFile(entry)
    }
  }

  function loadMore() {
    if (!entries) return
    setVisibleCount(count => Math.min(count + PAGE_SIZE, entries.length))
  }

  async function confirm() {
    const destination = page.path
    const problem = await validateDestinations(sources, destination).catch(e =>
      e instanceof Error ? e.message : String(e)
    )
    if (problem) {
      await Dialog.alert({ title: "无法放到这里", message: problem })
      return
    }

    const sourceDirectories = Array.from(
      new Set(sources.map(source => parentDirectory(source.path)))
    )
    const sourceText = sourceDirectories
      .map(directory => pathLocation(startMount, directory))
      .join("\n")
    const destinationText = pathLocation(page.mount, destination)
    const countText = sources.length > 1 ? `\n\n共 ${sources.length} 项` : ""
    const choice = await Dialog.actionSheet({
      title: "要执行什么操作？",
      message: `原路径：\n${sourceText}\n\n新路径：\n${destinationText}${countText}`,
      actions: [{ label: "复制" }, { label: "移动" }],
    })
    if (choice == null) return

    onConfirm(choice === 0 ? "copy" : "move", sources, destination)
  }

  const title = displayName(page.path, page.mount.name)
  const location = pathLocation(page.mount, page.path)
  const visibleEntries = (entries ?? []).slice(0, visibleCount)
  const hasMore = entries != null && visibleCount < entries.length

  return (
    <List
      navigationTitle={title}
      navigationBarTitleDisplayMode="inline"
      toolbar={{
        topBarTrailing: <Button title="选择此处" action={confirm} />,
      }}
    >
      {error != null ? (
        <Section>
          <VStack spacing={10} padding={{ vertical: 24 }} frame={{ maxWidth: "infinity" }}>
            <Image
              systemName="folder.badge.questionmark"
              font="largeTitle"
              foregroundStyle="secondaryLabel"
            />
            <Text font="headline">无法读取这个目录</Text>
            <Text font="footnote" foregroundStyle="secondaryLabel">
              {error}
            </Text>
            <Button title="重试" action={() => setReloadKey(key => key + 1)} />
          </VStack>
        </Section>
      ) : entries === undefined ? (
        <Section>
          <HStack spacing={10} padding={{ vertical: 20 }} frame={{ maxWidth: "infinity" }}>
            <ProgressView />
            <Text foregroundStyle="secondaryLabel">正在读取…</Text>
          </HStack>
        </Section>
      ) : (
        <Section header={<Text lineLimit={1} truncationMode="head">{location}</Text>}>
          {entries.length === 0 ? (
            <VStack spacing={8} padding={{ vertical: 24 }} frame={{ maxWidth: "infinity" }}>
              <Image systemName="folder" font="largeTitle" foregroundStyle="secondaryLabel" />
              <Text foregroundStyle="secondaryLabel">这个文件夹是空的</Text>
              <Text font="footnote" foregroundStyle="secondaryLabel">
                可以直接选择当前目录
              </Text>
            </VStack>
          ) : (
            <Group>
              {visibleEntries.map((entry, index) => {
                const isLast = index === visibleEntries.length - 1
                const loadMoreOnAppear =
                  isLast && hasMore ? loadMore : undefined
                const detail = entry.isDirectory
                  ? ""
                  : [
                      formatSize(entry.size),
                      entry.modifiedAt ? formatDate(entry.modifiedAt) : "",
                    ]
                      .filter(Boolean)
                      .join(" · ")

                return (
                  <Button
                    key={entry.path}
                    buttonStyle="plain"
                    contentShape="rect"
                    action={() => openEntry(entry)}
                  >
                    <HStack
                      spacing={12}
                      frame={{ maxWidth: "infinity" }}
                      contentShape="rect"
                      onAppear={loadMoreOnAppear}
                    >
                      <Image
                        systemName={iconForEntry(entry)}
                        font="title3"
                        foregroundStyle={
                          entry.isDirectory ? "systemBlue" : "secondaryLabel"
                        }
                        frame={{ width: 24 }}
                      />
                      <VStack
                        alignment="leading"
                        spacing={2}
                        frame={{ maxWidth: "infinity", alignment: "leading" }}
                      >
                        <Text lineLimit={1}>{entry.name}</Text>
                        {detail ? (
                          <Text
                            font="caption"
                            foregroundStyle="secondaryLabel"
                            lineLimit={1}
                          >
                            {detail}
                          </Text>
                        ) : null}
                      </VStack>
                      <Spacer />
                      {entry.isDirectory ? (
                        <Image
                          systemName="chevron.right"
                          font="footnote"
                          foregroundStyle="secondaryLabel"
                        />
                      ) : null}
                    </HStack>
                  </Button>
                )
              })}
              {hasMore ? (
                <HStack
                  spacing={8}
                  padding={{ vertical: 14 }}
                  frame={{ maxWidth: "infinity" }}
                >
                  <ProgressView />
                  <Text font="footnote" foregroundStyle="secondaryLabel">
                    正在加载更多…
                  </Text>
                </HStack>
              ) : null}
            </Group>
          )}
        </Section>
      )}
    </List>
  )
}

export function DestinationPicker({
  sources,
  startMount,
  startPath,
  onClose,
  onConfirm,
}: {
  sources: FileEntry[]
  startMount: Mount
  startPath: string
  onClose: () => void
  onConfirm: (kind: "copy" | "move", sources: FileEntry[], destination: string) => void
}) {
  const path = useObservable<string[]>(buildInitialPath(startMount, startPath))
  const [mounts, setMounts] = useState<Mount[] | undefined>(undefined)

  useEffect(() => {
    const initial = buildInitialPath(startMount, startPath)
    path.setValue(initial)
  }, [startMount.id, startPath])

  useEffect(() => {
    let cancelled = false
    setMounts(undefined)
    loadMounts()
      .then(list => {
        if (!cancelled) setMounts(list)
      })
      .catch(() => {
        if (!cancelled) setMounts([])
      })
    return () => {
      cancelled = true
    }
  }, [])

  function selectMount(mount: Mount, root: string) {
    path.setValue([encodePage({ mount, path: root })])
  }

  return (
    <NavigationStack path={path}>
      <List
        navigationTitle="挂载目录"
        navigationBarTitleDisplayMode="inline"
        toolbar={{
          topBarLeading: (
            <Button action={onClose}>
              <Image systemName="xmark" />
            </Button>
          ),
        }}
        navigationDestination={
          <NavigationDestination>
            {value => {
              const page = decodePage(value)
              if (!page) {
                return <Text>位置无效</Text>
              }
              return (
                <DirectoryPage
                  page={page}
                  path={path}
                  sources={sources}
                  startMount={startMount}
                  onClose={onClose}
                  onConfirm={onConfirm}
                />
              )
            }}
          </NavigationDestination>
        }
      >
        {mounts === undefined ? (
          <Section>
            <HStack spacing={10} padding={{ vertical: 20 }} frame={{ maxWidth: "infinity" }}>
              <ProgressView />
              <Text foregroundStyle="secondaryLabel">正在读取挂载…</Text>
            </HStack>
          </Section>
        ) : mounts.length === 0 ? (
          <Section>
            <VStack spacing={8} padding={{ vertical: 24 }} frame={{ maxWidth: "infinity" }}>
              <Image systemName="folder" font="largeTitle" foregroundStyle="secondaryLabel" />
              <Text foregroundStyle="secondaryLabel">还没有挂载文件夹</Text>
            </VStack>
          </Section>
        ) : (
          <Section header={<Text>挂载目录</Text>}>
            {mounts.map(mount => {
              const root = resolveMountPath(mount)
              return (
                <Button
                  key={mount.id}
                  buttonStyle="plain"
                  contentShape="rect"
                  action={() => {
                    if (root) selectMount(mount, root)
                  }}
                >
                  <HStack
                    spacing={12}
                    frame={{ maxWidth: "infinity" }}
                    contentShape="rect"
                  >
                    <Image
                      systemName="folder.fill"
                      font="title3"
                      foregroundStyle={root ? "systemBlue" : "secondaryLabel"}
                    />
                    <VStack alignment="leading" spacing={2}>
                      <Text lineLimit={1}>{mount.name}</Text>
                      <Text font="caption" foregroundStyle="secondaryLabel" lineLimit={1}>
                        {root ?? "不可用"}
                      </Text>
                    </VStack>
                    <Spacer />
                    {root ? (
                      <Image
                        systemName="chevron.right"
                        font="footnote"
                        foregroundStyle="secondaryLabel"
                      />
                    ) : null}
                  </HStack>
                </Button>
              )
            })}
          </Section>
        )}
      </List>
    </NavigationStack>
  )
}
