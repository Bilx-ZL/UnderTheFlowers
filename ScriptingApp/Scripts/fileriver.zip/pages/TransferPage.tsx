import {
  Button,
  ForEach,
  Group,
  HStack,
  Image,
  List,
  Menu,
  NavigationDestination,
  NavigationStack,
  Section,
  Spacer,
  Text,
  VStack,
  useEffect,
  useObservable,
  useRef,
  useState,
} from "scripting"
import { FTPConnection } from "../types"
import { CloseButton } from "../components/CloseButton"
import { SettingsMenu } from "../components/SettingsMenu"
import { TransferStatusButton } from "../components/TransferStatusButton"
import { debugLog } from "../services/debug"
import { ExitBehavior } from "../services/settings"
import {
  addressForDisplay,
  deleteConnection,
  loadConnections,
  saveConnections,
} from "../services/ftp"
import { createFtpSource } from "../services/source"
import { subscribeTabBarHidden } from "../services/uiState"
import { decodeRoute, encodeRoute } from "../services/routes"
import { BrowserPage } from "./BrowserPage"
import { FTPConnectionSheet } from "./FTPConnectionSheet"

function connectionDetail(connection: FTPConnection): string {
  const account = connection.username ? `${connection.username}@` : ""
  return `${account}${addressForDisplay(connection)}${
    connection.secure ? " · FTPS" : ""
  }`
}

export function TransferPage({
  onClose,
}: {
  onClose: (behavior: ExitBehavior) => void
}) {
  const [sorting, setSorting] = useState(false)
  const editMode = useObservable(EditMode.inactive())
  const orderObs = useObservable<FTPConnection[]>([])
  const navPath = useObservable<string[]>([])
  const [connections, setConnections] = useState<FTPConnection[] | undefined>(
    undefined
  )
  const [loadError, setLoadError] = useState<string | null>(null)
  const [editor, setEditor] = useState<{
    initial?: FTPConnection
    session: number
  } | null>(null)
  const editorSession = useRef(0)

  function openEditor(initial?: FTPConnection) {
    editorSession.current += 1
    setEditor({ initial, session: editorSession.current })
  }
  const [tabBarHidden, setTabBarHidden] = useState(false)

  useEffect(() => {
    return subscribeTabBarHidden(setTabBarHidden)
  }, [])

  async function reloadConnections() {
    try {
      const list = await loadConnections()
      debugLog("ftp", `loaded ${list.length} connections`)
      setLoadError(null)
      setConnections(list)
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      debugLog("ftp", `load connections failed: ${message}`)
      setLoadError(message)
      setConnections(undefined)
    }
  }

  useEffect(() => {
    reloadConnections()
  }, [])

  function handleSaved(connection: FTPConnection) {
    setEditor(null)
    setConnections(previous => {
      const list = previous ?? []
      const index = list.findIndex(item => item.id === connection.id)
      return index >= 0
        ? list.map(item =>
            item.id === connection.id ? connection : item
          )
        : [...list, connection]
    })
    debugLog("ftp", `saved ${connection.name}`)
  }

  async function removeConnection(connection: FTPConnection) {
    const confirmed = await Dialog.confirm({
      title: "移除 FTP 连接",
      message: `确定移除「${connection.name}」吗？不会删除服务器上的文件。`,
      confirmLabel: "移除",
      cancelLabel: "取消",
    })
    if (!confirmed) return

    try {
      await deleteConnection(connection.id, connections ?? [])
      setConnections(previous =>
        (previous ?? []).filter(item => item.id !== connection.id)
      )
      debugLog("ftp", `removed ${connection.name}`)
    } catch (error) {
      debugLog("ftp", `remove failed: ${String(error)}`)
      await Dialog.alert({
        title: "移除失败",
        message: String(error),
      })
    }
  }

  function startSorting() {
    orderObs.setValue([...(connections ?? [])])
    editMode.setValue(EditMode.active())
    setSorting(true)
  }

  async function finishSorting() {
    const ids = orderObs.value.map(item => item.id)
    const list = connections ?? []
    const next = ids
      .map(id => list.find(item => item.id === id))
      .filter((item): item is FTPConnection => item != null)
    editMode.setValue(EditMode.inactive())
    setSorting(false)
    await saveConnections(next)
    setConnections(next)
    debugLog("ftp", `reordered -> ${next.map(item => item.name).join(" | ")}`)
  }

  function connectionRow(connection: FTPConnection) {
    return (
      <HStack spacing={12} frame={{ maxWidth: "infinity" }} contentShape="rect">
        <Image systemName="network" font="title3" foregroundStyle="systemBlue" />
        <VStack alignment="leading" spacing={2}>
          <Text lineLimit={1}>{connection.name}</Text>
          <Text
            font="caption"
            foregroundStyle="secondaryLabel"
            lineLimit={1}
            truncationMode="head"
          >
            {connectionDetail(connection)}
          </Text>
        </VStack>
        <Spacer />
        <Image
          systemName="chevron.right"
          font="footnote"
          foregroundStyle="secondaryLabel"
        />
      </HStack>
    )
  }

  return (
    <NavigationStack
      path={navPath}
      tabBarVisibility={tabBarHidden ? "hidden" : "visible"}
    >
      <List
        navigationTitle="FTP"
        navigationBarTitleDisplayMode="inline"
        listStyle="insetGroup"
        environments={{ editMode }}
        sheet={{
          isPresented: editor != null,
          onChanged: open => {
            if (!open) setEditor(null)
          },
          content: editor ? (
            <FTPConnectionSheet
              session={editor.session}
              initial={editor.initial}
              connections={connections ?? []}
              onClose={() => setEditor(null)}
              onSaved={handleSaved}
            />
          ) : (
            <Text> </Text>
          ),
        }}
        navigationDestination={
          <NavigationDestination>
            {value => {
              const route = decodeRoute(value)
              const connection =
                route == null
                  ? undefined
                  : (connections ?? []).find(
                      item => item.id === route.mountId
                    )
              if (!connection) {
                return (
                  <VStack
                    spacing={10}
                    padding={24}
                    frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
                  >
                    <Text font="headline">连接不可用</Text>
                    <Text font="footnote" foregroundStyle="secondaryLabel">
                      FTP 连接可能已被移除。
                    </Text>
                  </VStack>
                )
              }
              return (
                <BrowserPage
                  source={createFtpSource(connection)}
                  path={route?.path}
                  navPath={navPath}
                  onClose={onClose}
                />
              )
            }}
          </NavigationDestination>
        }
        toolbar={{
          topBarLeading: [
            <CloseButton onClose={onClose} />,
            ...(sorting
              ? []
              : [
                  <Menu label={<Image systemName="plus" />}>
                    <Button
                      title="添加FTP连接"
                      systemImage="network"
                      disabled={connections === undefined}
                      action={() => {
                        // 连接列表还没读完时先别让用户添加，避免覆盖已有配置
                        if (connections === undefined) return
                        openEditor()
                      }}
                    />
                  </Menu>,
                ]),
          ],
          topBarTrailing: sorting ? (
            <Button title="完成" action={finishSorting} />
          ) : (
            <HStack spacing={8}>
              <TransferStatusButton />
              <SettingsMenu onSort={startSorting} />
            </HStack>
          ),
        }}
      >
        <Section header={<Text>FTP连接</Text>}>
          {loadError != null ? (
            <VStack
              spacing={10}
              padding={{ vertical: 28 }}
              frame={{ maxWidth: "infinity" }}
            >
              <Image
                systemName="externaldrive.badge.exclamationmark"
                font="largeTitle"
                foregroundStyle="secondaryLabel"
              />
              <Text font="headline">无法读取 FTP 连接</Text>
              <Text
                font="footnote"
                foregroundStyle="secondaryLabel"
                lineLimit={3}
              >
                {loadError}
              </Text>
              <Button title="重试" action={reloadConnections} />
            </VStack>
          ) : connections === undefined ? null : connections.length === 0 ? (
            <VStack
              spacing={10}
              padding={{ vertical: 28 }}
              frame={{ maxWidth: "infinity" }}
            >
              <Image
                systemName="network"
                font="largeTitle"
                foregroundStyle="secondaryLabel"
              />
              <Text font="headline">还没有 FTP 连接</Text>
              <Text font="footnote" foregroundStyle="secondaryLabel">
                点左上角的加号，添加一个 FTP 连接。
              </Text>
            </VStack>
          ) : sorting ? (
            <ForEach
              data={orderObs}
              editActions="move"
              builder={connection => connectionRow(connection)}
            />
          ) : (
            connections.map(connection => (
              <Button
                key={connection.id}
                buttonStyle="plain"
                contentShape="rect"
                action={() =>
                  navPath.setValue([encodeRoute(connection.id)])
                }
                contextMenu={{
                  menuItems: (
                    <Group>
                      <Button
                        title="编辑"
                        systemImage="pencil"
                        action={() => openEditor(connection)}
                      />
                      <Button
                        title="移除连接"
                        systemImage="trash"
                        tint="red"
                        action={() => removeConnection(connection)}
                      />
                    </Group>
                  ),
                }}
                frame={{ maxWidth: "infinity" }}
              >
                {connectionRow(connection)}
              </Button>
            ))
          )}
        </Section>
      </List>
    </NavigationStack>
  )
}
