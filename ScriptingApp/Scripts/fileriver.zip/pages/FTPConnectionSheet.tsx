import {
  Button,
  HStack,
  List,
  NavigationStack,
  ProgressView,
  SecureField,
  Section,
  Text,
  TextField,
  Toggle,
  useEffect,
  useRef,
  useState,
} from "scripting"
import type { VirtualNode } from "scripting"
import { FTPConnection } from "../types"
import { debugLog } from "../services/debug"
import {
  loadFtpPassword,
  makeConnectionId,
  parseFtpAddress,
  parseFtpPort,
  testFtpConnection,
  upsertConnection,
} from "../services/ftp"

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

function FieldRow({
  label,
  children,
}: {
  label: string
  children: VirtualNode
}) {
  return (
    <HStack spacing={12} frame={{ maxWidth: "infinity" }}>
      <Text frame={{ width: 84 }}>{label}</Text>
      {children}
    </HStack>
  )
}

export function FTPConnectionSheet({
  session,
  initial,
  connections,
  onClose,
  onSaved,
}: {
  /** 每次打开表单都会递增，用于强制重置内部状态 */
  session: number
  initial?: FTPConnection
  connections: FTPConnection[]
  onClose: () => void
  onSaved: (connection: FTPConnection) => void
}) {
  const [name, setName] = useState(initial?.name ?? "")
  const [address, setAddress] = useState(
    initial
      ? initial.host.includes(":")
        ? `[${initial.host}]`
        : initial.host
      : ""
  )
  const [port, setPort] = useState(initial ? String(initial.port) : "21")
  const [username, setUsername] = useState(initial?.username ?? "")
  const [password, setPassword] = useState(
    () => (initial ? loadFtpPassword(initial.id) ?? "" : "")
  )
  const [path, setPath] = useState(initial?.path ?? "/")
  const [secure, setSecure] = useState(initial?.secure ?? false)
  const [insecure, setInsecure] = useState(initial?.insecure ?? false)
  const [connecting, setConnecting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const cancelled = useRef(false)
  const sessionRef = useRef(session)
  sessionRef.current = session

  useEffect(() => {
    return () => {
      cancelled.current = true
    }
  }, [])

  // sheet 可能复用同一个组件实例；每次打开都按 initial 重置，避免新增/编辑串状态
  useEffect(() => {
    cancelled.current = false
    setName(initial?.name ?? "")
    setAddress(
      initial
        ? initial.host.includes(":")
          ? `[${initial.host}]`
          : initial.host
        : ""
    )
    setPort(initial ? String(initial.port) : "21")
    setUsername(initial?.username ?? "")
    setPassword(initial ? loadFtpPassword(initial.id) ?? "" : "")
    setPath(initial?.path ?? "/")
    setSecure(initial?.secure ?? false)
    setInsecure(initial?.insecure ?? false)
    setConnecting(false)
    setError(null)
  }, [session])

  function changeAddress(value: string) {
    setAddress(value)
    if (/^ftps:\/\//i.test(value.trim())) setSecure(true)
  }

  async function connect() {
    if (connecting) return
    const requestSession = session
    setError(null)
    setConnecting(true)

    let connection: FTPConnection
    try {
      const portNumber = parseFtpPort(port)
      const parsed = parseFtpAddress(address, {
        port: portNumber,
        path,
        secure,
      })
      const trimmedUsername = username.trim()
      if (trimmedUsername.includes(":")) {
        throw new Error("用户名不能包含冒号。")
      }
      if (/[\r\n]/.test(trimmedUsername) || /[\r\n]/.test(password)) {
        throw new Error("用户名或密码不能包含换行。")
      }
      const hostLabel = parsed.host.includes(":")
        ? `[${parsed.host}]`
        : parsed.host
      const defaultName =
        parsed.port === 21 ? hostLabel : `${hostLabel}:${parsed.port}`
      connection = {
        id: initial?.id ?? makeConnectionId(),
        name: name.trim() || defaultName,
        host: parsed.host,
        port: parsed.port,
        username: trimmedUsername,
        path: parsed.path,
        secure: parsed.secure,
        insecure,
        createdAt: initial?.createdAt ?? Date.now(),
        lastConnectedAt: Date.now(),
      }
    } catch (e) {
      const message = errorMessage(e)
      setError(message)
      setConnecting(false)
      await Dialog.alert({ title: "请检查连接信息", message })
      return
    }

    const changed =
      initial == null ||
      initial.host !== connection.host ||
      initial.port !== connection.port ||
      initial.username !== connection.username ||
      initial.path !== connection.path ||
      initial.secure !== connection.secure ||
      initial.insecure !== connection.insecure ||
      password !== (loadFtpPassword(initial.id) ?? "")

    if (!changed && initial) {
      connection.lastConnectedAt = initial.lastConnectedAt
    }

    // 只改显示名称时不强制联网，服务器暂时离线也能保存
    if (changed) {
      try {
        await testFtpConnection(connection, password)
      } catch (e) {
        const message = errorMessage(e)
        debugLog("ftp", `connect failed: ${connection.host} ${message}`)
        if (cancelled.current || sessionRef.current !== requestSession) return
        setError(message)
        setConnecting(false)
        await Dialog.alert({ title: "连接失败", message })
        return
      }
    }

    if (cancelled.current || sessionRef.current !== requestSession) return

    try {
      await upsertConnection(connection, password, initial == null, connections)
    } catch (e) {
      const message = errorMessage(e)
      debugLog("ftp", `save connection failed: ${connection.host} ${message}`)
      if (cancelled.current || sessionRef.current !== requestSession) return
      setError(message)
      setConnecting(false)
      await Dialog.alert({ title: "保存失败", message })
      return
    }

    if (cancelled.current || sessionRef.current !== requestSession) return
    debugLog(
      "ftp",
      `${initial ? "updated" : "added"} ${connection.name} (${connection.host}:${connection.port})`
    )
    setConnecting(false)
    onSaved(connection)
  }

  return (
    <NavigationStack>
      <List
        listStyle="insetGroup"
        navigationTitle={initial ? "编辑 FTP 连接" : "添加 FTP 连接"}
        navigationBarTitleDisplayMode="inline"
        toolbar={{
          topBarLeading: <Button title="取消" action={onClose} />,
          topBarTrailing: connecting ? (
            <ProgressView />
          ) : (
            <Button
              title={initial ? "保存" : "连接"}
              action={connect}
              disabled={!address.trim()}
            />
          ),
        }}
      >
        <Section header={<Text>服务器</Text>}>
          <FieldRow label="名称">
            <TextField
              label={<Text>名称</Text>}
              value={name}
              onChanged={setName}
              prompt="可选"
              frame={{ maxWidth: "infinity" }}
            />
          </FieldRow>
          <FieldRow label="地址">
            <TextField
              label={<Text>地址</Text>}
              value={address}
              onChanged={changeAddress}
              prompt="ftp.example.com"
              keyboardType="URL"
              textContentType="URL"
              textInputAutocapitalization="never"
              autocorrectionDisabled
              frame={{ maxWidth: "infinity" }}
            />
          </FieldRow>
          <FieldRow label="端口">
            <TextField
              label={<Text>端口</Text>}
              value={port}
              onChanged={setPort}
              prompt="21"
              keyboardType="numberPad"
              frame={{ maxWidth: "infinity" }}
            />
          </FieldRow>
        </Section>

        <Section header={<Text>登录</Text>}>
          <FieldRow label="用户名">
            <TextField
              label={<Text>用户名</Text>}
              value={username}
              onChanged={setUsername}
              prompt="留空为匿名"
              textContentType="username"
              textInputAutocapitalization="never"
              autocorrectionDisabled
              frame={{ maxWidth: "infinity" }}
            />
          </FieldRow>
          <FieldRow label="密码">
            <SecureField
              label={<Text>密码</Text>}
              value={password}
              onChanged={setPassword}
              prompt="可留空"
              textContentType="password"
              frame={{ maxWidth: "infinity" }}
            />
          </FieldRow>
        </Section>

        <Section header={<Text>目录</Text>}>
          <FieldRow label="远程目录">
            <TextField
              label={<Text>远程目录</Text>}
              value={path}
              onChanged={setPath}
              prompt="/"
              keyboardType="URL"
              textInputAutocapitalization="never"
              autocorrectionDisabled
              frame={{ maxWidth: "infinity" }}
            />
          </FieldRow>
        </Section>

        <Section header={<Text>高级</Text>}>
          <Toggle
            title="使用 FTPS（显式 TLS）"
            value={secure}
            onChanged={setSecure}
          />
          <Toggle
            title="忽略证书错误"
            value={insecure}
            onChanged={setInsecure}
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            仅在服务器使用自签名证书时打开。新连接或修改服务器信息时会先用列目录验证地址和账号。
          </Text>
        </Section>

        {error ? (
          <Section>
            <Text foregroundStyle="red">{error}</Text>
          </Section>
        ) : null}
      </List>
    </NavigationStack>
  )
}
