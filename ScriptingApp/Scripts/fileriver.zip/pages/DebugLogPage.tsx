import { Button, Image, ScrollView, Text, VStack, useEffect, useState } from "scripting"
import { clearDebugLog, readDebugLog } from "../services/debug"
import { CloseButton } from "../components/CloseButton"
import { ExitBehavior } from "../services/settings"

export function DebugLogPage({
  onClose,
}: {
  onClose: (behavior: ExitBehavior) => void
}) {
  const [content, setContent] = useState<string | undefined>(undefined)

  async function refresh() {
    setContent(await readDebugLog())
  }

  useEffect(() => {
    refresh()
  }, [])

  async function clear() {
    const confirmed = await Dialog.confirm({
      title: "清理日志",
      message: "确定清空调试日志吗？",
      confirmLabel: "清理",
      cancelLabel: "取消",
    })
    if (!confirmed) return
    await clearDebugLog()
    await refresh()
  }

  return (
    <ScrollView
      navigationTitle="调试日志"
      navigationBarTitleDisplayMode="inline"
      toolbar={{
        topBarLeading: <CloseButton onClose={onClose} />,
        topBarTrailing: [
          <Button action={refresh}>
            <Image systemName="arrow.clockwise" />
          </Button>,
          <Button role="destructive" action={clear}>
            <Image systemName="trash" />
          </Button>,
        ],
      }}
    >
      <VStack alignment="leading" spacing={0} padding={16}>
        <Text
          font="caption"
          monospaced
          foregroundStyle={content ? "label" : "secondaryLabel"}
        >
          {content === undefined ? "读取中…" : content.length === 0 ? "暂无日志" : content}
        </Text>
      </VStack>
    </ScrollView>
  )
}
