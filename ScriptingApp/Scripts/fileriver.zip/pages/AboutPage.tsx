import {
  Button,
  HStack,
  Image,
  Navigation,
  Script,
  ScrollView,
  ScrollViewProxy,
  ScrollViewReader,
  Spacer,
  Text,
  VStack,
  useEffect,
  useRef,
  useState,
} from "scripting"

/** 第二至第四页的插图，对应 assets/ 下的文件。 */
const GUIDE_IMAGES = ["assets/usage-1.jpg", "assets/usage-2.jpg", "assets/usage-3.jpg"]

/** 第一页文字介绍，后面每张插图各占一页。 */
const TOTAL_PAGES = GUIDE_IMAGES.length + 1

/**
 * 关于页。
 *
 * 两种打开方式：
 * 1. 设置 → 点「版本」这一行进来的（外面已有 NavigationStack，这里不再套一层）
 * 2. 首次运行的弹窗（调用方自己套 NavigationStack）
 *
 * 共四页：首页是文字介绍，第二至四页是使用说明插图。
 * 底部按钮在非末页是「下一页」，末页变回「关闭」。
 */
export function AboutPage() {
  const dismiss = Navigation.useDismiss()
  const [page, setPage] = useState(0)
  const proxyRef = useRef<ScrollViewProxy>()

  const isLastPage = page === TOTAL_PAGES - 1

  // 翻页后回到顶部，避免上一页滚到一半的位置延续到下一页
  useEffect(() => {
    proxyRef.current?.scrollTo(`page-${page}`, "top")
  }, [page])

  function advance() {
    if (isLastPage) {
      dismiss()
      return
    }
    setPage(page + 1)
  }

  return (
    <ScrollViewReader>
      {proxy => {
        proxyRef.current = proxy
        return (
          <ScrollView
            navigationTitle="FTP文件流"
            navigationBarTitleDisplayMode="inline"
            safeAreaInset={{
              bottom: {
                spacing: 0,
                content: (
                  <HStack frame={{ maxWidth: "infinity" }} padding={{ bottom: 24 }}>
                    <Spacer />
                    <Button
                      action={advance}
                      buttonStyle="plain"
                      padding={{ horizontal: 44, vertical: 12 }}
                      glassEffect={{ glass: UIGlass.regular(), shape: "capsule" }}
                    >
                      <Text font="headline" foregroundStyle="label">
                        {isLastPage ? "关闭" : "下一页"}
                      </Text>
                    </Button>
                    <Spacer />
                  </HStack>
                ),
              },
            }}
          >
            {page === 0 ? (
              <Intro key="page-0" />
            ) : (
              <GuideImage key={`page-${page}`} page={page} />
            )}
          </ScrollView>
        )
      }}
    </ScrollViewReader>
  )
}

function Intro() {
  return (
    <VStack
      spacing={14}
      alignment="leading"
      frame={{ maxWidth: "infinity", alignment: "leading" }}
      padding={{ horizontal: 20, top: 12, bottom: 40 }}
    >
      <Text font="headline">有什么用</Text>
      <Text>一个用于在FTP服务器与手机互传文件的脚本。</Text>
      <Text>经常要手机电脑FTP互传，而商店一直没找到好看，好用，有性能的App，所以写了脚本自用。</Text>

      <Text font="headline" padding={{ top: 10 }}>
        特点
      </Text>
      <Text>
        简单高效，可直接从挂载目录和FTP在选定目录互传文件，可直接将外部文件拖动到+号按钮上传到FTP，或从FTP即时共享。
      </Text>

      <Text font="headline" padding={{ top: 10 }}>
        局限性
      </Text>
      <Text>Scripting暂不支持部分特性，无法从FTP拖出到应用外；</Text>
      <Text>不支持多线程。</Text>

      <Text font="headline" padding={{ top: 10 }}>
        写盘
      </Text>
      <Text>缓存在 我的iPhone/Scripting/文件流</Text>
      <Text>设置在 iCloud/Scripting/文件流</Text>
      <Text>凭据在系统钥匙串中由系统和App处理。</Text>

      <Button
        title="Telegram：@Qing_UL"
        systemImage="paperplane"
        action={() => {
          Safari.openURL("https://t.me/Qing_UL").catch(() => {})
        }}
      />
    </VStack>
  )
}

function GuideImage({ page }: { page: number }) {
  return (
    <VStack frame={{ maxWidth: "infinity" }} padding={{ bottom: 40 }}>
      <Image
        filePath={`${Script.directory}/${GUIDE_IMAGES[page - 1]}`}
        resizable={true}
        scaleToFit={true}
        frame={{ maxWidth: "infinity" }}
      />
    </VStack>
  )
}
