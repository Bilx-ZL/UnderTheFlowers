import {
  AbortController,
  Button,
  ForEach,
  GlassEffectContainer,
  Group,
  HStack,
  Image,
  List,
  ProgressView,
  Rectangle,
  ScrollViewReader,
  Section,
  Spacer,
  Text,
  VStack,
  ZStack,
  useEffect,
  useObservable,
  useRef,
  useState,
} from "scripting"
import type { VirtualNode } from "scripting"
import { FileEntry } from "../types"
import { FileSource } from "../services/source"
import { formatDate, formatSize, iconForEntry } from "../services/localfs"
import { removeProviderTempCopy } from "../services/dragStage"
import { resolveAttachments, type DroppedItem } from "../services/dropImport"
import { debugLog } from "../services/debug"
import { setTabBarHidden } from "../services/uiState"
import { CloseButton } from "../components/CloseButton"
import { SettingsMenu } from "../components/SettingsMenu"
import { TransferStatusButton } from "../components/TransferStatusButton"
import { DetailsSheet } from "../components/DetailsSheet"
import { DestinationPicker } from "./DestinationPicker"
import { startActionTask, startBatchDelete, startBatchTransfer, startDelete, notifyRemoteChanges, notifyTransferChanges, subscribeRemoteChanges, subscribeTransferChanges } from "../services/transfers"
import { DownloadCancelledError } from "../services/ftp"
import { ExitBehavior, subscribeShowHidden } from "../services/settings"
import { getShowHiddenFiles, getThumbnailsEnabled, subscribeThumbnails } from "../services/settings"
import { isThumbnailEligible, requestThumbnail, thumbnailKind } from "../services/thumbnails"
import { encodeRoute } from "../services/routes"
import { downloadEntriesToDir } from "../services/downloads"
import type { ConflictDecision, DownloadFileStats } from "../services/downloads"
import { cancelTransfer, enqueueTransfer } from "../services/transferQueue"
import { shareStageRoot } from "../services/paths"
import { OverwritePrompt } from "../components/OverwritePrompt"
import { MountPickerSheet } from "../components/MountPickerSheet"
import {
  clearLocalSession,
  createLocalSessionId,
  getLocalTarget,
  setLocalSession,
} from "../services/localTarget"
import {
  clearRemoteSession,
  createRemoteSessionId,
  getRemoteTarget,
  setRemoteSession,
  type RemoteTarget,
} from "../services/remoteTarget"
import { uploadEntriesToDir } from "../services/upload"
import type { UploadFileStats } from "../services/upload"
import { UploadCancelledError } from "../services/ftp"

import {
  SelectionCheckStore,
  createSelectionCheckStore,
} from "../services/selectionStore"

/**
 * 每次渲染的行数。导航栈里每一层都是一个活着的 BrowserPage，
 * push/pop 会让整栈页面重渲染 —— 这个值直接决定单页重建成本，
 * 所以宁可小一点、靠滚到底自动加载更多。
 */
const PAGE_SIZE = 30
/** 进入目录时先主动生成的首屏行数：List 初次布局时 onAppear 不一定触发，靠它兜底。 */
const PRELOAD_ROWS = 20
let lastRowTapAt = 0

function sameDirectory(a: string, b: string): boolean {
  const normalize = (value: string) =>
    value.length > 1 ? value.replace(/\/+$/, "") : value
  return normalize(a) === normalize(b)
}

/** 剩余时间：按当前速度估算，粗粒度取整避免数字跳个不停。 */
function formatEta(remainingBytes: number, bytesPerSecond?: number): string | null {
  if (!bytesPerSecond || bytesPerSecond <= 0 || remainingBytes <= 0) return null
  const seconds = remainingBytes / bytesPerSecond
  if (!Number.isFinite(seconds) || seconds <= 0) return null
  if (seconds < 10) return `剩余约 ${Math.max(1, Math.round(seconds))} 秒`
  if (seconds < 60) return `剩余约 ${Math.round(seconds / 5) * 5} 秒`
  if (seconds < 3600) return `剩余约 ${Math.round(seconds / 60)} 分`
  return `剩余约 ${(seconds / 3600).toFixed(1)} 小时`
}

/** 任务副标题：单文件显示「已下载 / 总大小 · 速度 · 剩余」，多文件再加上文件计数。 */
function describeFileProgress(
  stats: DownloadFileStats,
  completed: number,
  plannedTotal: number
): string {
  const parts: string[] = []
  if (plannedTotal > 1) parts.push(`${completed + 1} / ${plannedTotal}`)
  const sizeText = stats.total > 0
    ? `${formatSize(stats.loaded)} / ${formatSize(stats.total)}`
    : formatSize(stats.loaded)
  if (sizeText) parts.push(sizeText)
  if (stats.bytesPerSecond && stats.bytesPerSecond > 0) {
    parts.push(`${formatSize(stats.bytesPerSecond)}/s`)
    const eta = formatEta(stats.total - stats.loaded, stats.bytesPerSecond)
    if (eta) parts.push(eta)
  }
  return parts.join(" · ")
}

function splitExtension(name: string): { base: string; ext: string } {  const index = name.lastIndexOf(".")
  if (index <= 0 || index === name.length - 1) return { base: name, ext: "" }
  return { base: name.slice(0, index), ext: name.slice(index) }
}

function extensionLabel(ext: string): string {
  return ext ? `“${ext}”` : "无扩展名"
}

function withTimeout<T>(task: Promise<T>, ms: number): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    let settled = false
    setTimeout(() => {
      if (!settled) {
        settled = true
        reject(new Error("读取超时，目录可能已离线"))
      }
    }, ms)
    task.then(
      value => {
        if (!settled) {
          settled = true
          resolve(value)
        }
      },
      error => {
        if (!settled) {
          settled = true
          reject(error)
        }
      }
    )
  })
}

function RowCheck({
  store,
  path,
}: {
  store: SelectionCheckStore
  path: string
}) {
  const [checked, setChecked] = useState(() => store.isChecked(path))

  useEffect(() => {
    const update = () => setChecked(store.isChecked(path))
    update()
    return store.subscribePath(path, update)
  }, [path])

  return (
    <Image
      systemName={checked ? "checkmark.circle.fill" : "circle"}
      font="title3"
      foregroundStyle={checked ? "systemBlue" : "secondaryLabel"}
    />
  )
}

function RowHighlight({
  store,
  path,
}: {
  store: SelectionCheckStore
  path: string
}) {
  const [checked, setChecked] = useState(() => store.isChecked(path))

  useEffect(() => {
    const update = () => setChecked(store.isChecked(path))
    update()
    return store.subscribePath(path, update)
  }, [path])

  return checked ? <Rectangle fill="secondarySystemFill" /> : null
}

function SelectAllButton({
  total,
  nativeCount,
  selectAllActive,
  store,
  onToggle,
}: {
  total: number
  nativeCount: number
  selectAllActive: boolean
  store: SelectionCheckStore
  onToggle: () => void
}) {
  const compute = () => {
    const count = selectAllActive
      ? Math.max(0, total - store.deselectedCount())
      : nativeCount
    return total > 0 && count === total
  }
  const [allSelected, setAllSelected] = useState(compute)

  useEffect(() => {
    const update = () => setAllSelected(compute())
    update()
    return store.subscribeSummary(update)
  }, [selectAllActive, total, nativeCount])

  return (
    <Button
      title={allSelected ? "取消全选" : "全选"}
      action={onToggle}
    />
  )
}

function SelectionSummary({
  total,
  nativeCount,
  selectAllActive,
  store,
  editing,
}: {
  total: number | null
  nativeCount: number
  selectAllActive: boolean
  store: SelectionCheckStore
  editing: boolean
}) {
  const compute = () => {
    if (total == null) return 0
    return selectAllActive
      ? Math.max(0, total - store.deselectedCount())
      : nativeCount
  }
  const [count, setCount] = useState(compute)

  useEffect(() => {
    const update = () => setCount(compute())
    update()
    return store.subscribeSummary(update)
  }, [selectAllActive, total, nativeCount])

  const text = entryLabel(total, count, editing)
  return (
    <Text font="caption2" foregroundStyle="secondaryLabel" lineLimit={1}>
      {text}
    </Text>
  )
}

function entryLabel(total: number | null, count: number, editing: boolean): string {
  if (total == null) return " "
  if (!editing) return `${total}项`
  const all = total > 0 && count === total
  return all ? `已全选 ${count}项` : `已选 ${count}项`
}

function ThumbnailSlot({
  entry,
  enabled,
  thumbnail,
}: {
  entry: FileEntry
  enabled: boolean
  thumbnail: UIImage | null
}) {
  const eligible = enabled && isThumbnailEligible(entry)
  if (eligible && thumbnail) {
    return (
      <Image
        image={thumbnail}
        resizable
        aspectRatio={{ contentMode: "fill" }}
        frame={{ width: 40, height: 40 }}
        clipShape={{ type: "rect", cornerRadius: 6 }}
      />
    )
  }
  return (
    <Image
      systemName={iconForEntry(entry)}
      font="title3"
      foregroundStyle={entry.isDirectory ? "systemBlue" : "secondaryLabel"}
      frame={{ width: 40, height: 40 }}
    />
  )
}

function FileRow({
  entry,
  onAppear,
  showChevron = false,
  interactive = true,
  checkable = false,
  checkStore,
  thumbnailsEnabled,
  preloadThumbnail = false,
}: {
  entry: FileEntry
  onAppear?: () => void
  showChevron?: boolean
  interactive?: boolean
  checkable?: boolean
  checkStore?: SelectionCheckStore
  thumbnailsEnabled: boolean
  preloadThumbnail?: boolean
}) {
  const [thumbnail, setThumbnail] = useState<UIImage | null>(null)
  const cancelRef = useRef<(() => void) | null>(null)
  const hasThumbRef = useRef(false)
  const eligible = thumbnailsEnabled && isThumbnailEligible(entry)

  // 关闭缩略图时丢掉旧图/取消任务
  useEffect(() => {
    if (!eligible) {
      cancelRef.current?.()
      cancelRef.current = null
      hasThumbRef.current = false
      setThumbnail(null)
    }
  }, [eligible])

  useEffect(() => {
    cancelRef.current?.()
    cancelRef.current = null
    hasThumbRef.current = false
    setThumbnail(null)
  }, [entry.path])

  // 行被移除时兜底取消
  useEffect(() => {
    return () => {
      cancelRef.current?.()
      cancelRef.current = null
    }
  }, [])

  function startThumbnail() {
    if (!eligible || hasThumbRef.current || cancelRef.current) return
    cancelRef.current = requestThumbnail(entry, image => {
      cancelRef.current = null
      if (image) {
        hasThumbRef.current = true
        setThumbnail(image)
      }
    })
  }

  function stopThumbnail() {
    // 首屏行：初次布局时偶发 onDisappear，不因它放弃正在排队的首屏任务（真滑出会走卸载时的清理）
    if (preloadThumbnail && !hasThumbRef.current) return
    cancelRef.current?.()
    cancelRef.current = null
  }

  // 首屏行：初次进入目录时 onAppear 未必触发，挂载后主动请求一次
  useEffect(() => {
    if (!preloadThumbnail) return
    const timer = setTimeout(() => startThumbnail(), 250)
    return () => clearTimeout(timer)
  }, [preloadThumbnail, entry.path, eligible])

  const detail = entry.isDirectory
    ? entry.modifiedAt
      ? formatDate(entry.modifiedAt)
      : "文件夹"
    : [formatSize(entry.size), entry.modifiedAt ? formatDate(entry.modifiedAt) : ""]
        .filter(Boolean)
        .join(" · ")

  return (
    <HStack
      spacing={12}
      frame={{ maxWidth: "infinity" }}
      contentShape="rect"
      allowsHitTesting={interactive}
      onAppear={() => {
        onAppear?.()
        startThumbnail()
      }}
      onDisappear={stopThumbnail}
    >
      {checkable && checkStore ? (
        <RowCheck store={checkStore} path={entry.path} />
      ) : null}
      <ThumbnailSlot entry={entry} enabled={thumbnailsEnabled} thumbnail={thumbnail} />
      <VStack alignment="leading" spacing={2}>
        <Text lineLimit={1}>{entry.name}</Text>
        <Text font="caption" foregroundStyle="secondaryLabel" lineLimit={1}>
          {detail}
        </Text>
      </VStack>
      <Spacer />
      {showChevron ? (
        <Image systemName="chevron.right" font="footnote" foregroundStyle="secondaryLabel" />
      ) : null}
    </HStack>
  )
}

function UnavailableView({
  title,
  message,
  onRetry,
}: {
  title: string
  message: string
  onRetry: () => void
}) {
  return (
    <VStack spacing={10} padding={{ vertical: 24 }} frame={{ maxWidth: "infinity" }}>
      <Image
        systemName="externaldrive.badge.exclamationmark"
        font="largeTitle"
        foregroundStyle="secondaryLabel"
      />
      <Text font="headline">{title}</Text>
      <Text font="footnote" foregroundStyle="secondaryLabel">
        {message}
      </Text>
      <Button title="重试" action={onRetry} />
    </VStack>
  )
}

/** 屏幕中间的阻塞模态：标题 + 可选进度详情 + 可选取消。 */
type BusyState = { title: string; detail?: string; onCancel?: () => void }

type SelectionAction = {
  id: string
  title: string
  systemImage: string
  action: () => void
  /** 单独置灰（例如暂未实现的功能） */
  disabled?: boolean
}

function SelectionActionBar({
  total,
  nativeCount,
  selectAllActive,
  store,
  actions,
}: {
  total: number
  nativeCount: number
  selectAllActive: boolean
  store: SelectionCheckStore
  actions: SelectionAction[]
}) {
  const compute = () =>
    selectAllActive ? Math.max(0, total - store.deselectedCount()) : nativeCount
  const [count, setCount] = useState(compute)

  // 只订阅自定义勾选集合，不碰 List 绑定的 selection Observable
  useEffect(() => {
    const update = () => setCount(compute())
    update()
    return store.subscribeSummary(update)
  }, [selectAllActive, total, nativeCount])

  const disabled = count === 0

  return (
    <HStack frame={{ maxWidth: "infinity" }} padding={{ bottom: 24 }}>
      <Spacer />
      <GlassEffectContainer>
        <HStack
          spacing={actions.length > 3 ? 12 : 16}
          padding={{ horizontal: 18, vertical: 10 }}
          glassEffect={{ glass: UIGlass.regular(), shape: "capsule" }}
        >
          {actions.map(item => {
            const off = disabled || item.disabled === true
            return (
              <Button
                key={item.id}
                action={item.action}
                disabled={off}
                buttonStyle="plain"
                opacity={off ? 0.35 : 1}
              >
                <VStack spacing={2} frame={{ width: actions.length > 3 ? 62 : 76 }}>
                  <Image
                    systemName={item.systemImage}
                    font="title2"
                    foregroundStyle="label"
                  />
                  <Text font="caption2" foregroundStyle="label" lineLimit={1}>
                    {item.title}
                  </Text>
                </VStack>
              </Button>
            )
          })}
        </HStack>
      </GlassEffectContainer>
      <Spacer />
    </HStack>
  )
}

export function BrowserPage({
  source,
  path,
  onClose,
  navPath,
}: {
  source: FileSource
  path?: string
  onClose: (behavior: ExitBehavior) => void
  navPath?: Observable<string[]>
}) {
  const [rootPath, setRootPath] = useState<string | null>(
    () => path ?? source.rootPath
  )
  const [entries, setEntries] = useState<FileEntry[] | undefined>(undefined)
  const [error, setError] = useState<string | null>(null)
  const [reloadKey, setReloadKey] = useState(0)
  const [thumbnailsEnabled, setThumbnailsEnabled] = useState(getThumbnailsEnabled())
  const [refreshKey, setRefreshKey] = useState(0)
  const [pageVisible, setPageVisible] = useState(false)
  const [pendingRefresh, setPendingRefresh] = useState(false)
  const [copySources, setCopySources] = useState<FileEntry[] | null>(null)
  const [copySession, setCopySession] = useState(0)
  const [downloadSources, setDownloadSources] = useState<FileEntry[] | null>(null)
  const [downloadSession, setDownloadSession] = useState(0)
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE)
  const [selectAllActive, setSelectAllActive] = useState(false)
  const checkStore = useRef(createSelectionCheckStore()).current
  const selection = useObservable<string[]>([])
  const editMode = useObservable<EditMode>(EditMode.inactive())
  const [animatedEditing, setAnimatedEditing] = useState(false)
  const [detailEntry, setDetailEntry] = useState<FileEntry | null>(null)
  const [busy, setBusy] = useState<BusyState | null>(null)
  const [toastMessage, setToastMessage] = useState<string | null>(null)
  const [pendingScrollPath, setPendingScrollPath] = useState<string | null>(null)
  const scrollProxy = useRef<{
    scrollTo: (id: string, anchor?: any) => void
  } | null>(null)
  const animateNextRows = useRef(false)
  const lastRefreshAt = useRef(0)
  const busyRef = useRef(false)
  const deletingRef = useRef(false)
  /** 冲突弹窗是全局单实例（一个 sheet），所以多个任务同时遇到同名时排队询问。 */
  type ConflictAsk = { name: string; subtitle: string; showApplyAll: boolean }
  type PendingConflict = {
    info: ConflictAsk
    resolve: (decision: { action: ConflictDecision; applyAll: boolean }) => void
  }
  const conflictActive = useRef<PendingConflict | null>(null)
  const conflictQueue = useRef<PendingConflict[]>([])
  const [conflictPrompt, setConflictPrompt] = useState<ConflictAsk | null>(null)
  const localSessionId = useRef(0)
  if (localSessionId.current === 0) localSessionId.current = createLocalSessionId()
  const remoteSessionId = useRef(0)
  if (remoteSessionId.current === 0) remoteSessionId.current = createRemoteSessionId()
  const rowData = useObservable<{ id: string; entry: FileEntry; index: number }[]>([])

  // 选择的 UI 状态和原生 editMode 解耦：
  // 全选态必须让 editMode 退出（否则系统会给每行画原生圆圈），
  // 但绝不能把 List 的 selection 绑定摘掉 —— 实测那会让 List 整体重配、滚回顶部。
  const [selectionMode, setSelectionMode] = useState(false)

  // path 导航可能复用同一页面实例，rootPath 必须跟随 path 更新
  useEffect(() => {
    const next = path ?? source.rootPath
    setRootPath(previous => (previous === next ? previous : next))
  }, [path, source.id])

  // 本地浏览页登记自己是「文件」标签页停留的目录，卸载时注销。
  // 挂载列表不登记，所以停在列表时 getLocalTarget() 为空。
  useEffect(() => {
    if (source.kind !== "local") return
    const dir = path ?? source.rootPath
    if (!dir) return
    setLocalSession(localSessionId.current, {
      mountId: source.id,
      mountName: source.name,
      path: dir,
    })
  }, [path, source.id, source.kind, source.name, source.rootPath])

  useEffect(() => {
    const id = localSessionId.current
    return () => clearLocalSession(id)
  }, [])

  // FTP 页登记自己停留的远端目录，供「上传」当目标
  useEffect(() => {
    const connection = source.ftpConnection
    if (source.kind !== "ftp" || !connection) return
    const dir = path ?? source.rootPath
    if (!dir) return
    setRemoteSession(remoteSessionId.current, {
      connection,
      name: source.name,
      path: dir,
    })
  }, [path, source.id, source.kind, source.name, source.rootPath])

  useEffect(() => {
    const id = remoteSessionId.current
    return () => clearRemoteSession(id)
  }, [])

  // 启动时清一次上次拖入遗留的 provider 临时副本（见 dragStage）

  // 普通态的 List selection 变化就是一次 didSelect：立刻取消并执行点击动作
  useEffect(() => {
    if (selectionMode) return
    const selected = selection.value
    if (selected.length !== 1) return
    const entry = (entries ?? []).find(item => item.path === selected[0])
    if (!entry) return
    const timer = setTimeout(() => {
      if (selectionMode) return
      if (selection.value.length !== 1 || selection.value[0] !== selected[0]) return
      handleRowTap(entry)
    }, 0)
    return () => clearTimeout(timer)
  }, [selection.value, selectionMode, entries])

  // 双指手势由系统直接切 editMode；用独立状态再走一次显式动画
  useEffect(() => {
    if (animatedEditing === selectionMode) return
    withAnimation(Animation.smooth({ duration: 0.25 }), () => {
      setAnimatedEditing(selectionMode)
    })
  }, [selectionMode])

  // 系统双指手势会直接激活 editMode：同步成选择态；全选态则把系统编辑态压回去（交给自定义勾选）
  useEffect(() => {
    if (!editMode.value.isEditing) return
    if (selectAllActive) {
      editMode.setValue(EditMode.inactive())
      return
    }
    if (!selectionMode) setSelectionMode(true)
  }, [editMode.value.isEditing, selectAllActive, selectionMode])

  useEffect(() => {
    setTabBarHidden(animatedEditing)
  }, [animatedEditing])

  useEffect(() => {
    return () => {
      // 等返回手势结束再恢复 Tab 栏，避免中途重排打断导航
      setTimeout(() => setTabBarHidden(false), 350)
    }
  }, [])

  // 每次渲染都重新确认数据源；书签被移除 / 密码丢失时即使当前在子目录也直接显示不可用
  const offline = !source.available

  async function load(target: string, showLoading: boolean) {
    if (showLoading) setEntries(undefined)
    setError(null)
    try {
      const list = await withTimeout(
        source.list(target, getShowHiddenFiles()),
        source.readTimeout
      )
      if (!showLoading) animateNextRows.current = true
      setEntries(list)
    } catch (e) {
      const message = e instanceof Error ? e.message : String(e)
      debugLog("browse", `list failed: ${target} ${message}`)
      setError(message)
      setEntries([])
    }
  }

  useEffect(() => {
    if (!rootPath) {
      setEntries(undefined)
      return
    }
    load(rootPath, true)
  }, [rootPath, reloadKey])

  useEffect(() => {
    const subscribe =
      source.kind === "local" ? subscribeTransferChanges : subscribeRemoteChanges
    return subscribe(dirs => {
      if (!rootPath) return
      if (!dirs.some(dir => sameDirectory(dir, rootPath))) return
      if (!pageVisible) {
        setPendingRefresh(true)
        return
      }
      refreshList()
    })
  }, [rootPath, pageVisible, visibleCount, entries, source.kind])

  useEffect(() => {
    if (!pageVisible || !pendingRefresh) return
    setPendingRefresh(false)
    setRefreshKey(key => key + 1)
  }, [pageVisible, pendingRefresh])

  useEffect(() => {
    if (refreshKey === 0 || !rootPath) return
    load(rootPath, false)
  }, [refreshKey])

  useEffect(() => {
    // 静默重读：保留当前列表和滚动位置，避免切换显示 . 开头文件时回顶
    return subscribeShowHidden(() => setRefreshKey(key => key + 1))
  }, [])

  useEffect(() => {
    return subscribeThumbnails(() => setThumbnailsEnabled(getThumbnailsEnabled()))
  }, [])

  useEffect(() => {
    setVisibleCount(PAGE_SIZE)
  }, [rootPath])

  useEffect(() => {
    const list = entries ?? []
    const rows = list
      .slice(0, visibleCount)
      .map((entry, index) => ({ id: entry.path, entry, index }))
    const animate = animateNextRows.current
    animateNextRows.current = false
    if (animate) {
      withAnimation(Animation.smooth({ duration: 0.3 }), () => {
        rowData.setValue(rows)
      })
    } else {
      rowData.setValue(rows)
    }
  }, [entries, visibleCount])

  useEffect(() => {
    if (!pendingScrollPath || !entries) return
    const index = entries.findIndex(entry => entry.path === pendingScrollPath)
    if (index < 0) return
    if (visibleCount < index + 1) {
      setVisibleCount(index + 1)
      return
    }
    const timer = setTimeout(() => {
      const retryDelays = [80, 520]
      retryDelays.forEach(delay => {
        setTimeout(() => {
          withAnimation(Animation.smooth({ duration: 0.4 }), () => {
            scrollProxy.current?.scrollTo(pendingScrollPath, "center")
          })
        }, delay)
      })
      setPendingScrollPath(null)
    }, 100)
    return () => clearTimeout(timer)
  }, [pendingScrollPath, entries, visibleCount])

  const title = path
    ? path.split("/").filter(Boolean).pop() ?? source.name
    : source.name
  const location = source.displayLocation(rootPath)
  const nativeCount = selection.value.length
  const totalCount = entries == null ? null : entries.length
  const headerTitle = (
    <VStack spacing={0} frame={{ maxWidth: 240 }}>
      <Text font="headline" lineLimit={1}>
        {title}
      </Text>
      <SelectionSummary
        total={totalCount}
        nativeCount={nativeCount}
        selectAllActive={selectAllActive}
        store={checkStore}
        editing={animatedEditing}
      />
    </VStack>
  )

  function getSelectedEntries(): FileEntry[] {
    if (selectAllActive) {
      const deselected = checkStore.deselectedPaths()
      return (entries ?? []).filter(entry => !deselected.has(entry.path))
    }
    const selected = new Set(selection.value)
    return (entries ?? []).filter(entry => selected.has(entry.path))
  }

  function openCopyPicker(sources: FileEntry[]) {
    if (!source.supportsTransfer || !source.localMount) return
    setCopySession(session => session + 1)
    setCopySources(sources)
  }

  /** 选完目标目录与操作（复制/移动）后：先问同名冲突，再开始传输。 */
  /** 复制/移动选完目录后：先关 sheet，再逐个问同名冲突。 */
  async function handleTransferPick(
    kind: "copy" | "move",
    items: FileEntry[],
    destDir: string
  ) {
    setCopySources(null)
    endSelection()
    await new Promise<void>(resolve => setTimeout(resolve, 350))
    // 冲突在传输过程中逐个问：包括同名文件夹合并后里面的文件
    let applyAll: ConflictDecision | null = null
    let asked = 0
    const resolve = async (info: { name: string; path: string }) => {
      if (applyAll) return applyAll
      asked += 1
      const decision = await askConflict({
        name: info.name,
        subtitle:
          asked > 1
            ? `目标位置已有同名项目（第 ${asked} 个）`
            : "目标位置已有同名项目",
        showApplyAll: true,
      })
      if (decision.applyAll) applyAll = decision.action
      return decision.action
    }

    startBatchTransfer(
      kind,
      items.map(entry => ({ entry, name: entry.name })),
      destDir,
      refreshList,
      resolve
    )
  }

  function beginSelection() {
    if (!source.writable) return
    setSelectAllActive(false)
    checkStore.clear()
    selection.setValue([])
    setSelectionMode(true)
    withAnimation(Animation.smooth({ duration: 0.25 }), () => {
      editMode.setValue(EditMode.active())
    })
  }

  function endSelection() {
    setSelectAllActive(false)
    checkStore.clear()
    setSelectionMode(false)
    withAnimation(Animation.smooth({ duration: 0.25 }), () => {
      editMode.setValue(EditMode.inactive())
      selection.setValue([])
    })
  }

  function toggleDeselected(entry: FileEntry) {
    checkStore.toggle(entry.path)
  }

  function toggleSelectAll() {
    if (!source.writable || !entries) return
    if (selectAllActive) {
      const allSelected = entries.length > 0 && checkStore.deselectedCount() === 0
      if (allSelected) {
        setSelectAllActive(false)
        checkStore.clear()
        selection.setValue([])
        // 回到系统多选：保持 selection 绑定不变，只重新激活 editMode
        editMode.setValue(EditMode.active())
      } else {
        checkStore.clear()
      }
      return
    }
    selection.setValue([])
    checkStore.clear()
    // 全选用自定义勾选；退出 editMode 让系统不再画圆圈，滚动位置不受影响
    editMode.setValue(EditMode.inactive())
    setSelectAllActive(true)
  }

  function loadMore() {
    if (!entries) return
    setVisibleCount(count => Math.min(count + PAGE_SIZE, entries.length))
  }

  async function confirmDelete(title: string, message: string): Promise<boolean> {
    const index = await Dialog.actionSheet({
      title,
      message,
      cancelButton: true,
      actions: [{ label: "删除", destructive: true }],
    })
    return index === 0
  }

  /** 远程（FTP）删除：一个任务条目，进度按实际下发的命令数计。 */
  async function deleteRemoteItems(items: FileEntry[]) {
    if (!source.remove || items.length === 0) return
    const total = items.length
    const task = startActionTask(
      "delete",
      total === 1 ? items[0].name : `${total} 个项目`
    )
    task.setDetail("正在统计目录…")
    try {
      await source.remove(items, (done, count) => {
        task.setProgress(count > 0 ? done / count : null)
        task.setDetail(`${done} / ${count}`)
      })
      task.finish()
      setToastMessage(
        total === 1 ? `已删除「${items[0].name}」` : `已删除 ${total} 个项目`
      )
      debugLog("ftp", `deleted ${total} item(s)`)
      refreshList()
    } catch (e) {
      task.fail(e)
    }
  }

  async function deleteSelected() {
    if (!source.writable) return
    const items = getSelectedEntries()
    debugLog(
      "select",
      `delete selected count=${items.length} all=${selectAllActive} native=${selection.value.length}`
    )
    await deleteItems(items)
  }

  /** 删除给定的一组项目（单条/多条都走这里）。 */
  async function deleteItems(items: FileEntry[]) {
    if (!source.writable) return
    if (deletingRef.current) return
    if (items.length === 0) return

    const single = items.length === 1
    const confirmed = await confirmDelete(
      single
        ? items[0].isDirectory
          ? "删除文件夹"
          : "删除文件"
        : "删除项目",
      single
        ? `确定删除「${items[0].name}」吗？此操作无法撤销。`
        : `确定删除选中的 ${items.length} 个项目吗？此操作无法撤销。`
    )
    if (!confirmed) return

    if (source.kind === "ftp") {
      deletingRef.current = true
      // 进度看右上角任务中心，不需要把自己锁在多选态
      endSelection()
      try {
        await deleteRemoteItems(items)
      } finally {
        deletingRef.current = false
      }
      return
    }

    startBatchDelete(items, refreshList)
    endSelection()
  }

  /** 下载遇到同名文件时弹框，等用户选覆盖/跳过（可勾全都一样）。同时只展示一个，其余排队。 */
  function askConflict(info: ConflictAsk): Promise<{
    action: ConflictDecision
    applyAll: boolean
  }> {
    return new Promise(resolve => {
      const pending: PendingConflict = { info, resolve }
      if (conflictActive.current) {
        conflictQueue.current.push(pending)
        return
      }
      conflictActive.current = pending
      setConflictPrompt(info)
    })
  }

  function resolveConflict(action: ConflictDecision, applyAll: boolean) {
    const current = conflictActive.current
    if (!current) return
    conflictActive.current = null
    current.resolve({ action, applyAll })
    const next = conflictQueue.current.shift()
    if (next) {
      conflictActive.current = next
      setConflictPrompt(next.info)
    } else {
      setConflictPrompt(null)
    }
  }

  /** 用户下拉/点外部关掉弹窗时，当作跳过。 */
  function dismissConflict() {
    if (conflictActive.current == null) return
    resolveConflict("skip", false)
  }

  /** 把远程项目下载到指定本地目录（调用方负责校验前提）。
   *  同一时间只跑一个下载，其余排队并在任务中心显示「等待中…」。 */
  async function runDownload(items: FileEntry[], targetPath: string) {
    if (items.length === 0) return

    const controller = new AbortController()
    const task = startActionTask(
      "download",
      items.length === 1 ? items[0].name : `${items.length} 个项目`,
      { onCancel: () => cancelTransfer(controller) }
    )
    task.setDetail("等待中…")
    try {
      let applyAll: ConflictDecision | null = null
      let plannedTotal = 0
      let completed = 0
      const updateProgress = (fraction: number) => {
        if (plannedTotal <= 0) {
          task.setProgress(null)
          return
        }
        task.setProgress(
          Math.min(1, (completed + fraction) / plannedTotal)
        )
      }
      const result = await enqueueTransfer(controller, signal => {
        task.setDetail("正在统计目录…")
        return downloadEntriesToDir({
          source,
          entries: items,
          targetDir: targetPath,
          signal,
          onPlan: total => {
            plannedTotal = total
            completed = 0
            updateProgress(0)
            task.setDetail(`0 / ${total}`)
          },
          onProgress: (done, total) => {
            completed = done
            updateProgress(0)
            task.setDetail(`${done} / ${total}`)
          },
          onFileProgress: (fraction, stats) => {
            updateProgress(fraction)
            if (stats)
              task.setDetail(describeFileProgress(stats, completed, plannedTotal))
          },
          onConflict: async info => {
            if (applyAll) return applyAll
            const decision = await askConflict({
              name: info.name,
              subtitle:
                info.total > 1
                  ? `目标目录已有同名文件（${info.index} / ${info.total}）`
                  : "目标目录已有同名文件",
              showApplyAll: info.total > 1,
            })
            if (decision.applyAll) applyAll = decision.action
            return decision.action
          },
        })
      })

      if (result.total === 0) {
        task.fail(new Error("没有可下载的文件"))
        return
      }
      if (result.saved === 0 && result.failed.length > 0) {
        task.fail(new Error(result.failed[0]?.message ?? "下载失败"))
        return
      }

      task.finish()
      const folderName =
        targetPath.split("/").filter(Boolean).pop() ?? "目标目录"
      const skippedText = result.skipped > 0 ? `，跳过 ${result.skipped} 个` : ""
      if (result.saved === 0) {
        setToastMessage(`已跳过 ${result.skipped} 个同名文件`)
      } else {
        setToastMessage(
          `已下载 ${result.saved} 个文件到「${folderName}」${skippedText}`
        )
      }
      debugLog(
        "ftp",
        `downloaded ${result.saved} file(s) to ${targetPath}, skipped ${result.skipped}`
      )

      // 通知「文件」标签页里正停在该目录的浏览页静默重读
      if (result.saved > 0) notifyTransferChanges(result.dirs)

      if (result.failed.length > 0) {
        await Dialog.alert({
          title: "部分文件失败",
          message: `${result.failed.length} 个文件下载失败，例如「${result.failed[0].name}」：${result.failed[0].message}`,
        })
      }
    } catch (e) {
      if (e instanceof DownloadCancelledError) {
        task.cancel()
      } else {
        task.fail(e)
      }
    }
  }

  /** 下载到「文件」标签页停留的目录；没进入目录就提示。 */
  async function downloadToCurrent(items: FileEntry[]) {
    if (source.kind !== "ftp") return
    if (items.length === 0) return

    const target = getLocalTarget()
    if (!target) {
      await Dialog.alert({
        title: "无法下载",
        message: "当前未进入任何本地目录。请先在「文件」标签页里打开一个目录。",
      })
      return
    }
    if (!(await FileManager.exists(target.path))) {
      await Dialog.alert({
        title: "目标目录不可用",
        message: `「${target.path}」已经不存在或无法访问。`,
      })
      return
    }

    // 一点下就开始下载：立刻退出多选态（列表与底部操作栏回家）
    endSelection()
    await runDownload(items, target.path)
  }

  function downloadSelectedToLocal() {
    void downloadToCurrent(getSelectedEntries())
  }

  /**
   * 上传一组本地项目到指定远端目录。
   *
   * 两个入口共用：本地页长按/多选「上传」（目标 = FTP 标签页停留目录），
   * 以及 FTP 页收到拖入（目标 = 当前所在目录）。
   */
  async function runUploadTo(target: RemoteTarget, items: DroppedItem[]) {
    if (items.length === 0) return

    endSelection()
    const controller = new AbortController()
    const task = startActionTask(
      "upload",
      items.length === 1 ? items[0].name : `${items.length} 个项目`,
      { onCancel: () => cancelTransfer(controller) }
    )
    task.setDetail("等待中…")
    try {
      let applyAll: ConflictDecision | null = null
      let plannedTotal = 0
      let completed = 0
      const updateProgress = (fraction: number) => {
        if (plannedTotal <= 0) {
          task.setProgress(null)
          return
        }
        task.setProgress(Math.min(1, (completed + fraction) / plannedTotal))
      }
      const result = await enqueueTransfer(controller, signal => {
        task.setDetail("正在统计文件…")
        return uploadEntriesToDir({
          connection: target.connection,
          // 上传只用 path / name，拖入的项目没有 size / modifiedAt
          entries: items.map(item => ({ ...item, size: 0, modifiedAt: 0 })),
          targetDir: target.path,
          signal,
          onPlan: total => {
            plannedTotal = total
            completed = 0
            updateProgress(0)
            task.setDetail(`0 / ${total}`)
          },
          onProgress: (done, total) => {
            completed = done
            updateProgress(0)
            task.setDetail(`${done} / ${total}`)
          },
          onFileProgress: (fraction, _stats: UploadFileStats | undefined) => {
            // 上传进度只有块边界能拿到，不显示速度与剩余时间
            updateProgress(fraction)
          },
          onConflict: async info => {
            if (applyAll) return applyAll
            const decision = await askConflict({
              name: info.name,
              subtitle:
                info.total > 1
                  ? `FTP 目录已有同名文件（${info.index} / ${info.total}）`
                  : "FTP 目录已有同名文件",
              showApplyAll: info.total > 1,
            })
            if (decision.applyAll) applyAll = decision.action
            return decision.action
          },
        })
      })

      if (result.total === 0) {
        task.fail(new Error("没有可上传的文件"))
        return
      }
      if (result.uploaded === 0 && result.failed.length > 0) {
        task.fail(new Error(result.failed[0]?.message ?? "上传失败"))
        return
      }

      task.finish()
      // 全部成功才删 provider 临时副本；有失败就留着，等启动时兜底清理（避免把还能重试的副本删了）
      if (result.failed.length === 0) {
        for (const item of items) removeProviderTempCopy(item.path)
      }
      const folderName = target.path.split("/").filter(Boolean).pop() ?? target.name
      const skippedText = result.skipped > 0 ? `，跳过 ${result.skipped} 个` : ""
      if (result.uploaded === 0) {
        setToastMessage(`已跳过 ${result.skipped} 个同名文件`)
      } else {
        setToastMessage(
          `已上传 ${result.uploaded} 个文件到「${folderName}」${skippedText}`
        )
      }
      debugLog(
        "ftp",
        `uploaded ${result.uploaded} file(s) to ${target.path}, skipped ${result.skipped}`
      )

      if (result.uploaded > 0) notifyRemoteChanges(result.dirs)

      if (result.failed.length > 0) {
        await Dialog.alert({
          title: "部分文件失败",
          message: `${result.failed.length} 个文件上传失败，例如「${result.failed[0].name}」：${result.failed[0].message}`,
        })
      }
    } catch (e) {
      if (e instanceof UploadCancelledError || e instanceof DownloadCancelledError) {
        task.cancel()
      } else {
        task.fail(e)
      }
    }
  }

  /** 上传本地项目到「FTP」标签页停留的目录。 */
  async function uploadToRemote(items: FileEntry[]) {
    if (source.kind !== "local") return
    if (items.length === 0) return

    const target = getRemoteTarget()
    if (!target) {
      await Dialog.alert({
        title: "无法上传",
        message: "当前未进入任何 FTP 目录。请先在「FTP」标签页里打开一个目录。",
      })
      return
    }

    await runUploadTo(target, items)
  }

  /** FTP 页收到拖入：直接传到当前所在目录（效果同「上传」）。 */
  async function uploadDroppedHere(items: DroppedItem[]) {
    if (items.length === 0) return
    const connection = source.ftpConnection
    const targetPath = rootPath
    if (!connection || !targetPath) {
      setToastMessage("当前未进入任何 FTP 目录")
      return
    }
    await runUploadTo(
      { connection, name: source.name, path: targetPath },
      items
    )
  }

  /** 选一个挂载目录，下载到它的根目录。 */
  function openMountPicker(items: FileEntry[]) {
    if (source.kind !== "ftp") return
    if (items.length === 0) return
    setDownloadSession(session => session + 1)
    setDownloadSources(items)
  }

  /** 挂载表里选完并确认后：关表、退出多选、开始下载。 */
  async function handleMountPick(root: string) {
    const items = downloadSources
    setDownloadSources(null)
    if (!items || items.length === 0) return
    endSelection()
    await new Promise<void>(resolve => setTimeout(resolve, 350))

    if (!(await FileManager.exists(root))) {
      await Dialog.alert({
        title: "目标目录不可用",
        message: `「${root}」已经不存在或无法访问。`,
      })
      return
    }
    await runDownload(items, root)
  }

  /**
   * FTP 页的落点（右下角圆形按钮 / 路径胶囊那一带）。
   *
   * 只会从脚本外部拖入：把文件上传到当前远端目录，走与「上传」同一套流程。
   * 本地挂载页不再接收拖放，也不再作为拖拽源（内部拖放已删）。
   */
  function handleDrop(attachments: ItemProvider[]): boolean {
    debugLog("drag", `drop kind=${source.kind} attachments=${attachments.length}`)
    if (source.kind !== "ftp" || !source.ftpConnection || !rootPath) {
      setToastMessage("当前未进入任何 FTP 目录")
      return false
    }
    // 加载必须在 perform 的同步作用域里开始
    void resolveAttachments(attachments).then(items => {
      debugLog(
        "drag",
        `resolved ${items.length}/${attachments.length} names=${items.slice(0, 3).map(item => item.name).join(" | ")}`
      )
      if (items.length === 0) {
        void Dialog.alert({
          title: "无法读取拖入的内容",
          message: "没有拿到可用的文件或文件夹。",
        })
        return
      }
      void uploadDroppedHere(items)
    })
    return true
  }

  const plusDropHover = useObservable(false)
  const stripDropHover = useObservable(false)

  /**
   * 顶部路径胶囊条那一块的落点（仅 FTP 页）。
   *
   * 实机验证：List 内部的滚动区域不认拖放（onDropContent / onDrop / 行级都试过），
   * 但根容器这一层在导航栏下方那条（路径胶囊周围）是能接的。
   */
  const stripDropProps = {
    types: ["public.item", "public.file-url"] as UTType[],
    isTarget: stripDropHover,
    perform: handleDrop,
  }

  function refreshList() {
    const now = Date.now()
    if (now - lastRefreshAt.current < 250) return
    lastRefreshAt.current = now
    setRefreshKey(key => key + 1)
  }

  function retry() {
    setRootPath(path == null ? source.rootPath : path)
    setReloadKey(key => key + 1)
  }

  function openFolder(entry: FileEntry) {
    if (!navPath) return
    selection.setValue([])
    navPath.setValue([...navPath.value, encodeRoute(source.id, entry.path)])
  }

  function handleRowTap(entry: FileEntry) {
    const now = Date.now()
    if (now - lastRowTapAt < 250) return
    lastRowTapAt = now
    if (entry.isDirectory) openFolder(entry)
    else previewFile(entry)
  }

  function beginBusy(state: BusyState | null): boolean {
    if (busyRef.current) return false
    busyRef.current = true
    setBusy(state)
    return true
  }

  function updateBusy(patch: Partial<BusyState>): void {
    setBusy(prev => (prev ? { ...prev, ...patch } : prev))
  }

  function endBusy(): void {
    busyRef.current = false
    setBusy(null)
  }

  async function previewFile(entry: FileEntry) {
    if (!beginBusy({ title: `正在下载「${entry.name}」…` })) return
    selection.setValue([])
    let cleanup: (() => void) | undefined
    try {
      const prepared = await source.preparePreview(entry)
      cleanup = prepared.cleanup
      setBusy(null)
      await QuickLook.previewURLs([prepared.path])
    } catch (e) {
      debugLog("browse", `preview failed: ${entry.path} ${String(e)}`)
      await Dialog.alert({
        title: "无法预览",
        message: String(e),
      })
    } finally {
      endBusy()
      cleanup?.()
    }
  }

  /** 保存图片/视频到系统相册（FTP 先完整缓存，不限大小；进度只在任务中心显示）。 */
  async function saveEntryToAlbum(entry: FileEntry) {
    const kind = thumbnailKind(entry)
    if (!kind) return
    const downloading = source.kind === "ftp"
    const controller = downloading ? new AbortController() : null
    // 保存到相册是纯后台任务：不占模态、不被其它下载阻塞，进度与取消只在任务中心
    // 取消是异步生效的（分块之间才检查），所以取消请求后要停止刷新进度，
    // 否则会把任务中心的「正在取消…」覆盖掉
    let cancelling = false
    const requestCancel = () => {
      if (cancelling) return
      cancelling = true
      if (controller) cancelTransfer(controller)
    }
    const task = startActionTask("save", entry.name, {
      onCancel: controller ? requestCancel : undefined,
    })
    task.setDetail(downloading ? "等待中…" : "正在保存…")
    task.setDetail(downloading ? "正在下载…" : "正在保存…")
    let cleanup: (() => void) | undefined
    try {
      const prepared = controller
        ? await enqueueTransfer(controller, signal =>
            source.preparePreview(entry, {
              // 大小与时长都不限制，先完整缓存再交给系统相册
              mode: "share",
              signal,
              onProgress: (loaded, total) => {
                if (cancelling) return
                task.setProgress(total > 0 ? Math.min(1, loaded / total) : null)
                task.setDetail(
                  total > 0
                    ? `${formatSize(loaded)} / ${formatSize(total)}`
                    : formatSize(loaded)
                )
              },
            })
          )
        : await source.preparePreview(entry, { mode: "share" })
      cleanup = prepared.cleanup
      if (cancelling) return
      task.setDetail("正在写入相册…")
      const ok =
        kind === "video"
          ? await Photos.saveVideo(prepared.path)
          : await Photos.savePhoto(prepared.path)
      if (!ok) {
        throw new Error(
          "系统未能保存这个项目。请在「设置 › 隐私与安全性 › 照片」中确认本 App 有添加照片的权限。"
        )
      }
      task.finish()
      setToastMessage(`已保存「${entry.name}」到相册`)
      debugLog("share", `saved to photos ${entry.path}`)
    } catch (e) {
      if (e instanceof DownloadCancelledError) {
        task.cancel()
        return
      }
      const message = e instanceof Error ? e.message : String(e)
      task.fail(e)
      debugLog("share", `save to photos failed: ${entry.path} ${message}`)
      await Dialog.alert({ title: "保存到相册失败", message })
    } finally {
      cleanup?.()
    }
  }

  /**
   * 调系统共享面板。选中的**文件与文件夹原样共享**。
   *
   * 本地：直接把原路径当 file URL 交给面板，不复制。
   * FTP：没有本地文件，先把选中的项目（含目录树）下载到暂存目录，
   * 下载期间屏幕中显示模态进度 + 取消，完成后弹面板，面板关闭后删暂存。
   */
  async function shareEntries(list: FileEntry[]) {
    if (list.length === 0) return

    const downloading = source.kind === "ftp"
    const multi = list.length > 1
    const controller = downloading ? new AbortController() : null
    // 取消不能立即生效（分块之间才检查），所以置位后停止刷新进度，
    // 让模态与任务中心一直显示「正在取消…」直到真的停下
    let cancelling = false
    const requestCancel = () => {
      if (cancelling) return
      cancelling = true
      if (controller) cancelTransfer(controller)
      updateBusy({ title: "正在取消…", detail: undefined, onCancel: undefined })
    }
    const firstTitle = multi
      ? `正在准备 ${list.length} 个项目…`
      : `正在准备「${list[0].name}」…`
    if (
      !beginBusy(
        downloading ? { title: firstTitle, onCancel: requestCancel } : null
      )
    ) {
      return
    }

    const task = startActionTask(
      "share",
      multi ? `${list.length} 个项目` : list[0].name,
      { onCancel: controller ? requestCancel : undefined }
    )

    // 本地：原路径直接给面板（文件和文件夹都可以）
    if (!downloading) {
      try {
        for (const item of list) {
          if (!(await FileManager.exists(item.path))) {
            throw new Error(`「${item.name}」已经不存在或无法访问。`)
          }
        }
        const completed = await ShareSheet.present(list.map(item => item.path))
        if (completed) task.finish()
        else task.cancel("已取消共享")
      } catch (e) {
        const message = e instanceof Error ? e.message : String(e)
        task.fail(e)
        await Dialog.alert({ title: "无法共享", message })
      } finally {
        endBusy()
      }
      return
    }

    // FTP：单个文件走预览缓存（可复用），多项目或含目录则整堆下载到暂存目录
    const stageDir = shareStageRoot() + "/" + Date.now()
    const cleanups: Array<() => void> = []
    let usedStage = false

    try {
      let paths: string[] = []

      if (list.length === 1 && !list[0].isDirectory) {
        const file = list[0]
        task.setDetail("等待中…")
        const prepared = await enqueueTransfer(
          controller!,
          signal => {
            if (!cancelling) task.setDetail(`正在下载「${file.name}」`)
            return source.preparePreview(file, {
              mode: "share",
              signal,
              onProgress: (loaded, total) => {
                if (cancelling) return
                const text =
                  total > 0
                    ? `${formatSize(loaded)} / ${formatSize(total)}`
                    : formatSize(loaded)
                task.setProgress(total > 0 ? Math.min(1, loaded / total) : null)
                task.setDetail(`正在下载「${file.name}」 ${text}`)
                updateBusy({ detail: text })
              },
            })
          },
          () => updateBusy({ title: "排队等待中…", detail: undefined })
        )
        if (prepared.cleanup) cleanups.push(prepared.cleanup)
        if (!(await FileManager.exists(prepared.path))) {
          throw new Error(`「${file.name}」还没有下载到本地，无法共享。`)
        }
        paths = [prepared.path]
      } else {
        usedStage = true
        await FileManager.createDirectory(stageDir, true)
        let done = 0
        let totalFiles = 0
        task.setDetail("等待中…")
        const result = await enqueueTransfer(controller!, signal =>
          downloadEntriesToDir({
            source,
            entries: list,
            targetDir: stageDir,
            signal,
            onPlan: total => {
              if (cancelling) return
              totalFiles = total
              task.setDetail(`0 / ${total} 个文件`)
            },
            onName: name => {
              if (cancelling) return
              updateBusy({ title: `正在下载「${name}」`, detail: undefined })
              task.setDetail(`正在下载「${name}」`)
            },
            onProgress: (count, total) => {
              if (cancelling) return
              done = count
              task.setProgress(total > 0 ? Math.min(1, count / total) : null)
              task.setDetail(`${count} / ${total} 个文件`)
              updateBusy({ detail: `${count} / ${total} 个文件` })
            },
            onFileProgress: (fraction, stats) => {
              if (cancelling || !stats) return
              const text =
                stats.total > 0
                  ? `${formatSize(stats.loaded)} / ${formatSize(stats.total)}`
                  : formatSize(stats.loaded)
              // 模态与任务中心同步：按“已完成文件数 + 当前文件比例”算总进度
              if (totalFiles > 0) {
                task.setProgress(Math.min(1, (done + fraction) / totalFiles))
                task.setDetail(`${done} / ${totalFiles} 个文件 · ${text}`)
              }
              updateBusy({
                detail: `${done} / ${totalFiles} 个文件 · ${text}`,
              })
            },
            // 暂存目录是新建的，正常不会冲突；同名就覆盖
            onConflict: async () => "overwrite",
          })
        ,
          () => updateBusy({ title: "排队等待中…", detail: undefined })
        )
        if (result.failed.length > 0) {
          throw new Error(
            `${result.failed.length} 个项目下载失败，例如「${result.failed[0].name}」：${result.failed[0].message}`
          )
        }
        paths = list
          .map(item => stageDir + "/" + item.name)
          .filter(path => FileManager.existsSync(path))
        if (paths.length === 0) {
          throw new Error("选中的项目里没有可共享的内容（空文件夹会被跳过）。")
        }
      }

      if (controller?.signal.aborted) throw new DownloadCancelledError()

      updateBusy({ title: "正在打开共享面板…", detail: undefined })
      task.setDetail("等待共享面板…")
      const completed = await ShareSheet.present(paths)
      if (completed) task.finish()
      else task.cancel("已取消共享")
    } catch (e) {
      if (e instanceof DownloadCancelledError || controller?.signal.aborted) {
        task.cancel()
        return
      }
      const message = e instanceof Error ? e.message : String(e)
      task.fail(e)
      debugLog("share", `share failed: ${message}`)
      await Dialog.alert({ title: "无法共享", message })
    } finally {
      endBusy()
      for (const cleanup of cleanups) cleanup()
      if (usedStage) {
        await FileManager.remove(stageDir).catch(() => {})
      }
    }
  }

  async function renameEntry(entry: FileEntry) {
    if (!source.writable) return
    const value = await Dialog.prompt({
      title: entry.isDirectory ? "重命名文件夹" : "重命名文件",
      message: entry.isDirectory
        ? "只修改名称，不会移动其中的内容。"
        : "只修改名称，不会移动文件。",
      defaultValue: entry.name,
      placeholder: "名称",
      selectAll: true,
      confirmLabel: "保存",
      cancelLabel: "取消",
    })
    if (value == null) return

    const name = value.trim()
    if (!name || name === entry.name) return
    if (name.includes("/") || name === "." || name === "..") {
      await Dialog.alert({ title: "名称无效", message: "名称不能包含“/”。" })
      return
    }

    const oldParts = splitExtension(entry.name)
    const newParts = splitExtension(name)
    let finalName = name

    if (!entry.isDirectory && oldParts.ext.toLowerCase() !== newParts.ext.toLowerCase()) {
      const keep = await Dialog.confirm({
        title: `要将文件扩展名从 ${extensionLabel(oldParts.ext)} 更改为 ${extensionLabel(newParts.ext)} 吗？`,
        message: `如果进行这项更改，你的文件“${name}”可能会由另一个应用程序打开。`,
        confirmLabel: `保留 ${extensionLabel(oldParts.ext)}`,
        cancelLabel: `使用 ${extensionLabel(newParts.ext)}`,
      })
      // 保留原扩展名，但采用新输入的主文件名
      if (keep) finalName = newParts.base + oldParts.ext
      if (finalName === entry.name) return
    }

    const dir = entry.path.slice(0, entry.path.lastIndexOf("/"))
    const newPath = dir + "/" + finalName
    try {
      if (source.kind === "ftp") {
        if (!source.rename) return
        await source.rename(entry, finalName)
        debugLog("browse", `renamed remote ${entry.path} -> ${finalName}`)
        setRefreshKey(key => key + 1)
        return
      }
      if (await FileManager.exists(newPath)) {
        await Dialog.alert({ title: "已存在同名项目", message: `「${finalName}」已经存在。` })
        return
      }
      await FileManager.rename(entry.path, newPath)
      debugLog("browse", `renamed ${entry.path} -> ${newPath}`)
      setRefreshKey(key => key + 1)
    } catch (e) {
      debugLog("browse", `rename failed: ${entry.path} ${String(e)}`)
      await Dialog.alert({ title: "重命名失败", message: String(e) })
    }
  }

  async function createFolder() {
    if (!source.writable || !rootPath) return

    const value = await Dialog.prompt({
      title: "新建文件夹",
      message: "在当前目录中创建文件夹。",
      defaultValue: "新建文件夹",
      placeholder: "文件夹名称",
      selectAll: true,
      confirmLabel: "创建",
      cancelLabel: "取消",
    })
    if (value == null) return

    const name = value.trim()
    if (!name || name === "." || name === "..") {
      await Dialog.alert({ title: "名称无效", message: "请输入有效的文件夹名称。" })
      return
    }
    if (name.includes("/")) {
      await Dialog.alert({ title: "名称无效", message: "名称不能包含“/”。" })
      return
    }

    const base = rootPath.replace(/\/+$/, "")
    const target = `${base}/${name}`
    try {
      if (source.kind === "ftp") {
        if (!source.createDirectory) return
        await source.createDirectory(target)
        debugLog("browse", `created remote folder ${target}`)
        await load(rootPath, false)
        setPendingScrollPath(target)
        return
      }
      if (await FileManager.exists(target)) {
        await Dialog.alert({ title: "已存在同名项目", message: `「${name}」已经存在。` })
        return
      }
      await FileManager.createDirectory(target, false)
      debugLog("browse", `created folder ${target}`)
      await load(rootPath, false)
      setPendingScrollPath(target)
    } catch (e) {
      debugLog("browse", `create folder failed: ${target} ${String(e)}`)
      await Dialog.alert({ title: "新建文件夹失败", message: String(e) })
    }
  }

  async function deleteEntry(entry: FileEntry) {
    if (!source.writable) return
    const confirmed = await confirmDelete(
      entry.isDirectory ? "删除文件夹" : "删除文件",
      `确定删除「${entry.name}」吗？此操作无法撤销。`
    )
    if (!confirmed) return

    debugLog("select", `delete entry ${entry.path}`)
    if (source.kind === "ftp") {
      await deleteRemoteItems([entry])
      return
    }
    startDelete(entry, refreshList)
  }

  /**
   * 行长按菜单：只作用于这一行（多选态下也一样）。
   * 批量动作只走底部的多选操作栏，不在长按菜单里做。
   */
  function renderRowMenu(entry: FileEntry) {
    return (
      <Group>
        {source.kind === "local" ? (
          <Button
            title="上传"
            systemImage="arrow.up.circle"
            action={() => uploadToRemote([entry])}
          />
        ) : null}
        {source.kind === "ftp" ? (
          <Button
            title="下载到挂载"
            systemImage="arrow.down.circle"
            action={() => openMountPicker([entry])}
          />
        ) : null}
        {source.kind === "ftp" ? (
          <Button
            title="下载到当前"
            systemImage="arrow.down.to.line"
            action={() => downloadToCurrent([entry])}
          />
        ) : null}
        {source.supportsTransfer ? (
          <Button
            title="复制/移动"
            systemImage="doc.on.doc"
            action={() => openCopyPicker([entry])}
          />
        ) : null}
        <Button
          title="共享"
          systemImage="square.and.arrow.up"
          action={() => void shareEntries([entry])}
        />
        {source.writable ? (
          <Button
            title="重命名"
            systemImage="pencil"
            action={() => renameEntry(entry)}
          />
        ) : null}
        {thumbnailKind(entry) ? (
          <Button
            title="保存到相册"
            systemImage="square.and.arrow.down"
            action={() => saveEntryToAlbum(entry)}
          />
        ) : null}
        <Button
          title="详情"
          systemImage="info.circle"
          action={() => setDetailEntry(entry)}
        />
        {source.writable ? (
          <Button
            title="删除"
            systemImage="trash"
            tint="red"
            action={() => void deleteEntry(entry)}
          />
        ) : null}
      </Group>
    )
  }

  if (offline || rootPath === null) {
    return (
      <List
        navigationTitle={title}
        navigationBarTitleDisplayMode="inline"
        toolbar={{
          topBarLeading: <CloseButton onClose={onClose} />,
          topBarTrailing: <TransferStatusButton />,
        }}
      >
        <Section>
          <UnavailableView
            title={source.unavailableTitle}
            message={source.unavailableMessage}
            onRetry={retry}
          />
        </Section>
      </List>
    )
  }

  return (
    <ZStack
      alignment="bottom"
      frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
      onDropContent={source.kind === "ftp" ? stripDropProps : undefined}
      toast={{
        isPresented: toastMessage != null,
        onChanged: open => {
          if (!open) setToastMessage(null)
        },
        message: toastMessage ?? "",
        duration: 2,
        position: "bottom",
      }}
      sheet={[
        {
          isPresented: detailEntry != null,
          onChanged: open => {
            if (!open) setDetailEntry(null)
          },
          content: detailEntry ? (
            <DetailsSheet
              entry={detailEntry}
              remote={source.kind !== "local"}
              listRemote={
                source.kind === "ftp"
                  ? path => source.list(path, true)
                  : undefined
              }
              onClose={() => setDetailEntry(null)}
            />
          ) : (
            <Text> </Text>
          ),
        },
        {
          isPresented: conflictPrompt != null,
          onChanged: open => {
            if (!open) dismissConflict()
          },
          content: conflictPrompt ? (
            <OverwritePrompt
              key={conflictPrompt.name + conflictPrompt.subtitle}
              name={conflictPrompt.name}
              subtitle={conflictPrompt.subtitle}
              showApplyAll={conflictPrompt.showApplyAll}
              onDecision={resolveConflict}
            />
          ) : (
            <Text> </Text>
          ),
        },
      ]}
    >
      <ScrollViewReader>
        {proxy => {
          scrollProxy.current = proxy
          return (
      <List
        navigationTitle={title}
        navigationBarTitleDisplayMode="inline"
        safeAreaInset={{
          top: {
            spacing: 0,
            content: (
              <HStack
                padding={{ top: 2, bottom: 6 }}
                frame={{ maxWidth: "infinity" }}
              >
                <Spacer />
                <HStack
                  padding={{ horizontal: 12, vertical: 6 }}
                  glassEffect={{
                    glass: UIGlass.regular(),
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                >
                  <Text
                    font="footnote"
                    foregroundStyle="secondaryLabel"
                    lineLimit={1}
                    truncationMode="head"
                  >
                    {location}
                  </Text>
                </HStack>
                <Spacer />
              </HStack>
            ),
          },
        }}
        contentMargins={{
          edges: "vertical",
          insets: {
            top: 0,
            leading: 0,
            bottom: animatedEditing ? 110 : 0,
            trailing: 0,
          },
          placement: "scrollContent",
        }}
        selection={selection}
        environments={source.writable ? { editMode } : undefined}
        onAppear={() => setPageVisible(true)}
        onDisappear={() => setPageVisible(false)}
        toolbar={
        animatedEditing
          ? {
              principal: headerTitle,
              topBarLeading: (
                <SelectAllButton
                  total={entries?.length ?? 0}
                  nativeCount={nativeCount}
                  selectAllActive={selectAllActive}
                  store={checkStore}
                  onToggle={toggleSelectAll}
                />
              ),
              topBarTrailing: (
                <HStack spacing={8}>
                  <TransferStatusButton />
                  <Button title="完成" action={endSelection} />
                </HStack>
              ),
            }
          : {
              principal: headerTitle,
              topBarLeading: <CloseButton onClose={onClose} />,
              topBarTrailing: (
                <HStack spacing={8}>
                  <TransferStatusButton />
                  <SettingsMenu
                    onSelect={
                      source.writable && entries && entries.length > 0
                        ? beginSelection
                        : undefined
                    }
                  />
                </HStack>
              ),
            }
      }
      sheet={[
        {
          isPresented: copySources != null,
          onChanged: open => {
            if (!open) setCopySources(null)
          },
          content:
            copySources && source.localMount ? (
              <DestinationPicker
                key={copySession}
                sources={copySources}
                startMount={source.localMount}
                startPath={path ?? rootPath ?? ""}
                onClose={() => setCopySources(null)}
                onConfirm={handleTransferPick}
              />
            ) : (
              <Text> </Text>
            ),
        },
        {
          isPresented: downloadSources != null,
          onChanged: open => {
            if (!open) setDownloadSources(null)
          },
          content: downloadSources ? (
            <MountPickerSheet
              key={`download-${downloadSession}`}
              onClose={() => setDownloadSources(null)}
              onPick={(_mount, root) => {
                void handleMountPick(root)
              }}
            />
          ) : (
            <Text> </Text>
          ),
        },
      ]}
      refreshable={async () => {
        if (rootPath) await load(rootPath, false)
      }}
    >
      <Section>
        {error != null ? (
          <UnavailableView title="读取失败" message={error} onRetry={retry} />
        ) : entries === undefined ? (
          <HStack spacing={10} padding={{ vertical: 20 }} frame={{ maxWidth: "infinity" }}>
            <ProgressView />
            <Text foregroundStyle="secondaryLabel">正在读取…</Text>
          </HStack>
        ) : entries.length === 0 ? (
          <VStack spacing={8} padding={{ vertical: 24 }} frame={{ maxWidth: "infinity" }}>
            <Image systemName="folder" font="largeTitle" foregroundStyle="secondaryLabel" />
            <Text foregroundStyle="secondaryLabel">空文件夹</Text>
          </VStack>
        ) : (
        <Group>
          <ForEach
            data={rowData}
          builder={row => {
            const entry = row.entry
            const isLastLoaded =
              rowData.value.length > 0 &&
              row.id === rowData.value[rowData.value.length - 1].id
            const loadMoreOnAppear =
              isLastLoaded && entries != null && visibleCount < entries.length
                ? loadMore
                : undefined

            return (
              <VStack
                key={row.id}
                spacing={0}
                frame={{ maxWidth: "infinity" }}
                contentShape="rect"
                listRowBackground={
                  selectAllActive ? (
                    <RowHighlight store={checkStore} path={entry.path} />
                  ) : undefined
                }
                onTapGesture={
                  selectAllActive ? () => toggleDeselected(entry) : undefined
                }
                contextMenu={{ menuItems: renderRowMenu(entry) }}
              >
                <FileRow
                  entry={entry}
                  onAppear={loadMoreOnAppear}
                  showChevron={entry.isDirectory && !animatedEditing}
                  interactive={selectAllActive}
                  checkable={selectAllActive}
                  checkStore={checkStore}
                  thumbnailsEnabled={thumbnailsEnabled && source.supportsThumbnails}
                  preloadThumbnail={
                    source.supportsThumbnails && row.index < PRELOAD_ROWS
                  }
                />
              </VStack>
            )
          }}
          />
          {!animatedEditing && visibleCount < entries.length ? (
            <HStack
              spacing={8}
              padding={{ vertical: 18 }}
              frame={{ maxWidth: "infinity" }}
            >
              <ProgressView />
              <Text font="footnote" foregroundStyle="secondaryLabel">
                正在加载更多…
              </Text>
            </HStack>
          ) : null}
        </Group>
      )}
      </Section>
      </List>
          )
        }}
      </ScrollViewReader>
      {source.writable && !animatedEditing && !selectAllActive ? (
        <VStack
          spacing={0}
          frame={{
            maxWidth: "infinity",
            maxHeight: "infinity",
            alignment: "bottomTrailing",
          }}
        >
          <VStack spacing={0} padding={{ trailing: 20, bottom: 20 }}>
            <VStack
              spacing={0}
              frame={{ width: 56, height: 56 }}
              contentShape="capsule"
              glassEffect={{
                glass: UIGlass.regular(),
                shape: { type: "capsule", style: "continuous" },
              }}
              onTapGesture={createFolder}
              onDropContent={
                source.kind === "ftp"
                  ? {
                      types: ["public.item", "public.file-url"] as UTType[],
                      isTarget: plusDropHover,
                      perform: handleDrop,
                    }
                  : undefined
              }
            >
              <Image
                systemName={plusDropHover.value ? "arrow.down.to.line" : "plus"}
                font="title2"
                foregroundStyle={plusDropHover.value ? "systemBlue" : "label"}
              />
            </VStack>
          </VStack>
        </VStack>
      ) : null}
      {animatedEditing && source.writable ? (
        <SelectionActionBar
          total={entries?.length ?? 0}
          nativeCount={nativeCount}
          selectAllActive={selectAllActive}
          store={checkStore}
          actions={[
            ...(source.kind === "ftp"
              ? [
                  {
                    id: "download",
                    title: "下载到挂载",
                    systemImage: "arrow.down.circle",
                    action: () => {
                      const items = getSelectedEntries()
                      if (items.length > 0) openMountPicker(items)
                    },
                  },
                  {
                    id: "downloadHere",
                    title: "下载到当前",
                    systemImage: "arrow.down.to.line",
                    action: downloadSelectedToLocal,
                  },
                ]
              : []),
            ...(source.kind === "local"
              ? [
                  {
                    id: "upload",
                    title: "上传",
                    systemImage: "arrow.up.circle",
                    action: () => {
                      const items = getSelectedEntries()
                      if (items.length > 0) uploadToRemote(items)
                    },
                  },
                ]
              : []),
            ...(source.supportsTransfer
              ? [
                  {
                    id: "transfer",
                    title: "复制/移动",
                    systemImage: "doc.on.doc",
                    action: () => {
                      const items = getSelectedEntries()
                      if (items.length > 0) openCopyPicker(items)
                    },
                  },
                ]
              : []),
            {
              id: "share",
              title: "共享",
              systemImage: "square.and.arrow.up",
              action: () => {
                const items = getSelectedEntries()
                if (items.length > 0) shareEntries(items)
              },
            },
            {
              id: "delete",
              title: "删除",
              systemImage: "trash",
              action: deleteSelected,
            },
          ]}
        />
      ) : null}
      {busy ? (
        <VStack
          spacing={10}
          padding={24}
          frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
          contentShape="rect"
          onTapGesture={() => {}}
        >
          <VStack
            spacing={10}
            padding={{ horizontal: 22, vertical: 16 }}
            glassEffect={{
              glass: UIGlass.regular(),
              shape: { type: "rect", cornerRadius: 14 },
            }}
          >
            <ProgressView />
            <Text font="footnote" lineLimit={2} frame={{ maxWidth: 260 }}>
              {busy.title}
            </Text>
            {busy.detail ? (
              <Text font="caption2" foregroundStyle="secondaryLabel">
                {busy.detail}
              </Text>
            ) : null}
            {busy.onCancel ? (
              <Button
                title="取消"
                role="cancel"
                action={busy.onCancel}
                font="footnote"
              />
            ) : null}
          </VStack>
        </VStack>
      ) : null}
    </ZStack>
  )
}
