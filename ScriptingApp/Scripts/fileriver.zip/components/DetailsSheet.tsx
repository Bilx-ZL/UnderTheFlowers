import {
  Button,
  LabeledContent,
  List,
  NavigationStack,
  Section,
  Text,
  VStack,
  useEffect,
  useState,
} from "scripting"
import { FileEntry } from "../types"
import { formatSize } from "../services/localfs"
import { getRecursiveFtpFolderStats } from "../services/settings"
import { HASH_ALGORITHMS, hashFile, type HashAlgorithm } from "../services/hash"

type StatInfo = {
  creationDate: number
  modificationDate: number
  type: string
  size: number
}

type FolderSize = {
  bytes: number
  files: number
  directories: number
}

function joinPath(dir: string, name: string): string {
  return dir.endsWith("/") ? `${dir}${name}` : `${dir}/${name}`
}

async function calculateFolderSize(
  root: string,
  active: () => boolean
): Promise<FolderSize> {
  let bytes = 0
  let files = 0
  let directories = 0

  async function walk(dir: string): Promise<void> {
    if (!active()) return
    let children: string[] = []
    try {
      children = await FileManager.readDirectory(dir)
    } catch {
      return
    }

    for (const child of children) {
      if (!active()) return
      if (child === "." || child === "..") continue

      const path = joinPath(dir, child)
      try {
        const stat = await FileManager.stat(path)
        const type = String(stat.type ?? "").toLowerCase()
        if (type === "directory" || type.endsWith("directory")) {
          directories += 1
          await walk(path)
        } else {
          files += 1
          bytes += stat.size ?? 0
        }
      } catch {
        // 单个项目无权限或已消失时跳过，继续统计其余内容
      }
    }
  }

  await walk(root)
  return { bytes, files, directories }
}

const MAX_REMOTE_DEPTH = 32

async function calculateRemoteFolderSize(
  list: (path: string) => Promise<FileEntry[]>,
  root: string,
  active: () => boolean
): Promise<FolderSize> {
  let bytes = 0
  let files = 0
  let directories = 0
  const visited = new Set<string>()

  async function walk(dir: string, depth: number): Promise<void> {
    if (!active() || depth > MAX_REMOTE_DEPTH || visited.has(dir)) return
    visited.add(dir)

    let children: FileEntry[] = []
    try {
      children = await list(dir)
    } catch {
      return
    }

    for (const child of children) {
      if (!active()) return
      if (child.name === "." || child.name === "..") continue
      if (child.isDirectory) {
        directories += 1
        await walk(child.path, depth + 1)
      } else {
        files += 1
        bytes += child.size ?? 0
      }
    }
  }

  await walk(root, 0)
  return { bytes, files, directories }
}

function formatDetailDate(timestamp: number): string {
  if (!timestamp) return "—"
  const date = new Date(timestamp)
  const pad = (value: number) => (value < 10 ? `0${value}` : String(value))
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(
    date.getDate()
  )} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`
}

function formatDetailSize(bytes: number): string {
  if (bytes === 0) return "0 B"
  return formatSize(bytes) || `${bytes} 字节`
}

function LongValue({ label, value }: { label: string; value: string }) {
  return (
    <VStack alignment="leading" spacing={4} padding={{ vertical: 4 }}>
      <Text font="footnote" foregroundStyle="secondaryLabel">
        {label}
      </Text>
      <Text font="body" textSelection={true}>
        {value}
      </Text>
    </VStack>
  )
}

export function DetailsSheet({
  entry,
  onClose,
  remote = false,
  listRemote,
}: {
  entry: FileEntry
  onClose: () => void
  /** FTP 等远程条目没有本地 stat；目录递归统计需显式开启 */
  remote?: boolean
  /** 远程目录列目录函数，仅在设置开启时用于递归统计 */
  listRemote?: (path: string) => Promise<FileEntry[]>
}) {
  const [stat, setStat] = useState<StatInfo | null>(null)
  const [folderSize, setFolderSize] = useState<FolderSize | null>(null)
  const [folderSizeLoading, setFolderSizeLoading] = useState(false)
  /** 只有本地普通文件才算校验值（FTP 端拿不到服务器哈希）。 */
  const showHashes = !remote && !entry.isDirectory
  const [hashes, setHashes] = useState<Record<HashAlgorithm, string | null>>({
    md5: null,
    sha1: null,
    sha256: null,
  })
  const [hashError, setHashError] = useState<string | null>(null)
  const recursiveRemote =
    remote && entry.isDirectory && !!listRemote && getRecursiveFtpFolderStats()

  useEffect(() => {
    if (remote) return
    let active = true
    FileManager.stat(entry.path)
      .then(value => {
        if (active) setStat(value)
      })
      .catch(() => {})
    return () => {
      active = false
    }
  }, [entry.path, remote])

  useEffect(() => {
    if (!entry.isDirectory || (remote && !recursiveRemote)) {
      setFolderSize(null)
      setFolderSizeLoading(false)
      return
    }

    let active = true
    setFolderSize(null)
    setFolderSizeLoading(true)
    const task =
      remote && listRemote
        ? calculateRemoteFolderSize(listRemote, entry.path, () => active)
        : calculateFolderSize(entry.path, () => active)
    task
      .then(value => {
        if (!active) return
        setFolderSize(value)
        setFolderSizeLoading(false)
      })
      .catch(() => {
        if (!active) return
        setFolderSizeLoading(false)
      })

    return () => {
      active = false
    }
  }, [entry.path, entry.isDirectory, remote, recursiveRemote])

  useEffect(() => {
    if (!showHashes) return
    let active = true
    setHashes({ md5: null, sha1: null, sha256: null })
    setHashError(null)
    ;(async () => {
      // 逐个算：算完一个先上屏，用户能尽早看到第一个结果
      for (const algorithm of HASH_ALGORITHMS) {
        try {
          const value = await hashFile(entry.path, algorithm.id)
          if (!active) return
          setHashes(previous => ({ ...previous, [algorithm.id]: value }))
        } catch (error) {
          if (!active) return
          setHashError(error instanceof Error ? error.message : String(error))
          return
        }
      }
    })()
    return () => {
      active = false
    }
  }, [entry.path, showHashes])

  const extension = entry.isDirectory
    ? ""
    : entry.name.includes(".")
      ? entry.name.split(".").pop() ?? ""
      : ""
  const typeLabel = entry.isDirectory
    ? "文件夹"
    : extension
      ? `${extension.toUpperCase()} 文件`
      : "文件"
  const size = stat?.size ?? entry.size
  const hidden = entry.name.startsWith(".")
  const sizeValue = entry.isDirectory
    ? folderSize
      ? formatDetailSize(folderSize.bytes)
      : folderSizeLoading
        ? "计算中…"
        : "—"
    : formatDetailSize(size)

  return (
    <NavigationStack>
      <List
        navigationTitle="详情"
        navigationBarTitleDisplayMode="inline"
        toolbar={{ topBarTrailing: <Button title="完成" action={onClose} /> }}
      >
        <Section header={<Text>基本</Text>}>
          <LongValue label="名称" value={entry.name} />
          <LongValue label={remote ? "远程路径" : "完整路径"} value={entry.path} />
          <LabeledContent title="类型" value={typeLabel} />
          <LabeledContent title="隐藏项目" value={hidden ? "是" : "否"} />
        </Section>

        <Section header={<Text>文件数据</Text>}>
          <LabeledContent
            title="大小"
            value={sizeValue}
          />
          {entry.isDirectory ? (
            <LabeledContent
              title="数量"
              value={
                folderSize
                  ? `${folderSize.files} 个文件，${folderSize.directories} 个文件夹`
                  : folderSizeLoading
                    ? "计算中…"
                    : "—"
              }
            />
          ) : null}
          {entry.isDirectory ? (
            <LabeledContent
              title="字节数"
              value={
                folderSize
                  ? `${folderSize.bytes}`
                  : folderSizeLoading
                    ? "计算中…"
                    : "—"
              }
            />
          ) : (
            <LabeledContent title="字节数" value={`${size}`} />
          )}
          <LabeledContent
            title="创建日期"
            value={formatDetailDate(stat?.creationDate ?? 0)}
          />
          <LabeledContent
            title="修改日期"
            value={formatDetailDate(stat?.modificationDate ?? entry.modifiedAt)}
          />
          <LabeledContent title="底层类型" value={stat?.type ?? "—"} />
          {entry.isDirectory && (!remote || recursiveRemote) ? (
            <Text font="footnote" foregroundStyle="secondaryLabel">
              {remote
                ? "FTP 文件夹大小按服务器目录递归统计，可能需要较长时间。"
                : "文件夹大小按内部文件递归统计，不包含文件夹自身元数据。"}
            </Text>
          ) : null}
        </Section>

        {showHashes ? (
          <Section header={<Text>校验值</Text>}>
            {HASH_ALGORITHMS.map(algorithm => (
              <LongValue
                key={algorithm.id}
                label={algorithm.label}
                value={hashes[algorithm.id] ?? (hashError ? "不可用" : "计算中…")}
              />
            ))}
            {hashError ? (
              <Text font="footnote" foregroundStyle="secondaryLabel">
                {hashError}
              </Text>
            ) : null}
          </Section>
        ) : null}
      </List>
    </NavigationStack>
  )
}
