import { Button, Image, Menu, useEffect, useState } from "scripting"
import {
  getShowHiddenFiles,
  setShowHiddenFiles,
  subscribeShowHidden,
} from "../services/settings"

export function SettingsMenu({
  onSelect,
  onCreateFolder,
  onSort,
}: {
  onSelect?: () => void
  onCreateFolder?: () => void
  /** 只有挂载目录 / FTP 连接列表传这个，进排序面板 */
  onSort?: () => void
} = {}) {
  const [showHidden, setShowHidden] = useState(getShowHiddenFiles())

  useEffect(() => subscribeShowHidden(() => setShowHidden(getShowHiddenFiles())), [])

  function toggleHidden() {
    setShowHiddenFiles(!showHidden)
  }

  return (
    <Menu label={<Image systemName="gearshape" />}>
      {onSort ? (
        <Button title="排序" systemImage="arrow.up.arrow.down" action={onSort} />
      ) : null}
      {onCreateFolder ? (
        <Button
          title="新建文件夹"
          systemImage="folder.badge.plus"
          action={onCreateFolder}
        />
      ) : null}
      {onSelect ? (
        <Button title="选择" systemImage="checkmark.circle" action={onSelect} />
      ) : null}
      <Button
        title="显示 .开头文件"
        systemImage={showHidden ? "checkmark.circle.fill" : "circle"}
        action={toggleHidden}
      />
    </Menu>
  )
}
