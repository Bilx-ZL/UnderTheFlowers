import {
  Button,
  HStack,
  Image,
  List,
  NavigationStack,
  ProgressView,
  Section,
  Spacer,
  Text,
  VStack,
  useEffect,
  useState,
} from "scripting"
import { Mount } from "../types"
import { displayPath, loadMounts, resolveMountPath } from "../services/mounts"

/**
 * 只列挂载目录的根：点一个 → 确认「下载到「X」？」→ 回调该挂载根。
 * 不浏览目录、不选子目录 —— 想下到具体目录请用「下载到当前」。
 */
export function MountPickerSheet({
  onClose,
  onPick,
}: {
  onClose: () => void
  onPick: (mount: Mount, root: string) => void
}) {
  const [mounts, setMounts] = useState<Mount[] | undefined>(undefined)

  useEffect(() => {
    let cancelled = false
    loadMounts()
      .then(list => {
        if (!cancelled) setMounts(list)
      })
      .catch(() => {
        if (!cancelled) setMounts([])
      })
    return () => {
      cancelled = true
    }
  }, [])

  async function choose(mount: Mount, root: string) {
    const index = await Dialog.actionSheet({
      title: `下载到「${mount.name}」？`,
      message: "文件会放进这个挂载目录的根目录。",
      cancelButton: true,
      actions: [{ label: "下载" }],
    })
    if (index !== 0) return
    onPick(mount, root)
  }

  return (
    <NavigationStack>
      <List
        navigationTitle="下载到挂载"
        navigationBarTitleDisplayMode="inline"
        toolbar={{
          topBarLeading: (
            <Button action={onClose}>
              <Image systemName="xmark" />
            </Button>
          ),
        }}
      >
      {mounts === undefined ? (
        <Section>
          <HStack spacing={10} padding={{ vertical: 20 }} frame={{ maxWidth: "infinity" }}>
            <ProgressView />
            <Text foregroundStyle="secondaryLabel">正在读取挂载…</Text>
          </HStack>
        </Section>
      ) : mounts.length === 0 ? (
        <Section>
          <VStack spacing={8} padding={{ vertical: 24 }} frame={{ maxWidth: "infinity" }}>
            <Image systemName="folder" font="largeTitle" foregroundStyle="secondaryLabel" />
            <Text foregroundStyle="secondaryLabel">还没有挂载文件夹</Text>
          </VStack>
        </Section>
      ) : (
        <Section header={<Text>挂载目录</Text>}>
          {mounts.map(mount => {
            const root = resolveMountPath(mount)
            return (
              <Button
                key={mount.id}
                buttonStyle="plain"
                contentShape="rect"
                disabled={!root}
                action={() => {
                  if (root) void choose(mount, root)
                }}
              >
                <HStack spacing={12} frame={{ maxWidth: "infinity" }} contentShape="rect">
                  <Image
                    systemName="folder.fill"
                    font="title3"
                    foregroundStyle={root ? "systemBlue" : "secondaryLabel"}
                  />
                  <VStack alignment="leading" spacing={2} frame={{ maxWidth: "infinity", alignment: "leading" }}>
                    <Text lineLimit={1}>{mount.name}</Text>
                    <Text
                      font="caption"
                      foregroundStyle="secondaryLabel"
                      lineLimit={1}
                      truncationMode="head"
                    >
                      {displayPath(mount)}
                    </Text>
                  </VStack>
                  <Spacer />
                </HStack>
              </Button>
            )
          })}
        </Section>
      )}
      </List>
    </NavigationStack>
  )
}
