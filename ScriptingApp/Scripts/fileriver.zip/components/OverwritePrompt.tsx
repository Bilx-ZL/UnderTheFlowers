import { Button, HStack, Image, Text, Toggle, VStack, useState } from "scripting"

export type ConflictAction = "overwrite" | "keepBoth" | "skip"

/** 目标位置已有同名项目：覆盖 / 保留两者 / 跳过，底部可勾「全部」一次决定。 */
export function OverwritePrompt({
  name,
  subtitle,
  showApplyAll,
  onDecision,
}: {
  name: string
  subtitle: string
  showApplyAll: boolean
  onDecision: (action: ConflictAction, applyAll: boolean) => void
}) {
  const [applyAll, setApplyAll] = useState(false)

  return (
    <VStack
      spacing={16}
      padding={{ horizontal: 20, top: 20, bottom: 14 }}
      frame={{ maxWidth: "infinity", maxHeight: "infinity", alignment: "top" }}
      presentationDetents={[showApplyAll ? 330 : 300]}
      presentationDragIndicator="visible"
    >
      <VStack spacing={8} frame={{ maxWidth: "infinity" }}>
        <Image
          systemName="doc.badge.ellipsis"
          font="title"
          foregroundStyle="secondaryLabel"
        />
        <Text
          font="headline"
          lineLimit={2}
          truncationMode="middle"
          multilineTextAlignment="center"
        >
          {name}
        </Text>
        <Text
          font="footnote"
          foregroundStyle="secondaryLabel"
          multilineTextAlignment="center"
        >
          {subtitle}
        </Text>
      </VStack>

      <VStack spacing={10} frame={{ maxWidth: "infinity" }}>
        <Button
          action={() => onDecision("overwrite", applyAll)}
          buttonStyle="borderedProminent"
          role="destructive"
          frame={{ maxWidth: "infinity" }}
        >
          <Text font="body" frame={{ maxWidth: "infinity" }}>
            覆盖
          </Text>
        </Button>
        <HStack spacing={10} frame={{ maxWidth: "infinity" }}>
          <Button
            action={() => onDecision("keepBoth", applyAll)}
            buttonStyle="bordered"
            frame={{ maxWidth: "infinity" }}
          >
            <Text font="body" frame={{ maxWidth: "infinity" }}>
              保留两者
            </Text>
          </Button>
          <Button
            action={() => onDecision("skip", applyAll)}
            buttonStyle="bordered"
            frame={{ maxWidth: "infinity" }}
          >
            <Text font="body" frame={{ maxWidth: "infinity" }}>
              跳过
            </Text>
          </Button>
        </HStack>
      </VStack>

      {showApplyAll ? (
        <Toggle
          value={applyAll}
          onChanged={setApplyAll}
          title="全部冲突都这样处理"
        />
      ) : null}
    </VStack>
  )
}
