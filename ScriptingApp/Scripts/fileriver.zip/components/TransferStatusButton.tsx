import {
  Button,
  HStack,
  Image,
  List,
  NavigationStack,
  ProgressView,
  Section,
  Spacer,
  Text,
  VStack,
  useEffect,
  useState,
} from "scripting"
import {
  TransferTask,
  cancelTask,
  getTasks,
  setTransferPanelOpen,
  subscribeTasks,
} from "../services/transfers"

function taskTitle(task: TransferTask): string {
  switch (task.kind) {
    case "copy":
      return `复制「${task.name}」`
    case "move":
      return `移动「${task.name}」`
    case "delete":
      return `删除「${task.name}」`
    case "save":
      return `保存「${task.name}」到相册`
    case "download":
      return `下载「${task.name}」`
    case "upload":
      return `上传「${task.name}」`
    default:
      return `共享「${task.name}」`
  }
}

function taskIcon(task: TransferTask): string {
  if (task.kind === "delete") return "trash"
  if (task.kind === "move") return "arrow.right"
  if (task.kind === "save") return "square.and.arrow.down"
  if (task.kind === "download") return "arrow.down.to.line"
  if (task.kind === "upload") return "arrow.up.to.line"
  if (task.kind === "share") return "square.and.arrow.up"
  return "doc.on.doc"
}

function taskSubtitle(task: TransferTask): string {
  if (task.status === "cancelled") return task.detail || "已取消"
  if (task.status === "failed") return task.error ?? "失败"
  if (task.status === "running") return task.detail
  if (task.kind === "delete") return "已删除"
  if (task.kind === "save") return "已保存到相册"
  if (task.kind === "share") return "已共享"
  if (task.kind === "download") return "已下载"
  if (task.kind === "upload") return "已上传"
  const destination = task.destination.split("/").filter(Boolean).pop()
  return destination ? `已放到「${destination}」` : "完成"
}

function taskPercent(task: TransferTask): string {
  if (task.status === "cancelled") return "已取消"
  if (task.status === "done") return "完成"
  if (task.status === "failed") return "失败"
  if (task.progress == null) return "…"
  return `${Math.round(task.progress * 100)}%`
}

function TaskRow({ task }: { task: TransferTask }) {
  const color =
    task.status === "failed"
      ? "systemRed"
      : task.status === "cancelled"
        ? "secondaryLabel"
        : task.status === "done"
          ? "systemGreen"
          : "systemBlue"

  return (
    <VStack alignment="leading" spacing={6} padding={{ vertical: 4 }}>
      <HStack spacing={10}>
        <Image systemName={taskIcon(task)} foregroundStyle={color} />
        <VStack alignment="leading" spacing={2}>
          <Text lineLimit={1}>{taskTitle(task)}</Text>
          <Text font="caption" foregroundStyle="secondaryLabel" lineLimit={1}>
            {taskSubtitle(task)}
          </Text>
        </VStack>
        <Spacer />
        {task.status === "running" && task.cancellable ? (
          <Button title="取消" action={() => cancelTask(task.id)} />
        ) : (
          <Text font="caption" foregroundStyle="secondaryLabel">
            {taskPercent(task)}
          </Text>
        )}
      </HStack>
      {task.status === "cancelled" ? (
        <ProgressView value={0} total={1} />
      ) : task.progress == null ? (
        <ProgressView />
      ) : (
        <ProgressView value={task.progress} total={1} />
      )}
    </VStack>
  )
}

function TaskPanel({
  tasks,
  onClose,
}: {
  tasks: TransferTask[]
  onClose: () => void
}) {
  return (
    <NavigationStack>
      <List
        navigationTitle="传输任务"
        navigationBarTitleDisplayMode="inline"
        toolbar={{ topBarTrailing: <Button title="完成" action={onClose} /> }}
      >
        {tasks.length === 0 ? (
          <Section>
            <VStack spacing={8} padding={{ vertical: 24 }} frame={{ maxWidth: "infinity" }}>
              <Image
                systemName="checkmark.circle"
                font="largeTitle"
                foregroundStyle="secondaryLabel"
              />
              <Text foregroundStyle="secondaryLabel">没有正在进行的任务</Text>
            </VStack>
          </Section>
        ) : (
          <Section>{tasks.map(task => <TaskRow key={task.id} task={task} />)}</Section>
        )}
      </List>
    </NavigationStack>
  )
}

export function TransferStatusButton() {
  const [tasks, setTasks] = useState<TransferTask[]>(getTasks())
  const [showPanel, setShowPanel] = useState(false)

  useEffect(() => subscribeTasks(setTasks), [])
  useEffect(() => {
    return () => setTransferPanelOpen(false)
  }, [])

  function handlePanelChange(open: boolean) {
    setShowPanel(open)
    setTransferPanelOpen(open)
  }

  if (tasks.length === 0) return null

  const running = tasks.filter(task => task.status === "running")
  const determinate = running.filter(task => task.progress != null)
  const overall =
    determinate.length > 0
      ? determinate.reduce((sum, task) => sum + (task.progress ?? 0), 0) / determinate.length
      : null
  const failed = tasks.some(task => task.status === "failed")
  const label = failed
    ? "!"
    : running.length === 0
      ? "✓"
      : overall != null
        ? `${Math.round(overall * 100)}%`
        : `${running.length}`

  return (
    <Button
      action={() => handlePanelChange(true)}
      sheet={{
        isPresented: showPanel,
        onChanged: handlePanelChange,
        content: <TaskPanel tasks={tasks} onClose={() => handlePanelChange(false)} />,
      }}
    >
      <HStack spacing={3}>
        <Image systemName="arrow.triangle.2.circlepath" font="body" />
        <Text font="caption">{label}</Text>
      </HStack>
    </Button>
  )
}
