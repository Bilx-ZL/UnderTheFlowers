import { Button, Image } from "scripting"
import { ExitBehavior, getExitBehavior } from "../services/settings"

export function CloseButton({ onClose }: { onClose: (behavior: ExitBehavior) => void }) {
  return (
    <Button action={() => onClose(getExitBehavior())}>
      <Image systemName="xmark" />
    </Button>
  )
}
