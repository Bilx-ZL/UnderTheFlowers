export type MountKind = "local" | "ftp"

/**
 * 一个挂载点。
 * - local: 通过安全作用域书签指向文件 App 中的某个目录
 * - ftp:   远端服务器（后续实现，密码存 Keychain）
 */
export type Mount = {
  id: string
  kind: MountKind
  name: string
  /** 仅 local：书签名，用 FileManager.bookmarkedPath 解析 */
  bookmarkName?: string
  /** 仅 local：上次解析到的路径，仅用于展示/离线提示 */
  lastPath?: string
  createdAt: number
}

export type FTPConnection = {
  id: string
  name: string
  host: string
  port: number
  username: string
  /** 初始目录，始终以 / 开头 */
  path: string
  /** 显式 TLS（FTPS） */
  secure: boolean
  /** 忽略证书错误（自签名证书） */
  insecure: boolean
  createdAt: number
  lastConnectedAt?: number
}

export type FileEntry = {
  name: string
  path: string
  isDirectory: boolean
  size: number
  modifiedAt: number
}
