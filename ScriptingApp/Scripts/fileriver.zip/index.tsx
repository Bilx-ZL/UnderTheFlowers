import { Navigation, NavigationStack, Script, Tab, TabView, useEffect, useState } from "scripting"
import { MountsPage } from "./pages/MountsPage"
import { TransferPage } from "./pages/TransferPage"
import { SettingsPage } from "./pages/SettingsPage"
import { AboutPage } from "./pages/AboutPage"
import {
  ExitBehavior,
  getAboutSeen,
  loadSettings,
  setAboutSeen,
} from "./services/settings"
import { debugLog, initDebug } from "./services/debug"
import {
  ensureCacheDirs,
  ensureDataDir,
  ensureSettingsDir,
} from "./services/paths"
import { subscribeTabBarHidden } from "./services/uiState"
import { enforceCacheLimit } from "./services/thumbnails"
import { cleanupProviderTempCopies } from "./services/dragStage"
import { cleanupShareStage, cleanupDownloadStage } from "./services/downloads"
import { cleanupFtpPreviews } from "./services/ftp"
import { releaseWakeLock } from "./services/wakeLock"

let isPresenting = false

function Root() {
  const dismiss = Navigation.useDismiss()
  const [tabIndex, setTabIndex] = useState(0)
  const [tabBarHidden, setTabBarHidden] = useState(false)

  useEffect(() => {
    return subscribeTabBarHidden(setTabBarHidden)
  }, [])

  async function requestClose(behavior: ExitBehavior) {
    debugLog("app", `close requested: ${behavior}`)
    if (behavior === "minimize") {
      if (Script.supportsMinimization()) {
        const minimized = await Script.minimize()
        if (minimized || Script.isMinimized()) return
      }
      await Dialog.alert({
        title: "无法最小化",
        message: "当前环境不支持最小化，可以在设置里改为“退出”。",
      })
      return
    }
    dismiss()
  }

  return (
    <TabView
      tabIndex={tabIndex}
      onTabIndexChanged={setTabIndex}
      tabBarVisibility={tabBarHidden ? "hidden" : "visible"}
    >
      <Tab title="文件" systemImage="folder" value={0}>
        <MountsPage onClose={requestClose} />
      </Tab>
      <Tab title="FTP" systemImage="arrow.up.arrow.down" value={1}>
        <TransferPage onClose={requestClose} />
      </Tab>
      <Tab title="设置" systemImage="gearshape" value={2}>
        <SettingsPage onClose={requestClose} active={tabIndex === 2} />
      </Tab>
    </TabView>
  )
}

async function presentRoot() {
  if (isPresenting) return
  isPresenting = true
  debugLog("app", "present root")
  try {
    await Navigation.present({
      element: <Root />,
      modalPresentationStyle: "fullScreen",
    })
  } finally {
    isPresenting = false
  }
  releaseWakeLock()
  Script.exit()
}

Script.onResume(details => {
  debugLog("app", `resume: fromMinimized=${details.resumeFromMinimized}`)
  if (details.resumeFromMinimized) presentRoot()
})

async function main() {
  await ensureDataDir()
  await ensureCacheDirs()
  await ensureSettingsDir()
  await loadSettings()
  await initDebug()
  // 启动时补一次缓存上限检查（不阻塞首屏）
  enforceCacheLimit().catch(() => {})
  cleanupFtpPreviews().catch(() => {})
  cleanupProviderTempCopies().catch(() => {})
  cleanupShareStage().catch(() => {})
  cleanupDownloadStage().catch(() => {})
  debugLog("app", "launch")
  // 首次运行先介绍一下脚本，关掉后再进主界面
  if (!getAboutSeen()) {
    await Navigation.present({
      element: (
        <NavigationStack>
          <AboutPage />
        </NavigationStack>
      ),
    })
    await setAboutSeen(true)
  }
  presentRoot()
}

main()
