import type { AbortSignal } from "scripting"
import { FileEntry, FTPConnection } from "../types"
import { debugLog } from "./debug"
import { ensureSettingsDir, ftpPreviewDir, iCloudPath } from "./paths"
import { newId } from "./mounts"
import { formatSize } from "./localfs"
import {
  getFtpPreviewCacheLimit,
  getFtpPreviewCacheRetentionDays,
} from "./settings"

const CONNECT_TIMEOUT = 12
const LIST_MAX_TIME = 60
const TEST_MAX_TIME = 30
/** 预览下载：20 秒总时长 + 5 秒低速放弃，只作用于预览。 */
const PREVIEW_MAX_TIME = 20
/** 保存到相册 / 共享的下载沿用原来的宽松值，且不做低速判定。 */
const STALL_SPEED_LIMIT = 1024
const STALL_SPEED_TIME = 5
/** 分块下载：每块最长秒数（也决定取消按钮的响应延迟）。
 *  预览是弹窗交互，块要短一点取消才跟手；下载/保存按用户要求 15 秒。 */
const PREVIEW_CHUNK_SECONDS = 5
/** 分块下载的单块秒数：块间才检查取消标志，所以这个值就是取消的响应上限。
 *  15s 会让人觉得“点了没反应”，改小到 6s；续传靠 Range，块小不丢速度。 */
const CHUNK_SECONDS = 6
/** 块内轮询临时文件大小的间隔：curl 在跑的同时读 stat，得到秒级进度。 */
const PROGRESS_POLL_MS = 2000
/** 速度滑窗长度（至少覆盖两个采样点）。 */
const SPEED_WINDOW_MS = 6000
/** 卡死判定（按“多久没有新字节”，与块长解耦）。 */
const PREVIEW_STALL_MS = 5_000
const OTHER_STALL_MS = 30_000
/** 服务器端命令（RNFR/RNTO、DELE、RMD、MKD）的超时。 */
const OP_MAX_TIME = 60
const DOWNLOAD_FAIL_MESSAGE = "文件过大或预览超时。"
const STALL_TIMEOUT_MESSAGE = "下载超时，文件可能过大或网络较慢。"
const PREVIEW_MAX_BYTES = 100 * 1024 * 1024
const PREVIEW_ACCESS_FILE = ".fileRiver-access"
/** 下载完成后写入；命中缓存必须看到它，否则半截文件可能被当成完整内容。 */
const PREVIEW_COMPLETE_FILE = ".fileRiver-complete"
/** 下载中写入；用于区分“正在写的半成品”和“断掉的残留”。 */
const PREVIEW_PARTIAL_FILE = ".fileRiver-partial"
/** 带 partial 标记的目录在这段时间内不参与清理（保护正在进行的下载）。 */
const PREVIEW_PARTIAL_GRACE_MS = 10 * 60 * 1000

function joinPath(dir: string, name: string): string {
  return dir.replace(/\/+$/, "") + "/" + name
}

function connectionsFile(): string | null {
  return iCloudPath("ftp.json")
}

// MARK: - 连接存储

function normalizePort(value: unknown, fallback = 21): number {
  const port = typeof value === "number" ? value : Number(value)
  if (!Number.isInteger(port) || port < 1 || port > 65535) return fallback
  return port
}

export function normalizeRemotePath(path: string): string {
  const value = (path ?? "").trim()
  if (!value || value === "/") return "/"
  const withLeading = value.startsWith("/") ? value : "/" + value
  const collapsed = withLeading.replace(/\/{2,}/g, "/")
  return collapsed.replace(/\/+$/, "") || "/"
}

function normalizeConnection(raw: any): FTPConnection | null {
  if (!raw || typeof raw !== "object") return null
  let host = typeof raw.host === "string" ? raw.host.trim() : ""
  if (host.startsWith("[") && host.endsWith("]")) {
    host = host.slice(1, -1)
  }
  if (typeof raw.id !== "string" || !raw.id || !host) return null
  try {
    validateHost(host)
  } catch {
    return null
  }
  const username = typeof raw.username === "string" ? raw.username : ""
  if (username.includes(":") || /[\r\n]/.test(username)) return null
  const port = normalizePort(raw.port)
  const hostLabel = host.includes(":") ? `[${host}]` : host
  const fallbackName = port === 21 ? hostLabel : `${hostLabel}:${port}`
  return {
    id: raw.id,
    name:
      typeof raw.name === "string" && raw.name.trim()
        ? raw.name.trim()
        : fallbackName,
    host,
    port,
    username,
    path: normalizeRemotePath(typeof raw.path === "string" ? raw.path : "/"),
    secure: raw.secure === true,
    insecure: raw.insecure === true,
    createdAt:
      typeof raw.createdAt === "number" && Number.isFinite(raw.createdAt)
        ? raw.createdAt
        : Date.now(),
    lastConnectedAt:
      typeof raw.lastConnectedAt === "number" &&
      Number.isFinite(raw.lastConnectedAt)
        ? raw.lastConnectedAt
        : undefined,
  }
}

export async function loadConnections(): Promise<FTPConnection[]> {
  const file = connectionsFile()
  if (!file) throw new Error("iCloud 不可用，无法读取 FTP 连接。")
  if (!(await FileManager.exists(file))) return []

  // iCloud 目录按普通目录读取：readAsString 会自行触发下载。
  // 不要显式 downloadFileFromiCloud：关闭 iCloud 移动数据时可能无限卡住。
  const text = await FileManager.readAsString(file)
  let parsed: any
  try {
    parsed = JSON.parse(text)
  } catch {
    throw new Error("FTP 连接文件格式不正确。")
  }
  if (!Array.isArray(parsed)) {
    throw new Error("FTP 连接文件格式不正确。")
  }
  const list = parsed
    .map(normalizeConnection)
    .filter((item): item is FTPConnection => item !== null)
  if (parsed.length > 0 && list.length === 0) {
    throw new Error("FTP 连接文件格式不正确。")
  }
  return list
}

export async function saveConnections(
  connections: FTPConnection[]
): Promise<void> {
  const file = connectionsFile()
  if (!file) throw new Error("iCloud 不可用，无法保存 FTP 连接")
  await ensureSettingsDir()
  await FileManager.writeAsString(file, JSON.stringify(connections, null, 2))
}

function passwordKey(id: string): string {
  return `ftp.password.${id}`
}

export function loadFtpPassword(id: string): string | null {
  try {
    return Keychain.get(passwordKey(id))
  } catch (error) {
    debugLog("ftp", `keychain read failed: ${String(error)}`)
    return null
  }
}

function saveFtpPassword(id: string, password: string): boolean {
  try {
    return Keychain.set(passwordKey(id), password)
  } catch (error) {
    debugLog("ftp", `keychain write failed: ${String(error)}`)
    return false
  }
}

function removeFtpPassword(id: string): void {
  try {
    Keychain.remove(passwordKey(id))
  } catch (error) {
    debugLog("ftp", `keychain remove failed: ${String(error)}`)
  }
}

export async function upsertConnection(
  connection: FTPConnection,
  password: string,
  isNew: boolean,
  existing?: FTPConnection[]
): Promise<void> {
  const previousPassword = isNew ? null : loadFtpPassword(connection.id)
  if (!saveFtpPassword(connection.id, password)) {
    throw new Error("无法把密码保存到钥匙串。")
  }

  // 优先使用调用方内存里的列表，避免读文件失败时把旧连接覆盖掉
  const list = existing ?? (await loadConnections())
  const index = list.findIndex(item => item.id === connection.id)
  const next =
    index >= 0
      ? list.map(item => (item.id === connection.id ? connection : item))
      : [...list, connection]

  try {
    await saveConnections(next)
  } catch (error) {
    if (isNew) {
      removeFtpPassword(connection.id)
    } else if (previousPassword != null) {
      saveFtpPassword(connection.id, previousPassword)
    }
    throw error
  }
}

export async function deleteConnection(
  id: string,
  existing?: FTPConnection[]
): Promise<void> {
  const list = existing ?? (await loadConnections())
  await saveConnections(list.filter(item => item.id !== id))
  removeFtpPassword(id)
}

// MARK: - 地址解析

export type ParsedFtpAddress = {
  host: string
  port: number
  path: string
  secure: boolean
}

export function parseFtpPort(value: string, fallback = 21): number {
  const text = value.trim()
  if (!text) return fallback
  if (!/^\d+$/.test(text)) throw new Error("端口必须是数字。")
  const port = Number(text)
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error("端口必须在 1–65535 之间。")
  }
  return port
}

function validateHost(host: string): void {
  if (!host) throw new Error("请输入服务器地址。")
  if (/\s/.test(host)) throw new Error("服务器地址不能包含空格。")
  if (/[\/\\'"`$;&|<>%#?*\[\]]/.test(host)) {
    throw new Error("服务器地址包含无效字符。")
  }
  if (host.includes(":") && !/^[0-9A-Fa-f:.]+$/.test(host)) {
    throw new Error("IPv6 地址格式不正确，带端口时请使用 [地址]:端口。")
  }
}

/**
 * 解析用户输入的地址：
 * - `ftp.example.com`
 * - `ftp.example.com:2121`
 * - `ftp://ftp.example.com:2121/pub`
 * - `[2001:db8::1]:21`
 * 地址里带端口/路径时优先采用地址里的值。
 */
export function parseFtpAddress(
  raw: string,
  options: { port?: number; path?: string; secure?: boolean } = {}
): ParsedFtpAddress {
  let value = (raw ?? "").trim()
  if (!value) throw new Error("请输入服务器地址。")

  let secure = options.secure === true
  const schemeMatch = value.match(/^([A-Za-z][A-Za-z0-9+.-]*):\/\//)
  if (schemeMatch) {
    const scheme = schemeMatch[1].toLowerCase()
    if (scheme === "ftps") {
      secure = true
    } else if (scheme === "ftp") {
      // 显式 FTP
    } else if (scheme === "sftp") {
      throw new Error("暂不支持 SFTP，请使用 FTP 或 FTPS。")
    } else {
      throw new Error(`不支持的协议：${scheme.toUpperCase()}`)
    }
    value = value.slice(schemeMatch[0].length)
  }

  value = value.replace(/^\/+/, "")
  const slashIndex = value.indexOf("/")
  let authority = slashIndex >= 0 ? value.slice(0, slashIndex) : value
  const rawPath = slashIndex >= 0 ? value.slice(slashIndex) : ""

  if (!authority) throw new Error("请输入服务器地址。")
  if (authority.includes("@")) {
    throw new Error("请在用户名和密码栏填写凭据，不要写进服务器地址。")
  }

  let host = authority
  let port = options.port ?? 21

  if (authority.startsWith("[")) {
    const end = authority.indexOf("]")
    if (end < 0) throw new Error("IPv6 地址缺少右方括号。")
    host = authority.slice(1, end)
    const rest = authority.slice(end + 1)
    if (rest.startsWith(":")) {
      port = parseFtpPort(rest.slice(1))
    } else if (rest) {
      throw new Error("服务器地址格式不正确。")
    }
  } else {
    const colonCount = (authority.match(/:/g) ?? []).length
    if (colonCount === 1) {
      const colon = authority.lastIndexOf(":")
      host = authority.slice(0, colon)
      port = parseFtpPort(authority.slice(colon + 1))
    }
  }

  host = host.trim()
  validateHost(host)

  const fallbackPath = options.path ?? "/"
  const path =
    rawPath && rawPath !== "/"
      ? normalizeRemotePath(rawPath)
      : normalizeRemotePath(fallbackPath)

  return { host, port, path, secure }
}

export function addressForDisplay(connection: FTPConnection): string {
  const host = connection.host.includes(":")
    ? `[${connection.host}]`
    : connection.host
  return connection.port === 21 ? host : `${host}:${connection.port}`
}

// MARK: - curl

function encodeSegment(segment: string): string {
  return encodeURIComponent(segment).replace(
    /[!'()*]/g,
    char => "%" + char.charCodeAt(0).toString(16).toUpperCase()
  )
}

function encodeRemotePath(path: string): string {
  const normalized = normalizeRemotePath(path)
  if (normalized === "/") return "/"
  return normalized.split("/").map(encodeSegment).join("/")
}

export function buildFtpUrl(
  connection: FTPConnection,
  path: string,
  directory: boolean
): string {
  const host = connection.host.includes(":")
    ? `[${connection.host}]`
    : connection.host
  let encoded = encodeRemotePath(path)
  if (directory && !encoded.endsWith("/")) encoded += "/"
  return `ftp://${host}:${connection.port}${encoded}`
}

function quoteSingle(value: string): string {
  return `'${value.replace(/'/g, `'\\''`)}'`
}

function curlExitCode(output: string): number | null {
  const text = (output ?? "").trim()
  const match = text.match(/curl:\s*\((\d+)\)\s*([^\n]*)/)
  return match ? Number(match[1]) : null
}

function describeCurlFailure(output: string): string {
  const text = (output ?? "").trim()
  const code = curlExitCode(output)
  const messages: Record<number, string> = {
    1: "不支持的操作。",
    3: "服务器地址格式不正确。",
    5: "无法解析代理地址。",
    6: "无法解析服务器地址，请检查域名或网络。",
    7: "无法连接到服务器，请检查地址、端口和网络。",
    9: "服务器拒绝了访问。",
    21: "服务器拒绝了这条操作（可能无权限、目标已存在或文件已不存在）。",
    28: "连接或读取超时，请检查网络和服务器状态。",
    35: "TLS 握手失败，请确认服务器是否支持 FTPS。",
    51: "服务器证书验证失败。",
    60: "服务器证书无法验证，可在高级里打开“忽略证书错误”。",
    63: "文件过大或预览超时。",
    67: "用户名或密码错误，或服务器不允许登录。",
    78: "远程路径不存在或无法访问。",
    84: "FTP 命令执行失败。",
  }
  if (code != null && messages[code]) return messages[code]
  const tail = text.split("\n").filter(Boolean).pop()
  if (tail) return `无法访问 FTP 服务器：${tail}`
  return "无法访问 FTP 服务器。"
}

type CurlOptions = {
  connection: FTPConnection
  url: string
  password?: string
  maxTime: number
  listOnly?: boolean
  outputPath?: string
  /** 启用低速卡死判定（仅预览下载）。 */
  stall?: boolean
  /** 续传（-C -），用于分块下载。 */
  resume?: boolean
  /** 服务器端 FTP 命令（RNFR/RNTO、DELE、RMD、MKD）。 */
  quotes?: string[]
  /** 给 --max-filesize 用的字节上限；不传表示不限。 */
  maxBytes?: number
  /** 上传本地文件（-T）。 */
  uploadPath?: string
  /** 只取响应头（FTP 下等于发 SIZE，用来查远端文件大小）。 */
  headOnly?: boolean
}

async function runCurl(options: CurlOptions): Promise<ShellExecutionResult> {
  const { connection, url, maxTime } = options
  const parts = [
    "curl",
    "-sS",
    "--connect-timeout",
    String(CONNECT_TIMEOUT),
    "--max-time",
    String(maxTime),
    "--ftp-pasv",
  ]
  if (connection.secure) parts.push("--ssl-reqd")
  if (connection.insecure) parts.push("--insecure")
  if (options.listOnly) parts.push("--list-only")
  if (options.headOnly) parts.push("-I")

  if (connection.username) {
    // ios_system 不会在双引号内展开变量，这里直接把凭据拼进单引号参数。
    // 注意：不要把 command 写进日志。
    const password = options.password ?? loadFtpPassword(connection.id) ?? ""
    parts.push("-u", quoteSingle(`${connection.username}:${password}`))
  }

  if (options.uploadPath) {
    // 上传续传：-C - 让 curl 先问远端大小，再用 APPE 从那里续。
    if (options.resume) parts.push("-C", "-")
    parts.push("-T", quoteSingle(options.uploadPath))
  }

  if (options.outputPath) {
    if (options.maxBytes != null) {
      parts.push("--max-filesize", String(options.maxBytes))
    }
    if (options.stall) {
      parts.push("--speed-limit", String(STALL_SPEED_LIMIT))
      parts.push("--speed-time", String(STALL_SPEED_TIME))
    }
    if (options.resume) parts.push("-C", "-")
    parts.push("-o", quoteSingle(options.outputPath))
  }
  if (options.quotes) {
    for (const command of options.quotes) {
      parts.push("-Q", quoteSingle(command))
    }
  }
  parts.push(quoteSingle(url))

  debugLog(
    "ftp",
    `curl ${connection.host}:${connection.port} ${
      options.listOnly ? "list-only" : options.outputPath ? "download" : "list"
    }`
  )

  try {
    return await Shell.run(parts.join(" "), {
      timeout: maxTime + 12,
    })
  } catch {
    debugLog("ftp", "shell run failed")
    throw new Error("无法运行 curl，请确认脚本环境支持 Shell。")
  }
}

export async function testFtpConnection(
  connection: FTPConnection,
  password?: string
): Promise<void> {
  const result = await runCurl({
    connection,
    url: buildFtpUrl(connection, connection.path, true),
    password,
    maxTime: TEST_MAX_TIME,
    listOnly: true,
  })
  if (result.timedOut) {
    throw new Error("连接超时，请检查网络和服务器地址。")
  }
  if (result.exitCode !== 0) {
    throw new Error(describeCurlFailure(result.output))
  }
  if (/^curl:\s*\(\d+\)/m.test(result.output)) {
    throw new Error(describeCurlFailure(result.output))
  }
}

// MARK: - LIST 解析

const MONTHS: Record<string, number> = {
  jan: 0,
  feb: 1,
  mar: 2,
  apr: 3,
  may: 4,
  jun: 5,
  jul: 6,
  aug: 7,
  sep: 8,
  oct: 9,
  nov: 10,
  dec: 11,
}

function listingDate(
  month: number,
  day: number,
  year: number,
  hour: number,
  minute: number,
  explicitYear: boolean
): number {
  let value = new Date(year, month, day, hour, minute, 0, 0).getTime()
  if (!explicitYear && value > Date.now() + 24 * 60 * 60 * 1000) {
    value = new Date(year - 1, month, day, hour, minute, 0, 0).getTime()
  }
  return value
}

function entryFrom(
  basePath: string,
  name: string,
  isDirectory: boolean,
  size: number,
  modifiedAt: number
): FileEntry | null {
  if (!name || name === "." || name === "..") return null
  if (name.includes("/")) return null
  const base = normalizeRemotePath(basePath)
  return {
    name,
    path: base === "/" ? "/" + name : `${base}/${name}`,
    isDirectory,
    size: isDirectory ? 0 : Math.max(0, size),
    modifiedAt,
  }
}

function parseUnixLine(line: string, basePath: string): FileEntry | null {
  // -rw-r--r--    1 owner group      1234 Oct 20 12:00 file name
  // drwxr-xr-x    2 owner group      4096 Dec 13  2013 folder
  const match = line.match(
    /^([\-dlbcps])([rwxStTs\-]{9})[+.@]?\s+\d+\s+\S+\s+\S+\s+(\d+)\s+([A-Za-z]{3})\s+(\d{1,2})\s+(\d{1,2}:\d{2}|\d{4})\s+(.+)$/
  )
  if (!match) return null

  const type = match[1]
  const size = Number(match[3]) || 0
  const month = MONTHS[match[4].toLowerCase()]
  if (month == null) return null
  const day = Number(match[5])
  const dateToken = match[6]
  let name = match[7].replace(/\r$/, "").trimEnd()

  if (type === "l") {
    const arrow = name.indexOf(" -> ")
    if (arrow > 0) name = name.slice(0, arrow)
  }

  let modifiedAt = 0
  if (/^\d{4}$/.test(dateToken)) {
    modifiedAt = listingDate(month, day, Number(dateToken), 0, 0, true)
  } else {
    const [hour, minute] = dateToken.split(":").map(Number)
    modifiedAt = listingDate(
      month,
      day,
      new Date().getFullYear(),
      hour,
      minute,
      false
    )
  }

  return entryFrom(basePath, name, type === "d", size, modifiedAt)
}

function parseDosLine(line: string, basePath: string): FileEntry | null {
  // 10-20-25  03:23PM       <DIR>          folder
  // 10-20-25  03:23PM             12345 file.txt
  const match = line.match(
    /^(\d{1,2})-(\d{1,2})-(\d{2,4})\s+(\d{1,2}):(\d{2})\s*([AaPp][Mm])?\s+(<DIR>|\d+)\s+(.+)$/
  )
  if (!match) return null

  const month = Number(match[1]) - 1
  const day = Number(match[2])
  let year = Number(match[3])
  if (year < 100) year += 2000
  let hour = Number(match[4])
  const minute = Number(match[5])
  const suffix = match[6]?.toUpperCase()
  if (suffix === "PM" && hour < 12) hour += 12
  if (suffix === "AM" && hour === 12) hour = 0

  const isDirectory = match[7].toUpperCase() === "<DIR>"
  const size = isDirectory ? 0 : Number(match[7]) || 0
  const name = match[8].replace(/\r$/, "").trimEnd()

  return entryFrom(
    basePath,
    name,
    isDirectory,
    size,
    listingDate(month, day, year, hour, minute, true)
  )
}

function parseEplfLine(line: string, basePath: string): FileEntry | null {
  // +i8388621.48594,m825718503,r,s280,\tfile
  if (!line.startsWith("+")) return null
  const tab = line.indexOf("\t")
  if (tab < 0) return null
  const facts = line.slice(1, tab)
  const name = line.slice(tab + 1).replace(/\r$/, "").trimEnd()
  const isDirectory = /(^|,)\/(,|$)/.test(facts)
  const sizeMatch = facts.match(/(?:^|,)s(\d+)/)
  const timeMatch = facts.match(/(?:^|,)m(\d+)/)
  return entryFrom(
    basePath,
    name,
    isDirectory,
    sizeMatch ? Number(sizeMatch[1]) : 0,
    timeMatch ? Number(timeMatch[1]) * 1000 : 0
  )
}

export function parseFtpListing(
  output: string,
  basePath: string
): FileEntry[] {
  const entries: FileEntry[] = []
  for (const raw of (output ?? "").split(/\r?\n/)) {
    const line = raw.replace(/\r$/, "").trimEnd()
    if (!line.trim()) continue
    if (/^total\s+\d+/i.test(line.trim())) continue
    if (/^curl:\s*\(\d+\)/i.test(line.trim())) continue
    const entry =
      parseUnixLine(line, basePath) ??
      parseDosLine(line, basePath) ??
      parseEplfLine(line, basePath)
    if (entry) entries.push(entry)
  }
  return entries
}

function parseNamesOnly(output: string, basePath: string): FileEntry[] {
  const entries: FileEntry[] = []
  for (const raw of (output ?? "").split(/\r?\n/)) {
    const name = raw.replace(/\r$/, "").trim()
    if (!name) continue
    if (/^total\s+\d+/i.test(name)) continue
    if (/^curl:\s*\(\d+\)/i.test(name)) continue
    const entry = entryFrom(basePath, name, false, 0, 0)
    if (entry) entries.push(entry)
  }
  return entries
}

function hasListableLine(output: string): boolean {
  return (output ?? "")
    .split(/\r?\n/)
    .some(line => {
      const value = line.trim()
      return (
        value.length > 0 &&
        !/^total\s+\d+/i.test(value) &&
        !/^curl:\s*\(\d+\)/i.test(value)
      )
    })
}

function sortEntries(entries: FileEntry[]): FileEntry[] {
  entries.sort((a, b) => {
    if (a.isDirectory !== b.isDirectory) return a.isDirectory ? -1 : 1
    return a.name.localeCompare(b.name, "zh-Hans")
  })
  return entries
}

export async function listFtp(
  connection: FTPConnection,
  path: string,
  showHidden = true,
  password?: string
): Promise<FileEntry[]> {
  const target = normalizeRemotePath(path)
  const url = buildFtpUrl(connection, target, true)
  const result = await runCurl({
    connection,
    url,
    password,
    maxTime: LIST_MAX_TIME,
  })

  if (result.timedOut) {
    throw new Error("读取目录超时，请检查网络或稍后重试。")
  }
  if (result.exitCode !== 0) {
    throw new Error(describeCurlFailure(result.output))
  }

  let entries = parseFtpListing(result.output, target)

  // 少数服务器返回非 Unix/DOS 格式，退回到只取文件名（类型按文件处理）
  if (entries.length === 0 && hasListableLine(result.output)) {
    const fallback = await runCurl({
      connection,
      url,
      password,
      maxTime: LIST_MAX_TIME,
      listOnly: true,
    })
    if (fallback.timedOut) {
      throw new Error("读取目录超时，请检查网络或稍后重试。")
    }
    if (fallback.exitCode !== 0) {
      throw new Error(describeCurlFailure(fallback.output))
    }
    entries = parseNamesOnly(fallback.output, target)
  }

  const filtered = showHidden
    ? entries
    : entries.filter(entry => !entry.name.startsWith("."))
  return sortEntries(filtered)
}

// MARK: - 预览下载

/** 小文件不走进度采样：已知大小且 < 这个阈值时，直接跑一块就完。 */
const PROGRESS_SKIP_BYTES = 512 * 1024

/** 预览根目录本次运行是否已确认存在（批量下载时省掉每个文件一次 exists）。 */
let previewDirReady = false

async function ensurePreviewDir(): Promise<string> {
  const dir = ftpPreviewDir()
  if (previewDirReady) return dir
  if (!(await FileManager.exists(dir))) {
    await FileManager.createDirectory(dir, true)
  }
  previewDirReady = true
  return dir
}

function hashKey(value: string): string {
  let hash = 2166136261
  for (let i = 0; i < value.length; i++) {
    hash ^= value.charCodeAt(i)
    hash = Math.imul(hash, 16777619)
  }
  return (hash >>> 0).toString(36)
}

function safePreviewName(name: string): string {
  return (
    name
      .replace(/[\/\\:*?"<>|\r\n]/g, "_")
      .trim()
      .slice(0, 120) || "file"
  )
}

function isDirectoryType(type: unknown): boolean {
  return String(type ?? "").toLowerCase().endsWith("directory")
}

type PreviewCacheRecord = {
  path: string
  bytes: number
  at: number
  /** 带 .fileRiver-complete 标记才算完整缓存 */
  complete: boolean
}

async function hasCompleteMarker(dir: string): Promise<boolean> {
  try {
    return await FileManager.exists(joinPath(dir, PREVIEW_COMPLETE_FILE))
  } catch {
    return false
  }
}

async function scanFtpPreviewCache(): Promise<PreviewCacheRecord[]> {
  const dir = ftpPreviewDir()
  if (!(await FileManager.exists(dir))) return []
  const names = await FileManager.readDirectory(dir)
  const records: PreviewCacheRecord[] = []
  for (const name of names) {
    if (name === "." || name === "..") continue
    const path = joinPath(dir, name)
    try {
      const stat = await FileManager.stat(path)
      if (!isDirectoryType(stat.type)) continue
      const children = await FileManager.readDirectory(path, true)
      let bytes = 0
      for (const child of children) {
        try {
          // readDirectory(..., true) 返回的是相对路径，需要拼回预览子目录
          const childStat = await FileManager.stat(joinPath(path, child))
          if (!isDirectoryType(childStat.type)) {
            bytes += childStat.size ?? 0
          }
        } catch {
          // 单个文件统计失败时跳过
        }
      }
      let at = stat.modificationDate ?? 0
      try {
        const marker = joinPath(path, PREVIEW_ACCESS_FILE)
        if (await FileManager.exists(marker)) {
          const value = Number(await FileManager.readAsString(marker))
          if (Number.isFinite(value)) at = value
        }
      } catch {
        // 访问时间标记损坏时使用目录修改时间
      }
      records.push({ path, bytes, at, complete: await hasCompleteMarker(path) })
    } catch {
      // 单个预览目录失败时跳过
    }
  }
  return records
}

export async function getFtpPreviewCacheSize(): Promise<number> {
  const records = await scanFtpPreviewCache()
  return records.reduce((sum, record) => sum + record.bytes, 0)
}

/** 清空 FTP 预览缓存，返回释放的字节数。 */
export async function clearFtpPreviewCache(): Promise<number> {
  const records = await scanFtpPreviewCache()
  let freed = 0
  for (const record of records) {
    try {
      await FileManager.remove(record.path)
      freed += record.bytes
    } catch {
      // 可能已被外部删除
    }
  }
  return freed
}

/**
 * FTP 预览缓存只按天数保留（或即时清理 / 无限制），不再有容量上限。
 */
export async function enforceFtpPreviewCacheLimit(): Promise<void> {
  const retentionDays = getFtpPreviewCacheRetentionDays()
  const records = await scanFtpPreviewCache()
  const now = Date.now()

  // 1) 先清理没有完成标记的残留（下载中断、被杀进程留下的一半文件）
  //    带 fresh mtime 的目录当作“可能正在下载”，先放过。
  let junkRemoved = 0
  let junkFreed = 0
  for (const record of records) {
    if (record.complete) continue
    if (record.at > now - PREVIEW_PARTIAL_GRACE_MS) continue
    try {
      await FileManager.remove(record.path)
      junkRemoved += 1
      junkFreed += record.bytes
    } catch {
      // 可能已被外部删除
    }
  }
  if (junkRemoved > 0) {
    debugLog(
      "ftp",
      `preview cache dropped ${junkRemoved} incomplete dir(s), freed ${junkFreed} bytes`
    )
  }

  const valid = records.filter(record => record.complete)
  if (retentionDays == null) return

  // 按天数保留：删除最近使用时间超过 7/30 天的完整预览
  const cutoff = now - retentionDays * 24 * 60 * 60 * 1000
  let freed = 0
  let removed = 0
  for (const record of valid) {
    if (record.at >= cutoff) continue
    try {
      await FileManager.remove(record.path)
      removed += 1
    } catch {
      // 可能已被外部删除
    }
    freed += record.bytes
  }
  if (removed > 0) {
    debugLog(
      "ftp",
      `preview cache expired ${removed} dir(s), freed ${freed} bytes`
    )
  }
}

export type PreparedPreview = {
  path: string
  cleanup?: () => void
}

/** 用户主动取消下载。 */
export class DownloadCancelledError extends Error {
  constructor() {
    super("已取消")
    this.name = "DownloadCancelledError"
  }
}

export type DownloadOptions = {
  signal?: AbortSignal
  /** loaded/total 是字节；speed 是字节/秒（最近几秒滑窗，刚开头或未知时为 undefined）。 */
  onProgress?: (loaded: number, total: number, speed?: number) => void
}

/** preview = 快进快出（20s + 100MB + 低速判定，点开就看的场景）；
 *  share = 共享 / 保存到相册：不限大小与总时长，写入预览缓存；
 *  download = 下载到本地目录：不限制大小与总时长，不写预览缓存。 */
export type DownloadMode = "preview" | "share" | "download"

/** 只有 preview 受大小与总时长限制。 */
function isLimitedMode(mode: DownloadMode): boolean {
  return mode === "preview"
}

export async function downloadFtpFile(
  connection: FTPConnection,
  entry: FileEntry,
  password?: string,
  mode: DownloadMode = "preview",
  options?: DownloadOptions
): Promise<PreparedPreview> {
  if (isLimitedMode(mode) && entry.size > PREVIEW_MAX_BYTES) {
    throw new Error(DOWNLOAD_FAIL_MESSAGE)
  }

  const immediate =
    mode === "download" || getFtpPreviewCacheLimit() === "immediate"
  const dir = await ensurePreviewDir()
  const safeId = connection.id.replace(/[^a-zA-Z0-9._-]/g, "_") || "ftp"
  const safeName = safePreviewName(entry.name)
  // 即时清理：每次用新目录，关闭预览后删除。
  // 缓存模式：用连接 + 路径 + 大小 + 时间生成稳定目录，命中时直接复用。
  const cacheKey = `${safeId}-${hashKey(
    `${connection.host}|${connection.port}|${connection.username}|${entry.path}|${entry.size}|${entry.modifiedAt}`
  )}`
  const subdir = joinPath(
    dir,
    immediate
      ? `${safeId}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
      : cacheKey
  )
  const file = joinPath(subdir, safeName)

  if (!immediate) {
    try {
      if (await FileManager.exists(file)) {
        const stat = await FileManager.stat(file)
        const sizeMatches =
          stat.size > 0 && (entry.size <= 0 || stat.size === entry.size)
        if (sizeMatches && (await hasCompleteMarker(subdir))) {
          await FileManager.writeAsString(
            joinPath(subdir, PREVIEW_ACCESS_FILE),
            String(Date.now())
          ).catch(() => {})
          return {
            path: file,
            cleanup: () => {
              enforceFtpPreviewCacheLimit().catch(() => {})
            },
          }
        }
      }
    } catch {
      // 缓存损坏时重新下载
    }
  }

  if (await FileManager.exists(subdir)) {
    await FileManager.remove(subdir).catch(() => {})
  }
  await FileManager.createDirectory(subdir, true)
  // 标记“正在下载”，避免半成品被当成完整缓存或清理器误删
  await FileManager.writeAsString(
    joinPath(subdir, PREVIEW_PARTIAL_FILE),
    String(Date.now())
  ).catch(() => {})
  const url = buildFtpUrl(connection, entry.path, false)
  const total = entry.size > 0 ? entry.size : 0
  const budget = mode === "preview" ? PREVIEW_MAX_TIME : Number.POSITIVE_INFINITY
  const chunkLimit =
    mode === "preview" ? PREVIEW_CHUNK_SECONDS : CHUNK_SECONDS
  const stallMs = mode === "preview" ? PREVIEW_STALL_MS : OTHER_STALL_MS
  let lastGrowthAt = Date.now()
  const startedAt = Date.now()

  const failWith = async (message: string): Promise<never> => {
    await FileManager.remove(subdir).catch(() => {})
    throw new Error(message)
  }
  const cancelNow = async (): Promise<never> => {
    await FileManager.remove(subdir).catch(() => {})
    throw new DownloadCancelledError()
  }
  const statSize = async (): Promise<number> => {
    try {
      return (await FileManager.stat(file)).size ?? 0
    } catch {
      return 0
    }
  }

  let size = 0
  let resume = false
  let restarted = false

  // 速度滑窗：最近 SPEED_WINDOW_MS 内的 (时间, 字节) 样本
  const samples: { at: number; size: number }[] = []
  const report = (current: number) => {
    const now = Date.now()
    samples.push({ at: now, size: current })
    while (samples.length > 2 && now - samples[0].at > SPEED_WINDOW_MS) {
      samples.shift()
    }
    const first = samples[0]
    const span = (now - first.at) / 1000
    const speed = span >= 0.5 ? (current - first.size) / span : undefined
    options?.onProgress?.(current, total, speed && speed > 0 ? speed : undefined)
  }

  /** 跑一块，同时每隔 PROGRESS_POLL_MS 读一次临时文件大小（curl 在另一个线程，互不干扰）。
   *  小文件不采样：以前 ticker 的 sleep 会在块结束后继续等完整个间隔，
   *  每个小文件白白多等最多 2 秒。现在睡眠可被提前唤醒，且小块直接不启 ticker。 */
  const runChunk = async (chunkTime: number) => {
    let finished = false
    let reported = size
    // 用对象持有唤醒函数：直接写 let 变量时 TS 会把闭包外读到的值窄化成 null
    const wakeBox: { fn: (() => void) | null } = { fn: null }
    const sample = total === 0 || total > PROGRESS_SKIP_BYTES
    const ticker = sample
      ? (async () => {
          while (!finished) {
            await new Promise<void>(resolve => {
              wakeBox.fn = resolve
              setTimeout(resolve, PROGRESS_POLL_MS)
            })
            wakeBox.fn = null
            if (finished) break
            const current = await statSize()
            if (current > reported) {
              reported = current
              report(current)
            }
          }
        })()
      : null

    try {
      return await runCurl({
        connection,
        url,
        password,
        maxTime: chunkTime,
        stall: mode === "preview",
        outputPath: file,
        resume,
        maxBytes: isLimitedMode(mode) ? PREVIEW_MAX_BYTES : undefined,
      })
    } finally {
      finished = true
      wakeBox.fn?.()
      if (ticker) await ticker.catch(() => {})
    }
  }

  // 分块下载：每块最长 chunkLimit 秒，块间检查取消标志；
  // 拿不到总大小时退化为单次下载（因为无法判断何时写完）。
  while (true) {
    if (options?.signal?.aborted) await cancelNow()
    const elapsed = (Date.now() - startedAt) / 1000
    if (elapsed >= budget) {
      await failWith(
        mode === "preview" ? DOWNLOAD_FAIL_MESSAGE : STALL_TIMEOUT_MESSAGE
      )
    }
    const chunkTime = Math.max(
      1,
      Math.ceil(Math.min(chunkLimit, budget - elapsed))
    )

    const result = await runChunk(chunkTime)

    const previousSize = size
    const nextSize = await statSize()
    if (nextSize > size) {
      size = nextSize
      lastGrowthAt = Date.now()
    }
    if (size > previousSize) report(size)

    if (isLimitedMode(mode) && size > PREVIEW_MAX_BYTES) {
      await failWith(DOWNLOAD_FAIL_MESSAGE)
    }

    // 服务端不支持续传：本地文件比远端还大（追加了重复内容），从头重来一次
    if (total > 0 && size > total) {
      if (restarted) await failWith(DOWNLOAD_FAIL_MESSAGE)
      restarted = true
      await FileManager.remove(file).catch(() => {})
      size = 0
      resume = false
      lastGrowthAt = Date.now()
      samples.length = 0
      continue
    }

    if (total > 0 && size >= total) break
    if (result.exitCode === 0) break

    const code = curlExitCode(result.output)
    if (code === 63) await failWith(DOWNLOAD_FAIL_MESSAGE)
    if (code !== 28 && !result.timedOut) {
      await failWith(describeCurlFailure(result.output))
    }
    resume = true
    if (Date.now() - lastGrowthAt >= stallMs) {
      await failWith(
        mode === "preview" ? DOWNLOAD_FAIL_MESSAGE : STALL_TIMEOUT_MESSAGE
      )
    }
  }

  try {
    const stat = await FileManager.stat(file)
    if (isLimitedMode(mode) && stat.size > PREVIEW_MAX_BYTES) {
      throw new Error(DOWNLOAD_FAIL_MESSAGE)
    }
    if (!stat.size && entry.size > 0) {
      throw new Error("下载失败：收到的文件为空。")
    }
    // 写完成标记：以后命中缓存必须看到它
    await FileManager.writeAsString(
      joinPath(subdir, PREVIEW_COMPLETE_FILE),
      String(Date.now())
    ).catch(() => {})
    await FileManager.remove(joinPath(subdir, PREVIEW_PARTIAL_FILE)).catch(() => {})
    if (!immediate) {
      await FileManager.writeAsString(
        joinPath(subdir, PREVIEW_ACCESS_FILE),
        String(Date.now())
      ).catch(() => {})
    }
  } catch (error) {
    await FileManager.remove(subdir).catch(() => {})
    throw error instanceof Error ? error : new Error(String(error))
  }

  return {
    path: file,
    cleanup: () => {
      if (immediate) {
        FileManager.remove(subdir).catch(() => {})
      } else {
        enforceFtpPreviewCacheLimit().catch(() => {})
      }
    },
  }
}

/**
 * FTP 命令里的路径参数：直接发裸路径，不要加引号。
 * Wing FTP 等服务器会把双引号当成文件名的一部分，回 550 Invalid file name；
 * 路径里的空格不需要转义，FTP 命令把行剩余部分整个当参数。
 */
function commandPath(path: string): string {
  return normalizeRemotePath(path)
}

/** 发一批服务器端命令；失败（含 curl 报错）就抛异常。 */
async function runFtpCommands(
  connection: FTPConnection,
  commands: string[],
  password?: string
): Promise<void> {
  if (commands.length === 0) return
  const result = await runCurl({
    connection,
    url: buildFtpUrl(connection, "/", true),
    password,
    maxTime: OP_MAX_TIME,
    listOnly: true,
    quotes: commands,
  })
  if (result.timedOut) {
    throw new Error("服务器没有响应，操作可能未完成。")
  }
  if (result.exitCode !== 0 || /^curl:\s*\(\d+\)/m.test(result.output)) {
    throw new Error(describeCurlFailure(result.output))
  }
}

/** 同一目录内改名（文件或文件夹）。 */
export async function renameFtpEntry(
  connection: FTPConnection,
  fromPath: string,
  toPath: string,
  password?: string
): Promise<void> {
  try {
    await runFtpCommands(
      connection,
      [`RNFR ${commandPath(fromPath)}`, `RNTO ${commandPath(toPath)}`],
      password
    )
  } catch (error) {
    // 服务器拒绝改名时 curl 只报“引用命令失败”，给出更可操作的原因
    throw new Error(
      `重命名失败：${error instanceof Error ? error.message : String(error)}`
    )
  }
  debugLog("ftp", "renamed remote entry")
}

/** 新建远程目录（完整路径）。 */
export async function createFtpDirectory(
  connection: FTPConnection,
  path: string,
  password?: string
): Promise<void> {
  try {
    await runFtpCommands(connection, [`MKD ${commandPath(path)}`], password)
  } catch (error) {
    throw new Error(
      `新建文件夹失败：${error instanceof Error ? error.message : String(error)}`
    )
  }
  debugLog("ftp", "created remote directory")
}

/** 删除远端单个文件（同名覆盖前用）。 */
export async function deleteRemoteFile(
  connection: FTPConnection,
  path: string,
  password?: string
): Promise<void> {
  await runFtpCommands(connection, [`DELE ${commandPath(path)}`], password)
}

/** 远端文件字节数；不存在或查询失败返回 0。 */
export async function remoteFileSize(
  connection: FTPConnection,
  path: string,
  password?: string
): Promise<number> {
  const result = await runCurl({
    connection,
    url: buildFtpUrl(connection, path, false),
    password,
    maxTime: 20,
    headOnly: true,
  })
  const match = /Content-Length:\s*(\d+)/i.exec(result.output ?? "")
  return match ? Number(match[1]) : 0
}

/** 上传被用户取消。 */
export class UploadCancelledError extends Error {
  constructor() {
    super("已取消")
    this.name = "UploadCancelledError"
  }
}

export type UploadOptions = {
  signal?: AbortSignal
  /** uploaded/total 是字节；speed 是字节/秒（滑窗）。 */
  onProgress?: (uploaded: number, total: number, speed?: number) => void
  /** 单块最长秒数（默认与下载一致 15 秒；主要用于调试/调优）。 */
  chunkSeconds?: number
}

/**
 * 上传每块的秒数（与下载一致）。
 *
 * 上传时本地无法 stat 出“已传多少”，只能问服务器 SIZE，而传输进行中
 * 服务器会提前报出完整大小，所以只能采信块边界的值 —— 进度粒度 = 块长。
 * 速度/ETA 不显示（采样太粗，数字会骗人）。
 */
const UPLOAD_CHUNK_SECONDS = CHUNK_SECONDS

/**
 * 上传单个文件：分块 + APPE 续传。
 * 每块最多 15 秒，块内每 2 秒查一次远端大小作为进度。
 */
export async function uploadFileToFtp(
  connection: FTPConnection,
  localPath: string,
  remotePath: string,
  password?: string,
  options?: UploadOptions
): Promise<number> {
  const localSize = (await FileManager.stat(localPath)).size ?? 0
  const url = buildFtpUrl(connection, remotePath, false)

  if (localSize === 0) {
    // 空文件也要在服务器上创建一个 0 字节文件
    await runCurl({ connection, url, password, maxTime: OP_MAX_TIME, uploadPath: localPath })
    options?.onProgress?.(0, 0)
    return 0
  }

  const samples: { at: number; size: number }[] = []
  const report = (uploaded: number) => {
    const now = Date.now()
    samples.push({ at: now, size: uploaded })
    while (samples.length > 2 && now - samples[0].at > SPEED_WINDOW_MS) {
      samples.shift()
    }
    const first = samples[0]
    const span = (now - first.at) / 1000
    const speed = span >= 1 ? (uploaded - first.size) / span : undefined
    options?.onProgress?.(uploaded, localSize, speed && speed > 0 ? speed : undefined)
  }

  let uploaded = 0
  let lastGrowthAt = Date.now()

  while (true) {
    if (options?.signal?.aborted) throw new UploadCancelledError()

    const result = await runCurl({
      connection,
      url,
      password,
      maxTime: options?.chunkSeconds ?? UPLOAD_CHUNK_SECONDS,
      uploadPath: localPath,
      resume: uploaded > 0,
    })

    const size = await remoteFileSize(connection, remotePath, password)
    if (size > uploaded) {
      uploaded = Math.min(size, localSize)
      lastGrowthAt = Date.now()
      report(uploaded)
    }

    if (uploaded >= localSize) return uploaded

    const code = curlExitCode(result.output)
    if (result.exitCode !== 0 && code !== 28 && !result.timedOut) {
      throw new Error(describeCurlFailure(result.output))
    }
    if (Date.now() - lastGrowthAt >= OTHER_STALL_MS) {
      throw new Error("上传卡住了：服务器超过 30 秒没有接收新数据。")
    }
  }
}

/** 每连接一次发出的命令条数（太多会拉长单次超时风险）。 */
const QUOTE_BATCH = 40

/**
 * 删除远程项目（目录递归）：先递归列出全部内容，
 * 再按「先文件 DELE、后目录 RMD（子目录在前）」分批下发。
 */
export async function deleteFtpEntries(
  connection: FTPConnection,
  entries: FileEntry[],
  password?: string,
  onProgress?: (done: number, total: number) => void
): Promise<void> {
  const files: string[] = []
  const dirs: string[] = []
  const visited = new Set<string>()

  async function walk(entry: FileEntry, depth: number): Promise<void> {
    if (!entry.isDirectory) {
      files.push(entry.path)
      return
    }
    if (depth > 32 || visited.has(entry.path)) return
    visited.add(entry.path)
    let children: FileEntry[] = []
    try {
      children = await listFtp(connection, entry.path, true, password)
    } catch (error) {
      throw new Error(
        `无法读取远程目录：${error instanceof Error ? error.message : String(error)}`
      )
    }
    for (const child of children) {
      await walk(child, depth + 1)
    }
    dirs.push(entry.path)
  }

  for (const entry of entries) {
    await walk(entry, 0)
  }

  const commands = [
    ...files.map(path => `DELE ${commandPath(path)}`),
    ...dirs.map(path => `RMD ${commandPath(path)}`),
  ]
  const total = commands.length
  let done = 0

  for (let index = 0; index < commands.length; index += QUOTE_BATCH) {
    const batch = commands.slice(index, index + QUOTE_BATCH)
    await runFtpCommands(connection, batch, password)
    done += batch.length
    onProgress?.(done, total)
  }

  debugLog("ftp", `deleted ${entries.length} remote item(s), ${total} command(s)`)
}

/** 启动时按当前策略清理 FTP 预览缓存。 */
export async function cleanupFtpPreviews(): Promise<void> {
  try {
    if (getFtpPreviewCacheLimit() === "immediate") {
      // 即时清理模式不保留上次运行遗留的预览
      await clearFtpPreviewCache()
      return
    }
    await enforceFtpPreviewCacheLimit()
  } catch (error) {
    debugLog("ftp", `cleanup previews failed: ${String(error)}`)
  }
}

export function makeConnectionId(): string {
  return newId()
}
