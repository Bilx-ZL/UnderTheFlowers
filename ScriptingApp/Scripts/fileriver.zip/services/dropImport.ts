/**
 * 把从脚本外部拖进来的 `ItemProvider` 解析成 { 路径, 名字, 是否目录 }。
 *
 * 大多数 App 会给 `public.file-url`，`loadURL()` 直接是源文件路径（带原名）；
 * 没有的（照片、部分 App）用 `loadFilePath()`，那是 App Group 里 UUID 命名的
 * 临时副本，名字要按 UTI 补成「导入的文件 …」。
 *
 * 内部拖放已删（脚本内部拖拽 provider 拿不到原名，维护成本不划算），
 * 所以这里只服务外部拖入。
 */

export type DroppedItem = {
  path: string
  name: string
  isDirectory: boolean
}

/** 没有原名时按 UTI 补扩展名。 */
const EXT_BY_TYPE: Record<string, string> = {
  "public.plain-text": ".txt",
  "public.rtf": ".rtf",
  "public.jpeg": ".jpg",
  "public.png": ".png",
  "public.heic": ".heic",
  "public.tiff": ".tiff",
  "public.mpeg-4": ".mp4",
  "public.mpeg-4-audio": ".m4a",
  "public.movie": ".mov",
  "com.adobe.pdf": ".pdf",
  "public.zip-archive": ".zip",
}

/** loadFilePath 的兜底顺序：越具体越靠前。 */
const FALLBACK_TYPES: UTType[] = [
  "public.item",
  "public.data",
  "public.folder",
  "public.image",
  "public.movie",
  "public.plain-text",
]

const UUID_NAME = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i

function pad2(value: number): string {
  return value < 10 ? `0${value}` : String(value)
}

/**
 * provider 给的临时副本名可能是 UUID（相册是 `UUID.jpeg`，部分 App 是光 UUID），
 * 这种名字对人没意义，换成「导入的文件 2026-10-24 23.43.48.jpeg」。
 * 带日期时间是因为一次拖多张很常见，也能隔天区分开。
 */
export function cleanDroppedName(
  raw: string,
  type: UTType,
  isDirectory: boolean
): string {
  const dot = raw.lastIndexOf(".")
  const stem = dot > 0 ? raw.slice(0, dot) : raw
  const ext = dot > 0 ? raw.slice(dot) : ""
  if (!UUID_NAME.test(stem) && !UUID_NAME.test(raw)) return raw

  const now = new Date()
  const date = `${now.getFullYear()}-${pad2(now.getMonth() + 1)}-${pad2(now.getDate())}`
  const time = `${pad2(now.getHours())}.${pad2(now.getMinutes())}.${pad2(now.getSeconds())}`
  const suffix = ext || (isDirectory ? "" : (EXT_BY_TYPE[type] ?? ""))
  return `导入的文件 ${date} ${time}${suffix}`
}

function joinPath(dir: string, name: string): string {
  return dir.replace(/\/+$/, "") + "/" + name
}

function basenameOf(path: string): string {
  const parts = path.split("/").filter(Boolean)
  return parts[parts.length - 1] ?? path
}

function isDirectory(path: string): boolean {
  try {
    return FileManager.isDirectorySync(path)
  } catch {
    return false
  }
}

/** file:// URL → 本地路径（逐段解码，避免路径里的空格/中文被转义）。 */
function pathFromFileUrl(url: string): string | null {
  if (!url.startsWith("file://")) return null
  const raw = url.slice("file://".length)
  try {
    const path = raw
      .split("/")
      .map(segment => (segment ? decodeURIComponent(segment) : ""))
      .join("/")
    return path.length > 0 ? path : null
  } catch {
    return null
  }
}

/** 把单个拖入项解析成 { 路径, 名字, 是否目录 }；拿不到返回 null。 */
export async function resolveAttachment(
  attachment: ItemProvider
): Promise<DroppedItem | null> {
  try {
    if (attachment.hasItemConforming("public.file-url")) {
      const url = await attachment.loadURL()
      if (typeof url === "string") {
        const path = pathFromFileUrl(url)
        if (path) {
          return { path, name: basenameOf(path), isDirectory: isDirectory(path) }
        }
      }
    }
  } catch {
    // 继续走 loadFilePath
  }

  for (const type of FALLBACK_TYPES) {
    try {
      if (!attachment.hasItemConforming(type)) continue
      const path = await attachment.loadFilePath(type)
      if (typeof path !== "string" || path.length === 0) continue
      const dir = isDirectory(path)
      const name = cleanDroppedName(basenameOf(path), type, dir)
      return { path, name, isDirectory: dir }
    } catch {
      // 试下一个类型
    }
  }

  return null
}

export async function resolveAttachments(
  attachments: ItemProvider[]
): Promise<DroppedItem[]> {
  const resolved = await Promise.all(
    attachments.map(attachment => resolveAttachment(attachment))
  )
  const items = resolved.filter((item): item is DroppedItem => item != null)
  return dedupeNames(items)
}

/**
 * 同一批拖入里可能出现重名，必须在这里拆开。
 *
 * `loadFilePath()` 的临时副本是 UUID，`cleanDroppedName()` 会换成
 * 「导入的文件 2026-10-26 08.52.10.jpg」——只到秒，一拖几十个文件就全撞车。
 * 上传端只会在上传前预扫一次远端，批内重名不会被当成冲突，会静默互相覆盖。
 */
function dedupeNames(items: DroppedItem[]): DroppedItem[] {
  const seen = new Map<string, number>()
  return items.map(item => {
    const key = `${item.isDirectory ? "d" : "f"}:${item.name}`
    const count = (seen.get(key) ?? 0) + 1
    seen.set(key, count)
    return count === 1 ? item : { ...item, name: numberedName(item.name, count) }
  })
}

function numberedName(name: string, index: number): string {
  const dot = name.lastIndexOf(".")
  if (dot <= 0) return `${name} ${index}`
  return `${name.slice(0, dot)} ${index}${name.slice(dot)}`
}
