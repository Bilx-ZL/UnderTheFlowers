export type Route = {
  /** 本地挂载 id 或 FTP 连接 id（两者共用一套浏览页路由） */
  mountId: string
  path?: string
}

export function encodeRoute(mountId: string, path?: string): string {
  return JSON.stringify(path ? { mountId, path } : { mountId })
}

export function decodeRoute(value: string): Route | null {
  try {
    const parsed = JSON.parse(value) as Partial<Route>
    if (typeof parsed.mountId !== "string" || parsed.mountId.length === 0) return null
    if (parsed.path != null && typeof parsed.path !== "string") return null
    return { mountId: parsed.mountId, path: parsed.path ?? undefined }
  } catch {
    return null
  }
}
