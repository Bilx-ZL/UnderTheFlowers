/**
 * 「FTP」标签页当前停留的远端目录。
 *
 * 和 localTarget 对称：每个 FTP 浏览页挂载时登记自己，卸载时注销，
 * 栈顶就是用户停留的远端目录 —— 上传的目标就是它。
 */

import type { FTPConnection } from "../types"

export type RemoteTarget = {
  connection: FTPConnection
  name: string
  path: string
}

type Session = { id: number; target: RemoteTarget }

let sessions: Session[] = []
let nextSessionId = 1

export function createRemoteSessionId(): number {
  return nextSessionId++
}

export function setRemoteSession(id: number, target: RemoteTarget): void {
  const index = sessions.findIndex(item => item.id === id)
  if (index >= 0) {
    sessions[index] = { id, target }
    const [session] = sessions.splice(index, 1)
    sessions.push(session)
    return
  }
  sessions.push({ id, target })
}

export function clearRemoteSession(id: number): void {
  sessions = sessions.filter(item => item.id !== id)
}

/** 用户当前停留的远端目录；没有打开任何 FTP 目录时为 null。 */
export function getRemoteTarget(): RemoteTarget | null {
  return sessions.length > 0 ? sessions[sessions.length - 1].target : null
}
