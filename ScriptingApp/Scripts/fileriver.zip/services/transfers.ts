import { FileEntry } from "../types"
import { debugLog } from "./debug"
import { setTasksActive } from "./wakeLock"

export type TransferKind = "copy" | "move" | "delete" | "save" | "share" | "download" | "upload"
export type TransferStatus = "running" | "done" | "failed" | "cancelled"

export type TransferTask = {
  id: string
  kind: TransferKind
  name: string
  destination: string
  progress: number | null
  detail: string
  status: TransferStatus
  error?: string
  /** 是否可以中途取消（目前只有 FTP 下载类任务） */
  cancellable?: boolean
}

let tasks: TransferTask[] = []
const listeners = new Set<(tasks: TransferTask[]) => void>()
let nextId = 1
let panelOpen = false
let panelClosing = false
let panelCleanupTimer: ReturnType<typeof setTimeout> | null = null

const FINISH_HIDE_MS = 30_000
/** 每个已结束任务的移除计时器（面板打开期间清掉，关闭后重新计 30 秒）。 */
const hideTimers = new Map<string, ReturnType<typeof setTimeout>>()
const PROGRESS_EMIT_MS = 100
let emitTimer: ReturnType<typeof setTimeout> | null = null

function emit() {
  if (emitTimer != null) {
    clearTimeout(emitTimer)
    emitTimer = null
  }
  // 任务中心只要还有 running 的任务，就保持不锁屏
  setTasksActive(tasks.some(task => task.status === "running"))
  const snapshot = tasks.slice()
  listeners.forEach(listener => listener(snapshot))
}

function scheduleEmit() {
  if (emitTimer != null) return
  emitTimer = setTimeout(() => {
    emitTimer = null
    emit()
  }, PROGRESS_EMIT_MS)
}

const changeListeners = new Set<(dirs: string[]) => void>()

export function subscribeTransferChanges(
  listener: (dirs: string[]) => void
): () => void {
  changeListeners.add(listener)
  return () => {
    changeListeners.delete(listener)
  }
}

export function notifyTransferChanges(dirs: string[]) {
  changeListeners.forEach(listener => listener(dirs))
}

/** FTP 远端目录的刷新广播（与本地路径分开，避免 "/" 这类路径误匹配）。 */
const remoteChangeListeners = new Set<(dirs: string[]) => void>()

export function subscribeRemoteChanges(
  listener: (dirs: string[]) => void
): () => void {
  remoteChangeListeners.add(listener)
  return () => {
    remoteChangeListeners.delete(listener)
  }
}

export function notifyRemoteChanges(dirs: string[]) {
  remoteChangeListeners.forEach(listener => listener(dirs))
}

function updateTask(id: string, patch: Partial<TransferTask>) {
  tasks = tasks.map(task => (task.id === id ? { ...task, ...patch } : task))
  scheduleEmit()
}

function clearHideTimer(id: string) {
  const timer = hideTimers.get(id)
  if (timer != null) {
    clearTimeout(timer)
    hideTimers.delete(id)
  }
}

function removeTask(id: string) {
  clearHideTimer(id)
  cancelHandlers.delete(id)
  tasks = tasks.filter(task => task.id !== id)
  emit()
}

/** 结束 30 秒后移除；面板打开期间不计时，关闭后再重新计 30 秒。 */
function scheduleHide(id: string) {
  clearHideTimer(id)
  if (panelOpen || panelClosing) return
  hideTimers.set(
    id,
    setTimeout(() => {
      hideTimers.delete(id)
      removeTask(id)
    }, FINISH_HIDE_MS)
  )
}

function addTask(kind: TransferKind, name: string, destination: string): string {
  const id = `transfer-${Date.now()}-${nextId++}`
  // 新任务放最上面
  tasks = [
    {
      id,
      kind,
      name,
      destination,
      progress: kind === "copy" ? 0 : null,
      detail: kind === "delete" ? "正在删除…" : "准备中…",
      status: "running",
    },
    ...tasks,
  ]
  emit()
  return id
}

export function getTasks(): TransferTask[] {
  return tasks.slice()
}

export type ActionTaskHandle = {
  setDetail(detail: string): void
  setProgress(progress: number | null): void
  finish(detail?: string): void
  /** 用户取消了：状态单独标为「已取消」，不跟完成混在一起。 */
  cancel(detail?: string): void
  fail(error: unknown, options?: { alert?: boolean }): void
}

/** 任务 id → 取消回调（由发起方提供）。 */
const cancelHandlers = new Map<string, () => void>()
/** 已请求取消、还没结束的任务：这类任务不再接受进度刷新。 */
const cancellingIds = new Set<string>()

/** 取消一个运行中的任务（只对提供过 onCancel 的任务生效）。 */
export function cancelTask(id: string): void {
  const cancel = cancelHandlers.get(id)
  if (!cancel) return
  debugLog("transfer", `cancel requested: ${id}`)
  cancellingIds.add(id)
  updateTask(id, { detail: "正在取消…" })
  cancel()
}

/**
 * 给「保存到相册 / 共享」这类一次性动作用的轻量任务：
 * 只占右上角进度中心，进度不确定时传 null，完成后 30s 自动消失。
 */
export function startActionTask(
  kind: TransferKind,
  name: string,
  options?: { onCancel?: () => void }
): ActionTaskHandle {
  const id = addTask(kind, name, "")
  if (options?.onCancel) {
    cancelHandlers.set(id, options.onCancel)
    updateTask(id, { cancellable: true })
  }
  return {
    setDetail(detail) {
      // 已请求取消：不再让进度文字盖掉「正在取消…」
      if (cancellingIds.has(id)) return
      updateTask(id, { detail })
    },
    setProgress(progress) {
      if (cancellingIds.has(id)) return
      updateTask(id, { progress })
    },
    finish(detail) {
      cancellingIds.delete(id)
      finishTask(id, detail)
    },
    cancel(detail) {
      cancellingIds.delete(id)
      cancelDoneTask(id, detail)
    },
    fail(error, options) {
      cancellingIds.delete(id)
      failTask(id, error, options?.alert === true)
    },
  }
}

export function subscribeTasks(listener: (tasks: TransferTask[]) => void) {
  listeners.add(listener)
  listener(tasks.slice())
  return () => {
    listeners.delete(listener)
  }
}

/** 任务面板打开时暂缓隐藏已完成的任务；关闭时等 sheet 动画结束后再清理。 */
export function setTransferPanelOpen(open: boolean) {
  if (panelOpen === open) return
  panelOpen = open
  if (panelCleanupTimer != null) {
    clearTimeout(panelCleanupTimer)
    panelCleanupTimer = null
  }
  if (open) {
    panelClosing = false
    // 面板打开时暂停移除已结束的任务
    tasks.forEach(task => {
      if (task.status !== "running") clearHideTimer(task.id)
    })
    return
  }
  panelClosing = true
  panelCleanupTimer = setTimeout(() => {
    panelCleanupTimer = null
    panelClosing = false
    if (panelOpen) return
    // 关闭面板后，已结束的任务重新计 30 秒
    tasks.forEach(task => {
      if (task.status !== "running") scheduleHide(task.id)
    })
  }, 400)
}

function finishTask(id: string, detail = "完成") {
  updateTask(id, { status: "done", progress: 1, detail })
  scheduleHide(id)
}

function cancelDoneTask(id: string, detail = "已取消") {
  updateTask(id, { status: "cancelled", progress: null, detail })
  scheduleHide(id)
}

function failTask(id: string, error: unknown, alert = true) {
  const message = error instanceof Error ? error.message : String(error)
  updateTask(id, { status: "failed", error: message })
  debugLog("transfer", `failed: ${message}`)
  if (alert) void Dialog.alert({ title: "操作失败", message }).catch(() => {})
  scheduleHide(id)
}

function trimTrailingSlash(path: string): string {
  if (path.length > 1 && path.endsWith("/")) return path.replace(/\/+$/, "")
  return path
}

function dirname(path: string): string {
  const index = path.lastIndexOf("/")
  return index <= 0 ? "/" : path.slice(0, index)
}

function basename(path: string): string {
  return trimTrailingSlash(path).split("/").filter(Boolean).pop() ?? path
}

function joinPath(dir: string, name: string): string {
  if (name.startsWith("/")) return name
  return trimTrailingSlash(dir) + "/" + name
}

function isDirectory(stat: { type?: string }): boolean {
  const type = String(stat.type ?? "").toLowerCase()
  return type === "directory" || type.endsWith("directory")
}

async function collectFiles(path: string): Promise<string[]> {
  const stat = await FileManager.stat(path)
  if (!isDirectory(stat)) return [path]

  const files: string[] = []
  const walk = async (dir: string) => {
    const children = await FileManager.readDirectory(dir)
    for (const child of children) {
      const path = joinPath(dir, child)
      const childStat = await FileManager.stat(path)
      if (isDirectory(childStat)) {
        await walk(path)
      } else {
        files.push(path)
      }
    }
  }
  await walk(path)
  return files
}

/** 一批复制/移动的最终计划：entry 是源，name 是落到目标目录时用的名字。 */
export type TransferPlanItem = { entry: FileEntry; name: string }

export type TransferConflict = { name: string; path: string }
export type TransferDecision = "overwrite" | "keepBoth" | "skip"
export type TransferConflictResolver = (
  info: TransferConflict
) => Promise<TransferDecision>

export async function copyTree(
  source: string,
  target: string,
  onFileCopied: () => void,
  resolve?: TransferConflictResolver
): Promise<void> {
  const stat = await FileManager.stat(source)
  if (isDirectory(stat)) {
    if (await FileManager.exists(target)) {
      const targetStat = await FileManager.stat(target)
      if (!isDirectory(targetStat)) {
        // 源是目录、目标是同名文件
        const decision = resolve
          ? await resolve({ name: basename(target), path: target })
          : "overwrite"
        if (decision === "skip") return
        if (decision === "keepBoth") {
          target = joinPath(
            dirname(target),
            await uniqueTargetName(dirname(target), basename(target))
          )
        } else {
          await FileManager.remove(target)
        }
      }
    }
    await FileManager.createDirectory(target, true)
    const children = await FileManager.readDirectory(source)
    for (const child of children) {
      await copyTree(
        joinPath(source, child),
        joinPath(target, basename(child)),
        onFileCopied,
        resolve
      )
    }
    return
  }

  let destination = target
  if (await FileManager.exists(destination)) {
    const decision = resolve
      ? await resolve({ name: basename(target), path: target })
      : "overwrite"
    if (decision === "skip") return
    if (decision === "keepBoth") {
      destination = joinPath(
        dirname(target),
        await uniqueTargetName(dirname(target), basename(target))
      )
    } else {
      await FileManager.remove(destination)
    }
  }
  await FileManager.copyFile(source, destination)
  onFileCopied()
}

export async function validateDestination(
  sourcePath: string,
  destDir: string
): Promise<string | null> {
  const source = trimTrailingSlash(sourcePath)
  const dest = trimTrailingSlash(destDir)
  const name = basename(source)

  if (dest === dirname(source)) return "它已经在这个目录里了。"
  if (dest === source || dest.startsWith(source + "/")) {
    return "不能把文件夹放到它自己里面。"
  }
  return null
}

export async function validateDestinations(
  sources: FileEntry[],
  destDir: string
): Promise<string | null> {
  for (const source of sources) {
    const problem = await validateDestination(source.path, destDir)
    if (problem) {
      return sources.length === 1 ? problem : `「${source.name}」：${problem}`
    }
  }
  return null
}

export function startBatchTransfer(
  kind: "copy" | "move",
  items: TransferPlanItem[],
  destDir: string,
  onDone?: () => void,
  resolve?: TransferConflictResolver
): Promise<void> {
  const affectedDirs = new Set<string>()
  affectedDirs.add(destDir)
  for (const item of items) affectedDirs.add(dirname(item.entry.path))
  const affected = [...affectedDirs]
  const name = items.length === 1 ? items[0].name : `${items.length} 个项目`
  const id = addTask(kind, name, destDir)
  debugLog("transfer", `${kind} batch start: ${items.length} -> ${destDir}`)

  return (async () => {
    if (kind === "copy") {
      updateTask(id, { detail: "正在统计…" })
      const counts: number[] = []
      let total = 0
      for (const item of items) {
        const count = (await collectFiles(item.entry.path)).length
        counts.push(count)
        total += count
      }
      updateTask(id, {
        progress: total === 0 ? null : 0,
        detail: total === 0 ? "正在创建文件夹…" : `0 / ${total} 个文件`,
      })

      let done = 0
      for (let index = 0; index < items.length; index++) {
        const item = items[index]
        let target = joinPath(destDir, item.name)

        // 同名文件夹：先问整个文件夹（覆盖=合并，内部同名文件还会逐个问）
        if (resolve && item.entry.isDirectory && (await FileManager.exists(target))) {
          const stat = await FileManager.stat(target)
          if (isDirectory(stat)) {
            const decision = await resolve({ name: item.name, path: target })
            if (decision === "skip") {
              done += counts[index]
              updateTask(id, {
                progress: total === 0 ? null : done / total,
                detail: total === 0 ? "正在创建文件夹…" : `${done} / ${total} 个文件`,
              })
              continue
            }
            if (decision === "keepBoth") {
              target = joinPath(destDir, await uniqueTargetName(destDir, item.name))
            }
          }
        }

        await copyTree(
          item.entry.path,
          target,
          () => {
            done += 1
            updateTask(id, {
              progress: total === 0 ? null : done / total,
              detail: total === 0 ? "正在创建文件夹…" : `${done} / ${total} 个文件`,
            })
          },
          resolve
        )
      }
    } else {
      let done = 0
      updateTask(id, {
        progress: 0,
        detail: `0 / ${items.length} 个项目`,
      })

      for (const item of items) {
        let target = joinPath(destDir, item.name)
        let merge = false
        if (await FileManager.exists(target)) {
          const stat = await FileManager.stat(target)
          if (isDirectory(stat)) {
            if (resolve) {
              const decision = await resolve({ name: item.name, path: target })
              if (decision === "skip") {
                done += 1
                updateTask(id, {
                  progress: done / items.length,
                  detail: `${done} / ${items.length} 个项目`,
                })
                continue
              }
              if (decision === "keepBoth") {
                target = joinPath(destDir, await uniqueTargetName(destDir, item.name))
              } else {
                // 覆盖 = 合并，内部同名文件逐个问
                merge = true
              }
            } else {
              merge = true
            }
          } else {
            const decision = resolve
              ? await resolve({ name: item.name, path: target })
              : "overwrite"
            if (decision === "skip") {
              done += 1
              updateTask(id, {
                progress: done / items.length,
                detail: `${done} / ${items.length} 个项目`,
              })
              continue
            }
            if (decision === "keepBoth") {
              target = joinPath(destDir, await uniqueTargetName(destDir, item.name))
            } else {
              await FileManager.remove(target)
            }
          }
        }
        if (!merge) {
          try {
            await FileManager.rename(item.entry.path, target)
          } catch (e) {
            // 跨挂载点等情况下 rename 可能失败，退回复制 + 删除
            debugLog("transfer", `rename failed, fallback to copy: ${String(e)}`)
            merge = true
          }
        }
        if (merge) {
          updateTask(id, { detail: `正在移动「${item.name}」…` })
          await copyTree(item.entry.path, target, () => {}, resolve)
          await FileManager.remove(item.entry.path)
        }
        done += 1
        updateTask(id, {
          progress: done / items.length,
          detail: `${done} / ${items.length} 个项目`,
        })
      }
    }

    debugLog("transfer", `${kind} batch done: ${destDir}`)
  })()
    .then(() => {
      finishTask(id)
      onDone?.()
      notifyTransferChanges(affected)
    })
    .catch(error => {
      failTask(id, error)
      onDone?.()
      notifyTransferChanges(affected)
    })
}

export function startBatchDelete(
  entries: FileEntry[],
  onDone?: () => void
): Promise<void> {
  const affected = [...new Set(entries.map(entry => dirname(entry.path)))]
  const name = entries.length === 1 ? entries[0].name : `${entries.length} 个项目`
  const id = addTask("delete", name, "")
  debugLog("transfer", `delete batch start: ${entries.length}`)

  return (async () => {
    let done = 0
    updateTask(id, { progress: 0, detail: `0 / ${entries.length} 个项目` })
    for (const entry of entries) {
      await FileManager.remove(entry.path)
      done += 1
      updateTask(id, {
        progress: done / entries.length,
        detail: `${done} / ${entries.length} 个项目`,
      })
    }
    debugLog("transfer", `delete batch done: ${entries.length}`)
  })()
    .then(() => {
      finishTask(id)
      onDone?.()
      notifyTransferChanges(affected)
    })
    .catch(error => {
      failTask(id, error)
      onDone?.()
      notifyTransferChanges(affected)
    })
}

export function startTransfer(
  kind: "copy" | "move",
  source: FileEntry,
  destDir: string,
  onDone?: () => void
): Promise<void> {
  return startBatchTransfer(kind, [{ entry: source, name: source.name }], destDir, onDone)
}

/** 目标目录已有同名项时，算一个不冲突的名字（name (1) / (2) …）。 */
export async function uniqueTargetName(
  destDir: string,
  name: string
): Promise<string> {
  if (!(await FileManager.exists(joinPath(destDir, name)))) return name
  const dot = name.lastIndexOf(".")
  const base = dot > 0 ? name.slice(0, dot) : name
  const ext = dot > 0 ? name.slice(dot) : ""
  for (let index = 1; index < 500; index++) {
    const next = `${base} (${index})${ext}`
    if (!(await FileManager.exists(joinPath(destDir, next)))) return next
  }
  return `${base}-${Date.now()}${ext}`
}

export function startDelete(entry: FileEntry, onDone?: () => void): Promise<void> {
  return startBatchDelete([entry], onDone)
}
