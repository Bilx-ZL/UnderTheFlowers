/**
 * 「文件」标签页当前停留的本地目录。
 *
 * 每个本地浏览页（BrowserPage，kind === "local"）挂载时登记自己，
 * 卸载时注销；栈顶就是用户停留的目录。挂载列表本身不登记，
 * 所以列表页停留时这里为空 —— 下载就没有目标目录。
 */

export type LocalTarget = {
  mountId: string
  mountName: string
  path: string
}

type Session = { id: number; target: LocalTarget }

let sessions: Session[] = []
let nextSessionId = 1

export function createLocalSessionId(): number {
  return nextSessionId++
}

export function setLocalSession(id: number, target: LocalTarget): void {
  const index = sessions.findIndex(item => item.id === id)
  if (index >= 0) {
    sessions[index] = { id, target }
    const [session] = sessions.splice(index, 1)
    sessions.push(session)
    return
  }
  sessions.push({ id, target })
}

export function clearLocalSession(id: number): void {
  sessions = sessions.filter(item => item.id !== id)
}

/** 用户当前停留的本地目录；停在挂载列表时为 null。 */
export function getLocalTarget(): LocalTarget | null {
  return sessions.length > 0 ? sessions[sessions.length - 1].target : null
}
