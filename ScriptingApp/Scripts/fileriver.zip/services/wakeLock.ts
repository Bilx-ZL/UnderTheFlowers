import { Device } from "scripting"
import { getKeepAwakeDuringTasks } from "./settings"
import { debugLog } from "./debug"

/**
 * 任务进行中不锁屏。
 *
 * Scripting 把 `isIdleTimerDisabled` 包装成 `Device.setWakeLockEnabled(boolean)`
 * （仅主 App 环境可用），配合设置项 `keepAwakeDuringTasks`：
 * 任务中心有 `running` 状态的任务时开锁屏豁免，全部结束后关掉。
 */

let tasksActive = false
/** 上一次真正下发给系统的状态，避免每次任务进度都重复调用。 */
let applied: boolean | null = null

function apply(): void {
  const want = tasksActive && getKeepAwakeDuringTasks()
  if (applied === want) return
  applied = want
  try {
    Device.setWakeLockEnabled(want)
    debugLog("app", `wake lock ${want ? "on" : "off"}`)
  } catch (e) {
    debugLog("app", `wake lock failed: ${String(e)}`)
  }
}

/** 任务中心里是否有运行中的任务（由 transfers 每次状态变化时同步）。 */
export function setTasksActive(active: boolean): void {
  if (tasksActive === active) return
  tasksActive = active
  apply()
}

/** 设置项变化后重新下发一次。 */
export function refreshWakeLock(): void {
  apply()
}

/** 脚本结束时必须解掉锁屏豁免，避免它被永久禁用。 */
export function releaseWakeLock(): void {
  tasksActive = false
  applied = false
  try {
    Device.setWakeLockEnabled(false)
  } catch {
    // 环境不支持时忽略
  }
}
