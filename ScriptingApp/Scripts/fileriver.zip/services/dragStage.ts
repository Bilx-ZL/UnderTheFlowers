/**
 * 拖放的临时文件清理（只服务“从脚本外部拖进来”这一种情况）。
 *
 * `loadFilePath()` 会把内容复制到 App Group/Documents/NSItemProvider/tmp，
 * 文件名是 UUID。导入/上传成功后我们会当场删掉（`removeProviderTempCopy`），
 * 能留到下次启动的都是残渣（失败、被跳过、别的脚本漏的）。
 */

/** App Group/Documents/NSItemProvider/tmp（Scripting 给 loadFilePath 用的临时区）。 */
function providerTempDir(): string {
  return (
    FileManager.appGroupDocumentsDirectory.replace(/\/+$/, "") +
    "/NSItemProvider/tmp"
  )
}

/** Scripting 给临时副本起的名字：UUID（可能带扩展名）。 */
const UUID_LIKE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}(\.[^/]*)?$/i

/**
 * 清空拖入留下的临时副本（启动时调一次）。
 *
 * 为什么是全清而不按年龄：这个目录纯粹是 `loadFilePath()` 的落地区，
 * 用完就删了，能留到下次启动的全是残渣；而且启动那一瞬间不可能有拖入在进行。
 * 另外实测发现：clone 式复制会把**源文件的 birthtime** 也带过来，
 * 所以“按 creationDate 过 24 小时”不可靠。
 *
 * 只动 UUID 命名的条目，别人的东西不碰。
 */
export async function cleanupProviderTempCopies(): Promise<number> {
  const dir = providerTempDir()
  let removed = 0
  try {
    if (!(await FileManager.exists(dir))) return 0
    for (const name of await FileManager.readDirectory(dir)) {
      if (!UUID_LIKE.test(name)) continue
      try {
        await FileManager.remove(dir + "/" + name)
        removed += 1
      } catch {
        // 删不掉就算了（可能正被占用）
      }
    }
  } catch {
    // 清理失败不影响启动
  }
  return removed
}

/**
 * provider 给的临时副本（App Group/NSItemProvider/tmp）用完就删。
 *
 * 不是那个目录里的路径直接忽略。
 */
export function removeProviderTempCopy(path: string): void {
  if (!path.includes("/NSItemProvider/")) return
  void FileManager.remove(path).catch(() => {})
}
