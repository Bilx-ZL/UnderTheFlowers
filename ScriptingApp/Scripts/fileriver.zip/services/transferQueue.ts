import { AbortController } from "scripting"
import type { AbortSignal } from "scripting"
import { DownloadCancelledError } from "./ftp"

/**
 * FTP 传输的全局串行队列。
 *
 * 脚本里所有 FTP 下载都走同一套 curl 分块，同时开两个只会互相拖慢，
 * 所以这里让任务排成一队、一次只跑一个。排队中的任务可以取消
 * （直接从队列里摘掉），正在跑的任务可以取消（abort 信号）。
 */

type QueueEntry = {
  controller: AbortController
  /** 还在排队时被取消：让它以「已取消」结束。 */
  rejectQueued: (error: unknown) => void
  exec: () => void
}

const queue: QueueEntry[] = []
let running = false
const waitingListeners = new Set<() => void>()

function notifyWaiting(): void {
  waitingListeners.forEach(listener => listener())
}

function pump(): void {
  if (running) return
  const entry = queue.shift()
  if (!entry) return
  running = true
  notifyWaiting()
  entry.exec()
}

/** 排队中（含正在跑）的任务数，用于界面显示「等待中」。 */
export function queuedTransferCount(): number {
  return queue.length + (running ? 1 : 0)
}

/** 订阅队列长度变化（任务中心据此刷新「等待中」文案用）。 */
export function subscribeTransferQueue(listener: () => void): () => void {
  waitingListeners.add(listener)
  return () => {
    waitingListeners.delete(listener)
  }
}

/**
 * 把一个传输动作排进全局队列；真正开始时才回调 run。
 *
 * 返回值就是 run 的结果；排队期间被取消会抛 DownloadCancelledError。
 */
export function enqueueTransfer<T>(
  controller: AbortController,
  run: (signal: AbortSignal) => Promise<T>,
  /** 前面还有任务时回调（用于把界面文案切成「等待中」）。 */
  onQueued?: () => void
): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const entry: QueueEntry = {
      controller,
      rejectQueued: reject,
      exec: () => {
        let started: Promise<T>
        try {
          started = run(controller.signal)
        } catch (error) {
          running = false
          reject(error)
          pump()
          return
        }
        started
          .then(resolve, reject)
          .finally(() => {
            running = false
            pump()
          })
      },
    }
    queue.push(entry)
    if (running || queue.length > 1) onQueued?.()
    pump()
  })
}

/**
 * 取消：排队中 → 从队列移除并抛取消；正在跑 → 置 abort。
 * 无论哪种，调用方的 catch 都会收到 DownloadCancelledError。
 */
export function cancelTransfer(controller: AbortController): void {
  const index = queue.findIndex(entry => entry.controller === controller)
  if (index >= 0) {
    const [entry] = queue.splice(index, 1)
    notifyWaiting()
    entry.rejectQueued(new DownloadCancelledError())
    return
  }
  controller.abort()
}
