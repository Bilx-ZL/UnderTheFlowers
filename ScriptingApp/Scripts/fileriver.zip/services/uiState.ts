type Listener = (hidden: boolean) => void

let hidden = false
const listeners = new Set<Listener>()

/** 浏览页进入多选时统一隐藏 Files Tab 的底栏，所有层级共用。 */
export function setTabBarHidden(value: boolean): void {
  if (hidden === value) return
  hidden = value
  listeners.forEach(listener => {
    try {
      listener(value)
    } catch {
      // 忽略单个订阅者异常
    }
  })
}

export function subscribeTabBarHidden(listener: Listener): () => void {
  listeners.add(listener)
  listener(hidden)
  return () => {
    listeners.delete(listener)
  }
}
