import { FileEntry, FTPConnection, Mount } from "../types"
import { resolveMountPath } from "./mounts"
import { listDirectory } from "./localfs"
import {
  createFtpDirectory,
  deleteFtpEntries,
  downloadFtpFile,
  listFtp,
  loadFtpPassword,
  renameFtpEntry,
  type DownloadMode,
  type DownloadOptions,
  type PreparedPreview,
} from "./ftp"

export type PreparePreviewOptions = DownloadOptions & { mode?: DownloadMode }

/**
 * 浏览页的数据源。本地挂载与 FTP 共用同一套列表/导航 UI，
 * 写操作与缩略图能力按 source 的能力开关。
 */
export type FileSource = {
  id: string
  kind: "local" | "ftp"
  name: string
  /** 初始根路径；本地书签离线时为 null */
  rootPath: string | null
  /** 当前是否可用（书签能解析 / FTP 密码还在） */
  available: boolean
  /** 是否允许重命名、删除、新建文件夹 */
  writable: boolean
  /** 是否支持复制/移动（目前仅本地挂载；FTP 待实现） */
  supportsTransfer: boolean
  /** 是否可以生成缩略图（目前仅本地） */
  supportsThumbnails: boolean
  /** 读取目录的超时时间（毫秒） */
  readTimeout: number
  /** 仅本地：传给 DestinationPicker / 传输任务 */
  localMount?: Mount
  /** 仅 FTP：上传时需要真实的连接信息 */
  ftpConnection?: FTPConnection
  unavailableTitle: string
  unavailableMessage: string
  displayLocation(path: string | null): string
  list(path: string, showHidden: boolean): Promise<FileEntry[]>
  preparePreview(
    entry: FileEntry,
    options?: PreparePreviewOptions
  ): Promise<PreparedPreview>
  /** 重命名（同目录内改名）；仅可写数据源提供 */
  rename?(entry: FileEntry, newName: string): Promise<void>
  /** 删除项目（目录递归），onProgress 回调实际完成数 */
  remove?(
    entries: FileEntry[],
    onProgress?: (done: number, total: number) => void
  ): Promise<void>
  /** 新建目录（完整路径） */
  createDirectory?(path: string): Promise<void>
}

function normalizePath(value: string): string {
  return value.length > 1 ? value.replace(/\/+$/, "") : value
}

function localDisplayLocation(mount: Mount, target: string | null): string {
  const mountName = mount.name.trim() || mount.name
  if (!target) return mountName
  const root = resolveMountPath(mount)
  if (!root) return mountName
  const normalizedTarget = normalizePath(target)
  const normalizedRoot = normalizePath(root)
  if (normalizedTarget === normalizedRoot) return mountName
  const prefix = normalizedRoot === "/" ? "/" : normalizedRoot + "/"
  if (!normalizedTarget.startsWith(prefix)) return mountName
  return mountName + "/" + normalizedTarget.slice(prefix.length)
}

export function createLocalSource(mount: Mount): FileSource {
  return {
    id: mount.id,
    kind: "local",
    name: mount.name,
    get rootPath() {
      return resolveMountPath(mount)
    },
    get available() {
      return resolveMountPath(mount) != null
    },
    writable: true,
    supportsTransfer: true,
    supportsThumbnails: true,
    readTimeout: 10000,
    localMount: mount,
    unavailableTitle: "挂载不可用",
    unavailableMessage:
      "目录可能已被移动、删除，或对应的文件书签已在 App 设置中被移除。",
    displayLocation(target) {
      return localDisplayLocation(mount, target)
    },
    async list(path, showHidden) {
      if (!(await FileManager.exists(path))) {
        throw new Error("目录不存在或不可访问")
      }
      return listDirectory(path, showHidden)
    },
    async preparePreview(entry) {
      return { path: entry.path }
    },
  }
}

export function createFtpSource(connection: FTPConnection): FileSource {
  const password = connection.username
    ? loadFtpPassword(connection.id)
    : null
  return {
    id: connection.id,
    kind: "ftp",
    name: connection.name,
    rootPath: connection.path || "/",
    ftpConnection: connection,
    available: !connection.username || password != null,
    writable: true,
    supportsTransfer: false,
    supportsThumbnails: false,
    readTimeout: 80000,
    unavailableTitle: "连接不可用",
    unavailableMessage:
      "连接密码可能已丢失。请在 FTP 页编辑这个连接，重新输入密码后再试。",
    displayLocation(target) {
      if (!target || target === "/") return connection.name
      return connection.name + target
    },
    list(path, showHidden) {
      return listFtp(connection, path, showHidden)
    },
    preparePreview(entry, options) {
      return downloadFtpFile(
        connection,
        entry,
        undefined,
        options?.mode ?? "preview",
        options
      )
    },
    rename(entry, newName) {
      const dir = entry.path.slice(0, entry.path.lastIndexOf("/"))
      const target = dir === "" ? `/${newName}` : `${dir}/${newName}`
      return renameFtpEntry(connection, entry.path, target)
    },
    remove(entries, onProgress) {
      return deleteFtpEntries(connection, entries, undefined, onProgress)
    },
    createDirectory(path) {
      return createFtpDirectory(connection, path)
    },
  }
}
