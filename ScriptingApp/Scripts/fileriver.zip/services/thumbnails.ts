import { FileEntry } from "../types"
import { thumbnailsDir } from "./paths"
import { debugLog } from "./debug"
import {
  getThumbnailCacheLimitBytes,
  getThumbnailsEnabled,
} from "./settings"

/**
 * 图片 / 视频缩略图。
 *
 * 性能约定：
 * - 解码、抽帧、缩放全部丢到后台线程（Thread.runInBackground），主线程只收结果。
 * - 只给「出现在屏幕上」的行发请求，行消失时撤销排队中的任务。
 * - 生成前先等一小段时间，快速滚动时不会白算一堆缩略图。
 * - 内存 LRU（Map 插入顺序）+ 磁盘缓存（Documents/文件流/cache/thumbnails）。
 */

const THUMB_SIZE = { width: 160, height: 160 }
const JPEG_QUALITY = 0.8
const MAX_CONCURRENT = 3
const START_DELAY_MS = 120
const MEMORY_LIMIT = 200
const ENFORCE_DEBOUNCE_MS = 1500

const IMAGE_EXTENSIONS = new Set([
  "jpg",
  "jpeg",
  "png",
  "gif",
  "heic",
  "heif",
  "webp",
  "bmp",
  "tif",
  "tiff",
])

const VIDEO_EXTENSIONS = new Set(["mp4", "mov", "m4v", "3gp"])

export type ThumbnailKind = "image" | "video"

function extensionOf(name: string): string {
  const index = name.lastIndexOf(".")
  if (index <= 0 || index === name.length - 1) return ""
  return name.slice(index + 1).toLowerCase()
}

export function thumbnailKind(entry: FileEntry): ThumbnailKind | null {
  if (entry.isDirectory) return null
  const ext = extensionOf(entry.name)
  if (IMAGE_EXTENSIONS.has(ext)) return "image"
  if (VIDEO_EXTENSIONS.has(ext)) return "video"
  return null
}

export function isThumbnailEligible(entry: FileEntry): boolean {
  return thumbnailKind(entry) != null
}

function hashString(value: string): string {
  let h1 = 0x811c9dc5
  let h2 = 0x01000193
  for (let i = 0; i < value.length; i++) {
    const code = value.charCodeAt(i)
    h1 = Math.imul(h1 ^ code, 0x01000193) >>> 0
    h2 = (Math.imul(h2 ^ code, 0x85ebca6b) + i) >>> 0
  }
  return (
    h1.toString(16).padStart(8, "0") + h2.toString(16).padStart(8, "0")
  )
}

/** 路径 + 大小 + 修改时间 → 稳定的缓存键，文件变了自然换新的缩略图。 */
function cacheKey(entry: FileEntry): string {
  return hashString(`${entry.path}|${entry.size}|${entry.modifiedAt}`)
}

// MARK: - 内存 LRU

const memory = new Map<string, UIImage>()

function memoryGet(key: string): UIImage | null {
  const image = memory.get(key)
  if (!image) return null
  memory.delete(key)
  memory.set(key, image)
  return image
}

function memorySet(key: string, image: UIImage): void {
  if (memory.has(key)) memory.delete(key)
  memory.set(key, image)
  while (memory.size > MEMORY_LIMIT) {
    const oldest = memory.keys().next().value as string | undefined
    if (oldest == null) break
    memory.delete(oldest)
  }
}

// MARK: - 磁盘缓存索引

type CacheRecord = { path: string; size: number; at: number }

// path -> 记录；`at` 是「最近访问」时间，用于 LRU 淘汰
let registry: Map<string, CacheRecord> | null = null
let registryTotal = 0
let registryLoading: Promise<void> | null = null
let registryGeneration = 0

function thumbnailFile(key: string): string {
  return thumbnailsDir() + "/" + key + ".jpg"
}

async function mapLimit<T, R>(
  items: T[],
  limit: number,
  task: (item: T) => Promise<R>
): Promise<R[]> {
  const results: R[] = new Array(items.length)
  let next = 0
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (true) {
      const index = next
      next += 1
      if (index >= items.length) return
      results[index] = await task(items[index])
    }
  })
  await Promise.all(workers)
  return results
}

async function loadRegistry(): Promise<void> {
  if (registry) return
  if (registryLoading) return registryLoading
  registryLoading = (async () => {
    const records: CacheRecord[] = []
    try {
      const dir = thumbnailsDir()
      if (await FileManager.exists(dir)) {
        const names = await FileManager.readDirectory(dir)
        const stats = await mapLimit(names, 8, async name => {
          const path = name.startsWith("/") ? name : dir + "/" + name
          try {
            const stat = await FileManager.stat(path)
            return {
              path,
              size: stat.size ?? 0,
              at: stat.modificationDate ?? 0,
            } as CacheRecord
          } catch {
            return null
          }
        })
        for (const item of stats) if (item) records.push(item)
      }
    } catch {
      // 目录不可读时按空缓存处理
    }
    records.sort((a, b) => a.at - b.at)
    const map = new Map<string, CacheRecord>()
    for (const record of records) map.set(record.path, record)
    registry = map
    registryTotal = records.reduce((sum, item) => sum + item.size, 0)
    registryGeneration += 1
    registryLoading = null
  })()
  return registryLoading
}

let enforceTimer: number | undefined
let enforceChain: Promise<void> = Promise.resolve()

function scheduleEnforce(): void {
  if (enforceTimer !== undefined) return
  enforceTimer = setTimeout(() => {
    enforceTimer = undefined
    enforceChain = enforceChain.then(() => enforceCacheLimit()).catch(() => {})
  }, ENFORCE_DEBOUNCE_MS)
}

/**
 * 超过上限时：从最久未访问的开始删，一次至少释放「上限的 1/3」，避免刚删完又立刻触发。
 */
export async function enforceCacheLimit(): Promise<void> {
  await loadRegistry()
  const map = registry
  if (!map) return
  const generation = registryGeneration

  const limit = getThumbnailCacheLimitBytes()
  if (!isFinite(limit) || limit <= 0) return
  // 没超过上限就不动缓存；否则一次至少释放上限的 1/3
  if (registryTotal <= limit) return
  const records = Array.from(map.values()).sort((a, b) => a.at - b.at)
  const targetFree = limit / 3
  let freed = 0
  let removed = 0
  for (const record of records) {
    if (registryGeneration !== generation) return
    if (freed >= targetFree && registryTotal <= limit) break
    try {
      await FileManager.remove(record.path)
      removed += 1
    } catch {
      // 文件可能已被外部删掉，仍按释放计算
    }
    freed += record.size
    registryTotal = Math.max(0, registryTotal - record.size)
    map.delete(record.path)
    const key = record.path.split("/").pop()?.replace(/\.jpg$/i, "")
    if (key) memory.delete(key)
  }
  if (removed > 0) {
    debugLog(
      "thumb",
      `cache evicted ${removed} file(s), freed ${freed} bytes, ${registryTotal} left`
    )
  }
}

/** 命中磁盘缓存时刷新访问时间，让淘汰更接近 LRU。 */
function touchCacheRecord(key: string): void {
  if (!registry) return
  const record = registry.get(thumbnailFile(key))
  if (record) record.at = Date.now()
}

export async function getThumbnailCacheSize(): Promise<number> {
  await loadRegistry()
  return registryTotal
}

/** 清空内存与磁盘缓存，返回释放的字节数。 */
export async function clearThumbnailCache(): Promise<number> {
  memory.clear()
  await loadRegistry()
  const records = registry ? Array.from(registry.values()) : []
  registry = new Map()
  registryTotal = 0
  registryGeneration += 1
  let freed = 0
  for (const record of records) {
    try {
      await FileManager.remove(record.path)
      freed += record.size
    } catch {
      // 忽略单个文件删除失败
    }
  }
  try {
    const dir = thumbnailsDir()
    if (await FileManager.exists(dir)) await FileManager.remove(dir)
  } catch {
    // 目录可能已被上面的删除清空
  }
  debugLog("thumb", `cache cleared, freed ${freed} bytes`)
  return freed
}

// MARK: - 生成

async function persistThumbnail(key: string, image: UIImage): Promise<void> {
  try {
    const dir = thumbnailsDir()
    if (!(await FileManager.exists(dir))) {
      await FileManager.createDirectory(dir, true)
    }
    const data = await Thread.runInBackground(() =>
      image.toJPEGData(JPEG_QUALITY)
    )
    if (!data) return
    const path = thumbnailFile(key)
    await FileManager.writeAsData(path, data)
    let size = 0
    try {
      size = (await FileManager.stat(path)).size ?? 0
    } catch {
      // 拿不到大小时按 0 记，只影响上限统计精度
    }
    await loadRegistry()
    if (registry) {
      const existing = registry.get(path)
      if (existing) {
        registryTotal += size - existing.size
        existing.size = size
        existing.at = Date.now()
      } else {
        registry.set(path, { path, size, at: Date.now() })
        registryTotal += size
      }
      scheduleEnforce()
    }
  } catch (error) {
    debugLog("thumb", `write failed: ${String(error)}`)
  }
}

async function generateImageThumbnail(entry: FileEntry): Promise<UIImage | null> {
  return Thread.runInBackground(() => {
    const image = UIImage.fromFile(entry.path)
    if (!image) return null
    return image.preparingThumbnail(THUMB_SIZE)
  })
}

async function generateVideoThumbnail(entry: FileEntry): Promise<UIImage | null> {
  let asset: AVAsset | null = null
  try {
    asset = new AVAsset(entry.path)
    let seconds = 0.5
    try {
      const duration = await asset.loadDuration()
      const total = duration.seconds
      if (isFinite(total) && total > 0) {
        seconds = Math.min(1, Math.max(0.1, total * 0.1))
      }
    } catch {
      // 拿不到时长时退回 0.5s
    }
    const result = await asset.generateImage(
      MediaTime.make({ seconds, preferredTimescale: 600 }),
      {
        maximumSize: { width: 480, height: 480 },
        appliesPreferredTrackTransform: true,
      }
    )
    return await Thread.runInBackground(() =>
      result.image.preparingThumbnail(THUMB_SIZE)
    )
  } catch {
    return null
  } finally {
    try {
      asset?.dispose()
    } catch {
      // 忽略释放异常
    }
  }
}

async function generateThumbnail(entry: FileEntry): Promise<UIImage | null> {
  const kind = thumbnailKind(entry)
  if (kind === "image") return generateImageThumbnail(entry)
  if (kind === "video") return generateVideoThumbnail(entry)
  return null
}

// MARK: - 队列

type PendingJob = {
  entry: FileEntry
  key: string
  callbacks: Set<(image: UIImage | null) => void>
  timer?: number
  canceled: boolean
}

const queue: PendingJob[] = []
const pendingByKey = new Map<string, PendingJob>()
let active = 0

function deliver(job: PendingJob, image: UIImage | null): void {
  if (pendingByKey.get(job.key) === job) pendingByKey.delete(job.key)
  const callbacks = Array.from(job.callbacks)
  job.callbacks.clear()
  for (const callback of callbacks) {
    try {
      callback(image)
    } catch {
      // 单个订阅者异常不影响其他人
    }
  }
}

async function runJob(job: PendingJob): Promise<void> {
  active += 1
  try {
    let image: UIImage | null = null
    const file = thumbnailFile(job.key)
    try {
      if (await FileManager.exists(file)) {
        const data = await FileManager.readAsData(file)
        image = await Thread.runInBackground(() => {
          const cached = UIImage.fromData(data)
          if (!cached) return null
          // 磁盘里已经是缩略图尺寸：跳过缩放（实测 0.05ms vs 0.65ms），
          // 真正的解码交给渲染层异步完成
          if (
            cached.width <= THUMB_SIZE.width &&
            cached.height <= THUMB_SIZE.height
          ) {
            return cached
          }
          return cached.preparingThumbnail(THUMB_SIZE)
        })
      }
    } catch {
      image = null
    }

    if (image) touchCacheRecord(job.key)

    if (!image) {
      image = await generateThumbnail(job.entry)
      if (image) await persistThumbnail(job.key, image)
    }

    if (image) memorySet(job.key, image)
    deliver(job, image)
  } catch (error) {
    debugLog("thumb", `generate failed: ${String(error)}`)
    deliver(job, null)
  } finally {
    active -= 1
    pump()
  }
}

function pump(): void {
  while (active < MAX_CONCURRENT && queue.length > 0) {
    const job = queue.shift()
    if (!job || job.canceled) continue
    runJob(job)
  }
}

/**
 * 请求某行的缩略图。回调只在主线程被调用；返回函数用于取消（行滑出屏幕时）。
 */
export function requestThumbnail(
  entry: FileEntry,
  onReady: (image: UIImage | null) => void
): () => void {
  if (!getThumbnailsEnabled() || !isThumbnailEligible(entry)) {
    return () => {}
  }

  const key = cacheKey(entry)
  const cached = memoryGet(key)
  if (cached) {
    touchCacheRecord(key)
    onReady(cached)
    return () => {}
  }

  let job = pendingByKey.get(key)
  if (!job) {
    job = {
      entry,
      key,
      callbacks: new Set(),
      canceled: false,
    }
    pendingByKey.set(key, job)
    const created = job
    created.timer = setTimeout(() => {
      created.timer = undefined
      if (created.canceled) return
      queue.push(created)
      pump()
    }, START_DELAY_MS)
  }

  job.callbacks.add(onReady)

  return () => {
    const target = job
    if (!target) return
    target.callbacks.delete(onReady)
    if (target.callbacks.size > 0) return
    target.canceled = true
    if (target.timer !== undefined) {
      clearTimeout(target.timer)
      target.timer = undefined
    }
    if (pendingByKey.get(target.key) === target) {
      pendingByKey.delete(target.key)
    }
    const index = queue.indexOf(target)
    if (index >= 0) queue.splice(index, 1)
  }
}

/** 关闭缩略图时调用，立刻释放内存中的解码数据（磁盘缓存保留）。 */
export function clearThumbnailMemoryCache(): void {
  memory.clear()
}
