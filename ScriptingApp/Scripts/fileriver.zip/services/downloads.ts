import { FileEntry } from "../types"
import type { AbortSignal } from "scripting"
import { DownloadCancelledError, buildFtpUrl, loadFtpPassword } from "./ftp"
import { downloadStageRoot, shareStageRoot } from "./paths"
import type { FileSource } from "./source"

/** 把数据源里的文件（含目录递归）下载到本地目录。 */

function joinPath(dir: string, name: string): string {
  if (dir === "") return name
  return dir.endsWith("/") ? dir + name : dir + "/" + name
}

function quoteSingle(value: string): string {
  return `'${value.replace(/'/g, `'\\''`)}'`
}

function delay(ms: number): Promise<void> {
  return new Promise<void>(resolve => setTimeout(resolve, ms))
}

/**
 * 批量下载参数。
 *
 * 脚本只有一套 curl，逐个文件起进程意味着一文件一次 FTP 登录，
 * 小文件时开销占比极高（实测 208ms/文件 → 批量 92ms/文件）。
 * 所以这里把多个 URL 塞进同一条 curl 命令，复用同一条连接。
 */
const BATCH_MAX_FILES = 32
/** 一组最多这么多字节：太大会拉长取消的响应时间 */
const BATCH_MAX_BYTES = 32 * 1024 * 1024
/** 单次 curl 的最长运行时间，也是取消的响应上限（到点就退出，下一轮 -C - 续） */
const BATCH_MAX_SECONDS = 15
/** 单个文件最多尝试几次（每次最多 BATCH_MAX_SECONDS 秒） */
const MAX_ATTEMPTS = 4
const BATCH_CONNECT_TIMEOUT = 12

type Planned = { entry: FileEntry; dirs: string[] }

async function collect(
  source: FileSource,
  entries: FileEntry[],
  dirs: string[],
  out: Planned[]
): Promise<void> {
  for (const entry of entries) {
    if (entry.isDirectory) {
      let children: FileEntry[] = []
      try {
        children = await source.list(entry.path, true)
      } catch {
        continue
      }
      await collect(source, children, [...dirs, entry.name], out)
    } else {
      out.push({ entry, dirs })
    }
  }
}

async function ensureDirectory(path: string): Promise<void> {
  if (await FileManager.exists(path)) return
  await FileManager.createDirectory(path, true)
}

/** 同名时自动加「 (1)」，不覆盖用户已有文件。 */
async function uniqueDestination(dir: string, name: string): Promise<string> {
  const candidate = joinPath(dir, name)
  if (!(await FileManager.exists(candidate))) return candidate
  const dot = name.lastIndexOf(".")
  const base = dot > 0 ? name.slice(0, dot) : name
  const ext = dot > 0 ? name.slice(dot) : ""
  for (let index = 1; index < 500; index++) {
    const next = joinPath(dir, `${base} (${index})${ext}`)
    if (!(await FileManager.exists(next))) return next
  }
  return joinPath(dir, `${base}-${Date.now()}${ext}`)
}

async function fileSize(path: string): Promise<number> {
  try {
    const stat = await FileManager.stat(path)
    return stat.size ?? 0
  } catch {
    return -1
  }
}

export type ConflictInfo = {
  /** 文件（或目录内的文件）名 */
  name: string
  /** 本地目标路径 */
  path: string
  /** 第几个冲突（1 起） */
  index: number
  /** 冲突总数 */
  total: number
}

export type ConflictDecision = "overwrite" | "skip" | "keepBoth"

export type DownloadFailure = { name: string; message: string }

export type DownloadResult = {
  /** 实际写盘的文件数 */
  saved: number
  /** 因同名被跳过的文件数 */
  skipped: number
  /** 计划下载的文件总数（目录已展开） */
  total: number
  /** 本次写过的本地目录（用于通知浏览页静默刷新） */
  dirs: string[]
  failed: DownloadFailure[]
}

/** 单个文件的字节级进度（每秒轮询得到）。 */
export type DownloadFileStats = {
  loaded: number
  total: number
  /** 字节/秒，刚开头或无法计算时为 undefined */
  bytesPerSecond?: number
}

export type DownloadToDirOptions = {
  source: FileSource
  entries: FileEntry[]
  targetDir: string
  /** 取消信号（批与批之间检查，单批最长 BATCH_MAX_SECONDS 秒） */
  signal?: AbortSignal
  /** 目录展开完成，拿到文件总数 */
  onPlan?: (total: number) => void
  onProgress?: (done: number, total: number) => void
  /** 当前正在处理的文件名，用于任务副标题 */
  onName?: (name: string) => void
  /** 当前文件已下载比例 0~1（字节级，每秒一个采样） */
  onFileProgress?: (fraction: number, stats?: DownloadFileStats) => void
  /**
   * 目标目录已有同名文件时调用。
   * 不传则保持旧行为：自动改名成「 (1)」不覆盖。
   */
  onConflict?: (info: ConflictInfo) => Promise<ConflictDecision>
}

/** 一个待下载文件：目标路径已定，暂存路径稍后填。 */
type Job = {
  item: Planned
  dir: string
  exact: string
  destination: string
  staged: string
  /** 远端声明大小；0 表示未知 */
  bytes: number
  done: boolean
  attemptsLeft: number
}

export async function downloadEntriesToDir(
  options: DownloadToDirOptions
): Promise<DownloadResult> {
  const planned: Planned[] = []
  await collect(options.source, options.entries, [], planned)

  const dirOf = (item: Planned): string => {
    let dir = options.targetDir
    for (const segment of item.dirs) dir = joinPath(dir, segment)
    return dir
  }

  // 每个本地目录只列一次，得到目录内已有文件名（比逐文件 stat 便宜得多）
  const dirNames = new Map<string, Set<string>>()
  const namesIn = async (dir: string): Promise<Set<string>> => {
    const cached = dirNames.get(dir)
    if (cached) return cached
    let names: Set<string>
    try {
      names = new Set(await FileManager.readDirectory(dir))
    } catch {
      names = new Set()
    }
    dirNames.set(dir, names)
    return names
  }
  const rememberName = (dir: string, name: string) => {
    const set = dirNames.get(dir)
    if (set) set.add(name)
    else dirNames.set(dir, new Set([name]))
  }

  // 预扫描冲突（每个目录只列一次），好在提示里显示「第几个 / 共几个」
  const conflictIndexes = new Set<number>()
  for (let index = 0; index < planned.length; index++) {
    const item = planned[index]
    const names = await namesIn(dirOf(item))
    if (names.has(item.entry.name)) conflictIndexes.add(index)
  }

  options.onPlan?.(planned.length)

  let done = 0
  let saved = 0
  let skipped = 0
  let asked = 0
  const touchedDirs = new Set<string>([options.targetDir])
  const failed: DownloadFailure[] = []

  // ── 阶段一：定下每项的目标路径（冲突在这里问完） ──
  const jobs: Job[] = []
  for (let index = 0; index < planned.length; index++) {
    const item = planned[index]
    const dir = dirOf(item)
    const exact = joinPath(dir, item.entry.name)
    {
      let chain = options.targetDir
      touchedDirs.add(chain)
      for (const segment of item.dirs) {
        chain = joinPath(chain, segment)
        touchedDirs.add(chain)
      }
    }

    let destination = exact
    if (conflictIndexes.has(index)) {
      if (!options.onConflict) {
        destination = await uniqueDestination(dir, item.entry.name)
      } else {
        asked += 1
        const decision = await options.onConflict({
          name: item.entry.name,
          path: exact,
          index: asked,
          total: conflictIndexes.size,
        })
        if (decision === "skip") {
          skipped += 1
          done += 1
          options.onProgress?.(done, planned.length)
          continue
        }
        if (decision === "keepBoth") {
          destination = await uniqueDestination(dir, item.entry.name)
        }
      }
    }

    jobs.push({
      item,
      dir,
      exact,
      destination,
      staged: "",
      bytes: item.entry.size > 0 ? item.entry.size : 0,
      done: false,
      attemptsLeft: MAX_ATTEMPTS,
    })
  }

  /** 把暂存文件改名入位（同一卷内是改名，不搬数据；跨卷或 FileProvider 才退化成复制）。 */
  const commit = async (job: Job) => {
    await ensureDirectory(job.dir)
    if (job.destination === job.exact && (await FileManager.exists(job.exact))) {
      await FileManager.remove(job.exact)
    }
    try {
      await FileManager.rename(job.staged, job.destination)
    } catch {
      await FileManager.copyFile(job.staged, job.destination)
      await FileManager.remove(job.staged).catch(() => {})
    }
    rememberName(job.dir, job.destination.split("/").pop() ?? job.item.entry.name)
    saved += 1
    done += 1
    options.onProgress?.(done, planned.length)
  }

  const connection = options.source.ftpConnection
  const canBatch = options.source.kind === "ftp" && connection != null

  if (!canBatch) {
    // 非 FTP 数据源没有“批量登录”这回事，保持原来的逐文件路径
    for (const job of jobs) {
      if (options.signal?.aborted) throw new DownloadCancelledError()
      options.onName?.(job.item.entry.name)
      try {
        const prepared = await options.source.preparePreview(job.item.entry, {
          mode: "download",
          signal: options.signal,
          onProgress: (loaded, totalBytes, speed) => {
            if (totalBytes > 0) {
              options.onFileProgress?.(Math.min(1, loaded / totalBytes), {
                loaded,
                total: totalBytes,
                bytesPerSecond: speed,
              })
            }
          },
        })
        try {
          if (job.destination === job.exact && (await FileManager.exists(job.exact))) {
            await FileManager.remove(job.exact)
          }
          await FileManager.copyFile(prepared.path, job.destination)
        } finally {
          prepared.cleanup?.()
        }
        rememberName(job.dir, job.destination.split("/").pop() ?? job.item.entry.name)
        saved += 1
      } catch (e: any) {
        if (e instanceof DownloadCancelledError) throw e
        failed.push({ name: job.item.entry.name, message: String(e?.message ?? e) })
      }
      done += 1
      options.onProgress?.(done, planned.length)
    }
    return { saved, skipped, total: planned.length, dirs: [...touchedDirs], failed }
  }

  // ── 阶段二：批量下载到暂存 ──
  const password = loadFtpPassword(connection.id) ?? ""
  const auth = connection.username ? `${connection.username}:${password}` : null
  const stageRoot = joinPath(
    downloadStageRoot(),
    `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
  )

  const isComplete = async (job: Job): Promise<boolean> => {
    const size = await fileSize(job.staged)
    if (size < 0) return false
    if (job.bytes > 0) return size >= job.bytes
    return size > 0
  }

  /** 从待下载队列里切一组：文件数、字节数都设上限；大文件/未知大小单独成组。 */
  const nextBatch = (pending: Job[]): Job[] => {
    const batch: Job[] = []
    let bytes = 0
    for (const job of pending) {
      if (batch.length === 0) {
        batch.push(job)
        bytes += job.bytes
        if (job.bytes === 0 || job.bytes > BATCH_MAX_BYTES) break
        continue
      }
      if (
        batch.length >= BATCH_MAX_FILES ||
        job.bytes === 0 ||
        job.bytes > BATCH_MAX_BYTES ||
        bytes + job.bytes > BATCH_MAX_BYTES
      ) {
        break
      }
      batch.push(job)
      bytes += job.bytes
    }
    return batch
  }

  /** 一条 curl 跑一组 URL，同时每秒采一次当前文件的字节数。 */
  const runBatch = async (batch: Job[]) => {
    const parts = [
      "curl",
      "-sS",
      "--connect-timeout",
      String(BATCH_CONNECT_TIMEOUT),
      "--max-time",
      String(BATCH_MAX_SECONDS),
      "--ftp-pasv",
      // 每个 -o 各自按本地已有大小续传（已验证多 URL 逐个生效）
      "-C",
      "-",
    ]
    if (connection.secure) parts.push("--ssl-reqd")
    if (connection.insecure) parts.push("--insecure")
    if (auth) parts.push("-u", quoteSingle(auth))
    for (const job of batch) {
      parts.push(quoteSingle(buildFtpUrl(connection, job.item.entry.path, false)))
      parts.push("-o", quoteSingle(job.staged))
    }

    let finished = false
    const wakeBox: { fn: (() => void) | null } = { fn: null }
    let cursor = 0
    let lastAt = Date.now()
    let lastBytes = 0

    const ticker = (async () => {
      while (!finished) {
        await new Promise<void>(resolve => {
          wakeBox.fn = resolve
          setTimeout(resolve, 1000)
        })
        wakeBox.fn = null
        if (finished) break
        while (cursor < batch.length) {
          const job = batch[cursor]
          const size = await fileSize(job.staged)
          const size0 = Math.max(0, size)
          if (job.bytes > 0 && size0 >= job.bytes) {
            cursor += 1
            continue
          }
          const now = Date.now()
          const span = (now - lastAt) / 1000
          const speed =
            span > 0.3 && size0 >= lastBytes ? (size0 - lastBytes) / span : undefined
          lastAt = now
          lastBytes = size0
          options.onName?.(job.item.entry.name)
          options.onFileProgress?.(
            job.bytes > 0 ? Math.min(1, size0 / job.bytes) : 0,
            { loaded: size0, total: job.bytes, bytesPerSecond: speed }
          )
          break
        }
      }
    })()

    try {
      return await Shell.run(parts.join(" "))
    } finally {
      finished = true
      wakeBox.fn?.()
      await ticker.catch(() => {})
    }
  }

  try {
    await FileManager.createDirectory(stageRoot, true)
    for (let index = 0; index < jobs.length; index++) {
      jobs[index].staged = joinPath(stageRoot, String(index))
    }

    // 上一轮留下的半成品（同一批里重试时会用到）
    for (const job of jobs) {
      if (await isComplete(job)) job.done = true
    }

    let pending = jobs.filter(job => !job.done)
    let stall = 0

    while (pending.length > 0) {
      if (options.signal?.aborted) throw new DownloadCancelledError()

      const batch = nextBatch(pending)
      const batchSet = new Set(batch)

      // 记下这一批开始前的字节数，用来判断“有没有进展”：
      // 慢网下一个大文件可能拍换好几刀才下完，不能因为没“整文件完成”就当停滞
      const sizesBefore = new Map<Job, number>()
      for (const job of batch) sizesBefore.set(job, await fileSize(job.staged))

      await runBatch(batch)

      const still: Job[] = []
      let grew = false
      for (const job of batch) {
        if (await isComplete(job)) {
          await commit(job)
          grew = true
          continue
        }
        const size = await fileSize(job.staged)
        const before = sizesBefore.get(job) ?? -1
        if (size > before) {
          // 有进展：重置尝试次数，允许慢文件多拍几刀
          grew = true
          job.attemptsLeft = MAX_ATTEMPTS
        } else {
          job.attemptsLeft -= 1
        }
        if (job.attemptsLeft > 0) still.push(job)
        else failed.push({ name: job.item.entry.name, message: "下载未完成" })
      }

      pending = [...still, ...pending.filter(job => !batchSet.has(job))]
      stall = grew ? 0 : stall + 1
      if (stall >= MAX_ATTEMPTS) {
        for (const job of pending) {
          failed.push({ name: job.item.entry.name, message: "下载未完成" })
        }
        pending = []
      }
    }
  } finally {
    await FileManager.remove(stageRoot).catch(() => {})
  }

  return { saved, skipped, total: planned.length, dirs: [...touchedDirs], failed }
}

/**
 * 清空共享用的暂存目录（启动时调一次）。
 *
 * 共享结束后会主动删掉自己的那一层；能留到下次启动的，都是 App 被中断的残留。
 */
export async function cleanupShareStage(): Promise<void> {
  try {
    const root = shareStageRoot()
    if (!(await FileManager.exists(root))) return
    for (const name of await FileManager.readDirectory(root)) {
      await FileManager.remove(root + "/" + name).catch(() => {})
    }
  } catch {
    // 清理失败不影响启动
  }
}

/** 清空批量下载的暂存目录（启动时调一次），同 cleanupShareStage。 */
export async function cleanupDownloadStage(): Promise<void> {
  try {
    const root = downloadStageRoot()
    if (!(await FileManager.exists(root))) return
    for (const name of await FileManager.readDirectory(root)) {
      await FileManager.remove(root + "/" + name).catch(() => {})
    }
  } catch {
    // 清理失败不影响启动
  }
}
