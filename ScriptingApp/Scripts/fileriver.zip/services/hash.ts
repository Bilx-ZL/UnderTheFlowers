/**
 * 本地文件的校验值。
 *
 * 走内嵌 shell 的 `openssl dgst`，是流式计算 —— 不会把整个文件读进内存
 * （`Crypto.md5(data)` 那种写法遇到几百 MB 会爆内存）。
 *
 * 实测（Scripting 内嵌 ios_system）：
 *  - `md5 -q` 输出为空，不能用；
 *  - `openssl dgst -md5|-sha1|-sha256` 可用，输出形如 `SHA256(/path/a b'c.txt)= 7e87…`；
 *  - `shasum` / `sha256sum` 不存在。
 */

export type HashAlgorithm = "md5" | "sha1" | "sha256"

export const HASH_ALGORITHMS: { id: HashAlgorithm; label: string }[] = [
  { id: "md5", label: "MD5" },
  { id: "sha1", label: "SHA-1" },
  { id: "sha256", label: "SHA-256" },
]

/** 单引号包裹 + 转义内部单引号，路径里有空格/中文/引号都能过。 */
function shellQuote(path: string): string {
  return "'" + path.replace(/'/g, "'\\''") + "'"
}

export async function hashFile(
  path: string,
  algorithm: HashAlgorithm
): Promise<string> {
  const result = await Shell.run(`openssl dgst -${algorithm} ${shellQuote(path)}`)
  if (result.exitCode !== 0) {
    throw new Error(result.output.trim() || `openssl 退出码 ${result.exitCode}`)
  }
  const marker = ")= "
  const index = result.output.lastIndexOf(marker)
  const value = (
    index >= 0 ? result.output.slice(index + marker.length) : result.output
  ).trim()
  if (!/^[0-9a-f]+$/i.test(value)) throw new Error("无法解析校验值")
  return value.toLowerCase()
}
