/**
 * 全选模式下的「取消勾选」集合。
 *
 * 放在页面状态里会导致每次勾选都重渲染整个列表（几百行 × contextMenu），
 * 这里改成按 path 订阅：勾一行只通知那一行的小组件，合计只通知计数。
 */
export type SelectionCheckStore = {
  isChecked(path: string): boolean
  toggle(path: string): void
  clear(): void
  deselectedPaths(): Set<string>
  deselectedCount(): number
  subscribePath(path: string, listener: () => void): () => void
  subscribeSummary(listener: () => void): () => void
}

export function createSelectionCheckStore(): SelectionCheckStore {
  const deselected = new Set<string>()
  const pathListeners = new Map<string, Set<() => void>>()
  const summaryListeners = new Set<() => void>()

  function notifyPath(path: string): void {
    const listeners = pathListeners.get(path)
    if (!listeners) return
    listeners.forEach(listener => {
      try {
        listener()
      } catch {
        // 单个订阅者异常不影响其他行
      }
    })
  }

  function notifySummary(): void {
    summaryListeners.forEach(listener => {
      try {
        listener()
      } catch {
        // 忽略
      }
    })
  }

  return {
    isChecked(path) {
      return !deselected.has(path)
    },
    toggle(path) {
      if (deselected.has(path)) deselected.delete(path)
      else deselected.add(path)
      notifyPath(path)
      notifySummary()
    },
    clear() {
      if (deselected.size === 0) return
      const paths = Array.from(deselected)
      deselected.clear()
      paths.forEach(notifyPath)
      notifySummary()
    },
    deselectedPaths() {
      return new Set(deselected)
    },
    deselectedCount() {
      return deselected.size
    },
    subscribePath(path, listener) {
      let listeners = pathListeners.get(path)
      if (!listeners) {
        listeners = new Set()
        pathListeners.set(path, listeners)
      }
      listeners.add(listener)
      return () => {
        const current = pathListeners.get(path)
        if (!current) return
        current.delete(listener)
        if (current.size === 0) pathListeners.delete(path)
      }
    },
    subscribeSummary(listener) {
      summaryListeners.add(listener)
      return () => {
        summaryListeners.delete(listener)
      }
    },
  }
}
