const FOLDER_NAME = "文件流"
const CACHE_FOLDER = "cache"
const THUMBNAILS_FOLDER = "thumbnails"
const FTP_PREVIEW_FOLDER = "ftp-preview"

function join(base: string, child: string): string {
  return base.replace(/\/+$/, "") + "/" + child
}

/** 其余数据：App 根目录 Documents/文件流（文件 App 的“我的 iPhone/Scripting”下可见）。 */
export function dataDir(): string {
  return join(FileManager.documentsDirectory, FOLDER_NAME)
}

/** 设置：iCloud Documents/文件流；iCloud 不可用时返回 null。 */
export function settingsDir(): string | null {
  try {
    if (!FileManager.isiCloudEnabled) return null
    return join(FileManager.iCloudDocumentsDirectory, FOLDER_NAME)
  } catch {
    return null
  }
}

export function iCloudPath(name: string): string | null {
  const dir = settingsDir()
  return dir ? join(dir, name) : null
}

/** 本地缓存根目录：Documents/文件流/cache（“我的 iPhone/Scripting/文件流/cache”）。 */
export function cacheDir(): string {
  return join(dataDir(), CACHE_FOLDER)
}

/** 缩略图缓存：Documents/文件流/cache/thumbnails。 */
export function thumbnailsDir(): string {
  return join(cacheDir(), THUMBNAILS_FOLDER)
}

/** FTP 快速预览临时文件：Documents/文件流/cache/ftp-preview。 */
export function ftpPreviewDir(): string {
  return join(cacheDir(), FTP_PREVIEW_FOLDER)
}

/** 共享前的临时暂存根目录：Documents/文件流/cache/sharestage。 */
export function shareStageRoot(): string {
  return join(cacheDir(), "sharestage")
}

/** 批量下载的临时暂存根目录：Documents/文件流/cache/downloadstage。
 *  碎片只会出现在这里，目的地只收改名入位的完整文件。 */
export function downloadStageRoot(): string {
  return join(cacheDir(), "downloadstage")
}

/** 确保缓存目录存在。 */
export async function ensureCacheDirs(): Promise<void> {
  for (const dir of [thumbnailsDir(), ftpPreviewDir()]) {
    try {
      if (!(await FileManager.exists(dir))) {
        await FileManager.createDirectory(dir, true)
      }
    } catch {
      // 缓存目录创建失败时由使用方重试
    }
  }
}

export function settingsPath(name: string): string | null {
  return iCloudPath(name)
}

export async function ensureDataDir(): Promise<void> {
  try {
    const dir = dataDir()
    if (!(await FileManager.exists(dir))) {
      await FileManager.createDirectory(dir, true)
    }
  } catch {
    // 目录创建失败时由各写入方自行重试/报错
  }
}

export async function ensureSettingsDir(): Promise<void> {
  const dir = settingsDir()
  if (!dir) return
  try {
    if (!(await FileManager.exists(dir))) {
      await FileManager.createDirectory(dir, true)
    }
  } catch {
    // iCloud 不可写时，设置保持内存态
  }
}
