import { FileEntry } from "../types"

function joinPath(dir: string, nameOrPath: string): string {
  if (nameOrPath.startsWith("/")) return nameOrPath
  const base = dir.endsWith("/") ? dir.slice(0, -1) : dir
  return base + "/" + nameOrPath
}

/** 限制并发地映射数组，避免大目录里成百上千个 stat 同时打出去。 */
async function mapLimit<T, R>(
  items: T[],
  limit: number,
  task: (item: T) => Promise<R>
): Promise<R[]> {
  const results: R[] = new Array(items.length)
  let next = 0
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (true) {
      const index = next
      next += 1
      if (index >= items.length) return
      results[index] = await task(items[index])
    }
  })
  await Promise.all(workers)
  return results
}

export async function listDirectory(
  dir: string,
  showHidden = true
): Promise<FileEntry[]> {
  const raw = await FileManager.readDirectory(dir)
  const names = raw.filter(
    item =>
      item &&
      item !== "." &&
      item !== ".." &&
      (showHidden || !item.startsWith("."))
  )

  const stats = await mapLimit(names, 8, async item => {
    const path = joinPath(dir, item)
    const name = path.split("/").filter(Boolean).pop() ?? item
    try {
      const stat = await FileManager.stat(path)
      // 运行时返回的是 "NSFileTypeDirectory" / "NSFileTypeRegular"
      const type = String(stat.type ?? "").toLowerCase()
      return {
        name,
        path,
        isDirectory: type === "directory" || type.endsWith("directory"),
        size: stat.size,
        modifiedAt: stat.modificationDate,
      } as FileEntry
    } catch {
      return null
    }
  })

  const entries = stats.filter((entry): entry is FileEntry => entry !== null)
  entries.sort((a, b) => {
    if (a.isDirectory !== b.isDirectory) return a.isDirectory ? -1 : 1
    return a.name.localeCompare(b.name, "zh-Hans")
  })
  return entries
}

export function formatSize(bytes: number): string {
  if (!bytes || bytes < 0) return ""
  const units = ["B", "KB", "MB", "GB", "TB"]
  let value = bytes
  let i = 0
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024
    i++
  }
  const digits = i === 0 ? 0 : value >= 10 ? 0 : 1
  return value.toFixed(digits) + " " + units[i]
}

export function formatDate(timestamp: number): string {
  if (!timestamp) return ""
  const d = new Date(timestamp)
  const pad = (n: number) => (n < 10 ? "0" + n : String(n))
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`
}

const ICON_MAP: Record<string, string> = {
  jpg: "photo",
  jpeg: "photo",
  png: "photo",
  gif: "photo",
  heic: "photo",
  webp: "photo",
  svg: "photo",
  mp4: "film",
  mov: "film",
  m4v: "film",
  mkv: "film",
  mp3: "music.note",
  m4a: "music.note",
  wav: "music.note",
  flac: "music.note",
  zip: "doc.zipper",
  rar: "doc.zipper",
  "7z": "doc.zipper",
  tar: "doc.zipper",
  gz: "doc.zipper",
  pdf: "doc.richtext",
  txt: "doc.text",
  md: "doc.text",
  json: "curlybraces",
  js: "chevron.left.forwardslash.chevron.right",
  ts: "chevron.left.forwardslash.chevron.right",
  tsx: "chevron.left.forwardslash.chevron.right",
  swift: "chevron.left.forwardslash.chevron.right",
  html: "chevron.left.forwardslash.chevron.right",
  css: "chevron.left.forwardslash.chevron.right",
  doc: "doc.text",
  docx: "doc.text",
  xls: "tablecells",
  xlsx: "tablecells",
  ppt: "rectangle.on.rectangle",
  pptx: "rectangle.on.rectangle",
}

export function iconForEntry(entry: FileEntry): string {
  if (entry.isDirectory) return "folder.fill"
  const ext = entry.name.includes(".")
    ? entry.name.split(".").pop()!.toLowerCase()
    : ""
  return ICON_MAP[ext] ?? "doc"
}
