import { dataDir, ensureDataDir } from "./paths"

const MAX_LOG_BYTES = 512 * 1024

let enabled = false
let queue: Promise<void> = Promise.resolve()

function flagFile(): string {
  return dataDir() + "/debug.enabled"
}

function logFile(): string {
  return dataDir() + "/debug.log"
}

/** 启动时读取一次调试开关。之后由设置页或外部修改，需重启脚本才会重新读取。 */
export async function initDebug(): Promise<boolean> {
  try {
    enabled = await FileManager.exists(flagFile())
  } catch {
    enabled = false
  }
  return enabled
}

export function isDebugEnabled(): boolean {
  return enabled
}

/** 开关调试日志。开关本身就是数据目录里的一个文件，外部也能创建/删除。 */
export async function setDebugLogEnabled(value: boolean): Promise<void> {
  enabled = value
  const flag = flagFile()
  try {
    if (value) {
      await ensureDataDir()
      await FileManager.writeAsString(flag, new Date().toISOString())
    } else if (await FileManager.exists(flag)) {
      await FileManager.remove(flag)
    }
  } catch {
    // 开关写入失败时保持内存状态，不影响脚本运行
  }
}

/** 写一行调试日志。未开启时是空操作。 */
export function debugLog(tag: string, message: string): void {
  if (!enabled) return
  const line = `${new Date().toISOString()} [${tag}] ${message}\n`
  queue = queue
    .then(async () => {
      try {
        await ensureDataDir()
        await FileManager.appendText(logFile(), line)
        const stat = await FileManager.stat(logFile())
        if (stat.size > MAX_LOG_BYTES) {
          const text = await FileManager.readAsString(logFile())
          await FileManager.writeAsString(logFile(), text.slice(-Math.floor(MAX_LOG_BYTES / 2)))
        }
      } catch {
        // 日志失败不影响主流程
      }
    })
    .catch(() => {})
}

export async function readDebugLog(): Promise<string> {
  await queue.catch(() => {})
  try {
    if (!(await FileManager.exists(logFile()))) return ""
    return await FileManager.readAsString(logFile())
  } catch {
    return ""
  }
}

export async function clearDebugLog(): Promise<void> {
  await queue.catch(() => {})
  try {
    if (await FileManager.exists(logFile())) {
      await FileManager.remove(logFile())
    }
  } catch {
    // 忽略
  }
}

export async function debugLogExists(): Promise<boolean> {
  try {
    return await FileManager.exists(logFile())
  } catch {
    return false
  }
}
