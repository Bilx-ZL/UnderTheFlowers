import type { AbortSignal } from "scripting"
import type { FileEntry, FTPConnection } from "../types"
import {
  UploadCancelledError,
  createFtpDirectory,
  deleteRemoteFile,
  listFtp,
  normalizeRemotePath,
  uploadFileToFtp,
} from "./ftp"

/** 与下载保持一致的三种处理方式。 */
export type UploadConflictAction = "overwrite" | "keepBoth" | "skip"

export type UploadConflictInfo = {
  name: string
  /** 第几个冲突（1 起） */
  index: number
  /** 冲突总数 */
  total: number
}

export type UploadFileStats = {
  loaded: number
  total: number
  bytesPerSecond?: number
}

export type UploadToDirOptions = {
  connection: FTPConnection
  password?: string
  /** 要上传的本地文件/文件夹 */
  entries: FileEntry[]
  /** 远端目标目录（FTP 页当前停留的位置） */
  targetDir: string
  signal?: AbortSignal
  /** 展开完成，拿到待上传文件总数 */
  onPlan?: (total: number) => void
  /** 已处理完的项目数（含跳过的） */
  onProgress?: (done: number, total: number) => void
  /** 当前文件的字节级进度（每 2 秒一个采样） */
  onFileProgress?: (fraction: number, stats?: UploadFileStats) => void
  /** 远端已有同名文件时询问；不传则直接覆盖。 */
  onConflict?: (info: UploadConflictInfo) => Promise<UploadConflictAction>
}

export type UploadResult = {
  uploaded: number
  skipped: number
  total: number
  /** 触碰到的远端目录（含中间层），用于刷新浏览页 */
  dirs: string[]
  failed: { name: string; message: string }[]
}

function joinPath(dir: string, name: string): string {
  const base = normalizeRemotePath(dir)
  return base === "/" ? "/" + name : base + "/" + name
}

function splitExtension(name: string): { base: string; ext: string } {
  const index = name.lastIndexOf(".")
  if (index <= 0) return { base: name, ext: "" }
  return { base: name.slice(0, index), ext: name.slice(index) }
}

function isDirectoryType(type: unknown): boolean {
  return String(type ?? "").toLowerCase().endsWith("directory")
}

type PlanItem = {
  localPath: string
  remoteDir: string
  name: string
  size: number
}

/** 递归展开本地项目，记下所有需要存在的远端目录。 */
async function collectLocal(
  localPath: string,
  remoteDir: string,
  name: string,
  items: PlanItem[],
  dirs: Set<string>
): Promise<void> {
  const stat = await FileManager.stat(localPath)
  if (isDirectoryType(stat.type)) {
    const dir = joinPath(remoteDir, name)
    dirs.add(dir)
    const children = await FileManager.readDirectory(localPath)
    for (const child of children) {
      await collectLocal(joinPath(localPath, child), dir, child, items, dirs)
    }
    return
  }
  items.push({ localPath, remoteDir, name, size: stat.size ?? 0 })
}

/** 远端某目录里已有的文件名集合；目录不存在返回空集。 */
async function remoteNames(
  connection: FTPConnection,
  dir: string,
  password?: string
): Promise<Set<string>> {
  try {
    const list = await listFtp(connection, dir, true, password)
    return new Set(list.map(entry => entry.name))
  } catch {
    return new Set()
  }
}

/** 目录是否存在（能列出来就算存在）。 */
async function remoteDirExists(
  connection: FTPConnection,
  dir: string,
  password?: string
): Promise<boolean> {
  try {
    await listFtp(connection, dir, true, password)
    return true
  } catch {
    return false
  }
}

/**
 * 把本地文件/文件夹上传到远端目录。
 * 目录会自动创建（已有的直接合并），同名文件逐个询问。
 */
export async function uploadEntriesToDir(
  options: UploadToDirOptions
): Promise<UploadResult> {
  const { connection, password, signal } = options
  const targetDir = normalizeRemotePath(options.targetDir)

  const items: PlanItem[] = []
  const dirs = new Set<string>([targetDir])
  for (const entry of options.entries) {
    await collectLocal(entry.path, targetDir, entry.name, items, dirs)
  }
  options.onPlan?.(items.length)

  const result: UploadResult = {
    uploaded: 0,
    skipped: 0,
    total: items.length,
    dirs: [...dirs],
    failed: [],
  }
  if (items.length === 0) return result

  // 1) 先补齐远端目录（父目录在前；目标目录本身也要检查）
  const ordered = [...dirs].sort((a, b) => a.split("/").length - b.split("/").length)
  for (const dir of ordered) {
    if (await remoteDirExists(connection, dir, password)) continue
    try {
      await createFtpDirectory(connection, dir, password)
      result.dirs.push(dir)
    } catch (error) {
      // 建不出来就让后续上传报错，别在这里吞掉整批
      result.failed.push({
        name: dir,
        message: error instanceof Error ? error.message : String(error),
      })
    }
  }

  // 2) 预扫同名冲突
  const listingCache = new Map<string, Set<string>>()
  const namesIn = async (dir: string): Promise<Set<string>> => {
    const cached = listingCache.get(dir)
    if (cached) return cached
    const names = await remoteNames(connection, dir, password)
    listingCache.set(dir, names)
    return names
  }
  const conflicts = new Set<PlanItem>()
  for (const item of items) {
    if ((await namesIn(item.remoteDir)).has(item.name)) conflicts.add(item)
  }

  // 3) 逐个上传（冲突先问）
  let asked = 0
  let done = 0
  for (const item of items) {
    if (signal?.aborted) throw new UploadCancelledError()

    let name = item.name
    const isConflict = conflicts.has(item)
    if (isConflict) {
      asked += 1
      const action = options.onConflict
        ? await options.onConflict({
            name: item.name,
            index: asked,
            total: conflicts.size,
          })
        : "overwrite"

      if (action === "skip") {
        result.skipped += 1
        done += 1
        options.onProgress?.(done, result.total)
        continue
      }
      if (action === "keepBoth") {
        name = await uniqueRemoteName(item.name, await namesIn(item.remoteDir))
      } else {
        await deleteRemoteFile(
          connection,
          joinPath(item.remoteDir, item.name),
          password
        ).catch(() => {})
        ;(await namesIn(item.remoteDir)).delete(item.name)
      }
    }

    // 批内重名兜底：预扫只能看到服务器现有文件，同一批里后面的同名文件
    // 走到这里时前者已经写进缓存了，自动改成「 (1)」而不是默默覆盖。
    if (!isConflict) {
      const existing = await namesIn(item.remoteDir)
      if (existing.has(name)) {
        name = await uniqueRemoteName(name, existing)
      }
    }

    const remotePath = joinPath(item.remoteDir, name)
    try {
      await uploadFileToFtp(connection, item.localPath, remotePath, password, {
        signal,
        onProgress: (uploaded, total, speed) => {
          if (total > 0) {
            options.onFileProgress?.(Math.min(1, uploaded / total), {
              loaded: uploaded,
              total,
              bytesPerSecond: speed,
            })
          }
        },
      })
      ;(await namesIn(item.remoteDir)).add(name)
      result.uploaded += 1
    } catch (error) {
      if (error instanceof UploadCancelledError) throw error
      result.failed.push({
        name: item.name,
        message: error instanceof Error ? error.message : String(error),
      })
    }
    done += 1
    options.onProgress?.(done, result.total)
  }

  result.dirs = [...new Set(result.dirs)]
  return result
}

/** 目录名带「 (1)」的兜底名字。 */
async function uniqueRemoteName(name: string, existing: Set<string>): Promise<string> {
  const { base, ext } = splitExtension(name)
  for (let i = 1; i < 1000; i++) {
    const candidate = `${base} (${i})${ext}`
    if (!existing.has(candidate)) return candidate
  }
  return `${base}-${Date.now()}${ext}`
}

