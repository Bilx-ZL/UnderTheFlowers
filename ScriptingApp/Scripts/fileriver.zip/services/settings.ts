import { settingsPath } from "./paths"

export type ExitBehavior = "minimize" | "exit"

export type ThumbnailCacheLimit =
  | "off"
  | "100MB"
  | "500MB"
  | "1GB"
  | "unlimited"

export const THUMBNAIL_CACHE_LIMIT_OPTIONS: Array<{
  value: ThumbnailCacheLimit
  label: string
  bytes: number
}> = [
  { value: "off", label: "关闭", bytes: 0 },
  { value: "100MB", label: "100 MB", bytes: 100 * 1024 * 1024 },
  { value: "500MB", label: "500 MB", bytes: 500 * 1024 * 1024 },
  { value: "1GB", label: "1 GB", bytes: 1024 * 1024 * 1024 },
  { value: "unlimited", label: "无限制", bytes: Number.POSITIVE_INFINITY },
]

const DEFAULT_THUMBNAIL_CACHE_LIMIT: ThumbnailCacheLimit = "100MB"

export type FtpPreviewCacheLimit =
  | "immediate"
  | "7d"
  | "30d"
  | "unlimited"

export const FTP_PREVIEW_CACHE_LIMIT_OPTIONS: Array<{
  value: FtpPreviewCacheLimit
  label: string
}> = [
  { value: "immediate", label: "即时清理" },
  { value: "7d", label: "7 天" },
  { value: "30d", label: "30 天" },
  { value: "unlimited", label: "无限制" },
]

const DEFAULT_FTP_PREVIEW_CACHE_LIMIT: FtpPreviewCacheLimit = "immediate"

function isFtpPreviewCacheLimit(value: unknown): value is FtpPreviewCacheLimit {
  return FTP_PREVIEW_CACHE_LIMIT_OPTIONS.some(option => option.value === value)
}

function isThumbnailCacheLimit(value: unknown): value is ThumbnailCacheLimit {
  return THUMBNAIL_CACHE_LIMIT_OPTIONS.some(option => option.value === value)
}

export type AppSettings = {
  exitBehavior: ExitBehavior
  showHiddenFiles: boolean
  /** 任务中心有进行中的任务时不锁屏 */
  keepAwakeDuringTasks: boolean
  /** 列表中显示图片/视频缩略图 */
  thumbnailsEnabled: boolean
  /** 缩略图磁盘缓存上限；off 同时关闭缩略图显示 */
  thumbnailCacheLimit: ThumbnailCacheLimit
  /** FTP 快速预览缓存上限；immediate 关闭预览后立即删除 */
  ftpPreviewCacheLimit: FtpPreviewCacheLimit
  /** 详情页对 FTP 文件夹递归统计大小 */
  recursiveFtpFolderStats: boolean
  /** 首次运行已看过「关于」页 */
  aboutSeen: boolean
}

const DEFAULTS: AppSettings = {
  exitBehavior: "minimize",
  showHiddenFiles: true,
  keepAwakeDuringTasks: true,
  thumbnailsEnabled: true,
  thumbnailCacheLimit: DEFAULT_THUMBNAIL_CACHE_LIMIT,
  ftpPreviewCacheLimit: DEFAULT_FTP_PREVIEW_CACHE_LIMIT,
  recursiveFtpFolderStats: false,
  aboutSeen: false,
}

// 内存缓存：切换后立即生效，不依赖磁盘写入完成
let cached: AppSettings | null = null

// 串行化写入：避免快速切换时旧写入覆盖新写入
let writeQueue: Promise<void> = Promise.resolve()

function settingsFile(): string | null {
  return settingsPath("settings.json")
}

function enqueueWrite(snapshot: AppSettings): Promise<void> {
  const file = settingsFile()
  if (!file) return Promise.resolve()
  writeQueue = writeQueue
    .then(async () => {
      const dir = file.slice(0, file.lastIndexOf("/"))
      if (!(await FileManager.exists(dir))) {
        await FileManager.createDirectory(dir, true)
      }
      await FileManager.writeAsString(file, JSON.stringify(snapshot, null, 2))
    })
    .catch(() => {})
  return writeQueue
}

export async function loadSettings(): Promise<AppSettings> {
  if (cached) return { ...cached }
  const file = settingsFile()
  try {
    if (file && (await FileManager.exists(file))) {
      const parsed = JSON.parse(await FileManager.readAsString(file))
      const rawThumbnailLimit: ThumbnailCacheLimit = isThumbnailCacheLimit(
        parsed?.thumbnailCacheLimit
      )
        ? parsed.thumbnailCacheLimit
        : DEFAULT_THUMBNAIL_CACHE_LIMIT
      // 兼容旧版开关：关掉显示缩略图等价于缓存上限“关闭”
      const thumbnailsEnabled =
        parsed?.thumbnailsEnabled !== false && rawThumbnailLimit !== "off"
      cached = {
        exitBehavior: parsed?.exitBehavior === "exit" ? "exit" : "minimize",
        // 旧版本没有这个字段时默认显示 . 开头文件和目录
        showHiddenFiles: parsed?.showHiddenFiles !== false,
        // 旧版本没有这个字段时默认开启（旧键 keepAwakeDuringTransfer 兼容读取）
        keepAwakeDuringTasks:
          parsed?.keepAwakeDuringTasks !== false &&
          parsed?.keepAwakeDuringTransfer !== false,
        thumbnailsEnabled,
        thumbnailCacheLimit: thumbnailsEnabled ? rawThumbnailLimit : "off",
        ftpPreviewCacheLimit: isFtpPreviewCacheLimit(parsed?.ftpPreviewCacheLimit)
          ? parsed.ftpPreviewCacheLimit
          : DEFAULT_FTP_PREVIEW_CACHE_LIMIT,
        // 旧版本没有这个字段时默认关闭
        recursiveFtpFolderStats: parsed?.recursiveFtpFolderStats === true,
        aboutSeen: parsed?.aboutSeen === true,
      }
    } else {
      cached = { ...DEFAULTS }
    }
  } catch {
    cached = { ...DEFAULTS }
  }
  return { ...cached }
}

/** 同步读取当前缓存值；启动时先调用 loadSettings()。 */
export function getExitBehavior(): ExitBehavior {
  return cached?.exitBehavior ?? DEFAULTS.exitBehavior
}

export function getShowHiddenFiles(): boolean {
  return cached?.showHiddenFiles ?? DEFAULTS.showHiddenFiles
}

export function getKeepAwakeDuringTasks(): boolean {
  return cached?.keepAwakeDuringTasks ?? DEFAULTS.keepAwakeDuringTasks
}

export function getThumbnailsEnabled(): boolean {
  return cached?.thumbnailsEnabled ?? DEFAULTS.thumbnailsEnabled
}

export function getThumbnailCacheLimit(): ThumbnailCacheLimit {
  return cached?.thumbnailCacheLimit ?? DEFAULTS.thumbnailCacheLimit
}

export function getRecursiveFtpFolderStats(): boolean {
  return cached?.recursiveFtpFolderStats ?? DEFAULTS.recursiveFtpFolderStats
}

export function getFtpPreviewCacheLimit(): FtpPreviewCacheLimit {
  return cached?.ftpPreviewCacheLimit ?? DEFAULTS.ftpPreviewCacheLimit
}

export function getAboutSeen(): boolean {
  return cached?.aboutSeen ?? DEFAULTS.aboutSeen
}

export function setAboutSeen(value: boolean): Promise<void> {
  cached = { ...(cached ?? DEFAULTS), aboutSeen: value }
  return enqueueWrite({ ...cached })
}

/** FTP 预览按天数保留；null 表示不是按天数策略。 */
export function getFtpPreviewCacheRetentionDays(): number | null {
  const limit = getFtpPreviewCacheLimit()
  return limit === "7d" ? 7 : limit === "30d" ? 30 : null
}

export function getThumbnailCacheLimitBytes(): number {
  const limit = getThumbnailCacheLimit()
  return (
    THUMBNAIL_CACHE_LIMIT_OPTIONS.find(option => option.value === limit)?.bytes ??
    THUMBNAIL_CACHE_LIMIT_OPTIONS[1].bytes
  )
}

type SettingsListener = () => void
const showHiddenListeners = new Set<SettingsListener>()
const thumbnailListeners = new Set<SettingsListener>

export function subscribeShowHidden(listener: SettingsListener): () => void {
  showHiddenListeners.add(listener)
  return () => {
    showHiddenListeners.delete(listener)
  }
}

export function subscribeThumbnails(listener: SettingsListener): () => void {
  thumbnailListeners.add(listener)
  return () => {
    thumbnailListeners.delete(listener)
  }
}

function notifyThumbnails(): void {
  thumbnailListeners.forEach(listener => {
    try {
      listener()
    } catch {
      // 忽略单个订阅者异常
    }
  })
}

export function setExitBehavior(behavior: ExitBehavior): Promise<void> {
  cached = { ...(cached ?? DEFAULTS), exitBehavior: behavior }
  return enqueueWrite({ ...cached })
}

export function setKeepAwakeDuringTasks(value: boolean): Promise<void> {
  cached = { ...(cached ?? DEFAULTS), keepAwakeDuringTasks: value }
  return enqueueWrite({ ...cached })
}

export function setShowHiddenFiles(value: boolean): Promise<void> {
  cached = { ...(cached ?? DEFAULTS), showHiddenFiles: value }
  showHiddenListeners.forEach(listener => {
    try {
      listener()
    } catch {
      // 忽略单个订阅者异常
    }
  })
  return enqueueWrite({ ...cached })
}

export function setThumbnailsEnabled(value: boolean): Promise<void> {
  const current = cached ?? DEFAULTS
  const limit =
    value && current.thumbnailCacheLimit === "off"
      ? DEFAULT_THUMBNAIL_CACHE_LIMIT
      : current.thumbnailCacheLimit
  cached = {
    ...current,
    thumbnailsEnabled: value,
    thumbnailCacheLimit: value ? limit : "off",
  }
  notifyThumbnails()
  return enqueueWrite({ ...cached })
}

export function setThumbnailCacheLimit(value: ThumbnailCacheLimit): Promise<void> {
  cached = {
    ...(cached ?? DEFAULTS),
    thumbnailCacheLimit: value,
    thumbnailsEnabled: value !== "off",
  }
  notifyThumbnails()
  return enqueueWrite({ ...cached })
}

export function setFtpPreviewCacheLimit(
  value: FtpPreviewCacheLimit
): Promise<void> {
  cached = { ...(cached ?? DEFAULTS), ftpPreviewCacheLimit: value }
  return enqueueWrite({ ...cached })
}

export function setRecursiveFtpFolderStats(value: boolean): Promise<void> {
  cached = { ...(cached ?? DEFAULTS), recursiveFtpFolderStats: value }
  return enqueueWrite({ ...cached })
}
