import { Mount } from "../types"
import { ensureSettingsDir, iCloudPath } from "./paths"

function mountsFile(): string | null {
  return iCloudPath("mounts.json")
}

function normalize(raw: any): Mount | null {
  if (!raw || typeof raw !== "object" || typeof raw.id !== "string") return null
  return {
    id: raw.id,
    kind: raw.kind === "ftp" ? "ftp" : "local",
    name: typeof raw.name === "string" && raw.name ? raw.name : "未命名",
    bookmarkName: typeof raw.bookmarkName === "string" ? raw.bookmarkName : undefined,
    lastPath: typeof raw.lastPath === "string" ? raw.lastPath : undefined,
    createdAt: typeof raw.createdAt === "number" ? raw.createdAt : Date.now(),
  }
}

export async function loadMounts(): Promise<Mount[]> {
  try {
    const file = mountsFile()
    if (!file || !(await FileManager.exists(file))) return []
    const text = await FileManager.readAsString(file)
    const parsed = JSON.parse(text)
    if (!Array.isArray(parsed)) return []
    return parsed.map(normalize).filter((m): m is Mount => m !== null)
  } catch {
    return []
  }
}

export async function saveMounts(mounts: Mount[]): Promise<void> {
  const file = mountsFile()
  if (!file) return
  await ensureSettingsDir()
  await FileManager.writeAsString(file, JSON.stringify(mounts, null, 2))
}

export function newId(): string {
  return Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8)
}

export function baseName(path: string): string {
  const parts = path.split("/").filter(Boolean)
  return parts.length > 0 ? parts[parts.length - 1] : "未命名"
}

/** 已解析的本地挂载路径；离线/未恢复时返回 null。 */
export function resolveMountPath(mount: Mount): string | null {
  if (mount.kind !== "local" || !mount.bookmarkName) return null
  try {
    const path = FileManager.bookmarkedPath(mount.bookmarkName)
    // 运行时书签不存在时返回的是 undefined（而非文档写的 null）
    return typeof path === "string" && path.length > 0 ? path : null
  } catch {
    return null
  }
}

export function displayPath(mount: Mount): string {
  const path = resolveMountPath(mount) ?? mount.lastPath
  if (!path) return "离线，需重新授权"
  try {
    if (FileManager.isiCloudEnabled && path.startsWith(FileManager.iCloudDocumentsDirectory)) {
      return "iCloud 云盘"
    }
  } catch {
    // iCloud 不可用时忽略
  }
  try {
    if (path.startsWith(FileManager.documentsDirectory)) return "我的 iPhone"
  } catch {
    // 忽略
  }
  return path
}
