import {
  Button,
  HStack,
  Navigation,
  ScrollView,
  Spacer,
  Text,
  VStack,
} from "scripting"

/**
 * 关于页。
 *
 * 两种打开方式：
 * 1. 设置 → 点「版本」这一行进来的（外面已有 NavigationStack，这里不再套一层）
 * 2. 首次运行的弹窗（调用方自己套 NavigationStack）
 *
 * 正文直接铺在页面上（不用分组卡片），底部「关闭」按钮栏固定在底部。
 */
export function AboutPage() {
  const dismiss = Navigation.useDismiss()

  return (
    <ScrollView
      navigationTitle="FTP文件流"
      navigationBarTitleDisplayMode="inline"
      safeAreaInset={{
        bottom: {
          spacing: 0,
          content: (
            <HStack frame={{ maxWidth: "infinity" }} padding={{ bottom: 24 }}>
              <Spacer />
              <Button
                action={() => dismiss()}
                buttonStyle="plain"
                padding={{ horizontal: 44, vertical: 12 }}
                glassEffect={{ glass: UIGlass.regular(), shape: "capsule" }}
              >
                <Text font="headline" foregroundStyle="label">
                  关闭
                </Text>
              </Button>
              <Spacer />
            </HStack>
          ),
        },
      }}
    >
      <VStack
        spacing={14}
        alignment="leading"
        frame={{ maxWidth: "infinity", alignment: "leading" }}
        padding={{ horizontal: 20, top: 12, bottom: 40 }}
      >
        <Text font="headline">有什么用</Text>
        <Text>一个用于在FTP服务器与手机互传文件的脚本。</Text>
        <Text>
          经常要手机电脑FTP互传，而商店一直没找到好看，好用，有性能的App，所以写了脚本自用。
        </Text>

        <Text font="headline" padding={{ top: 10 }}>
          特点
        </Text>
        <Text>
          简单高效，可直接从挂载目录和FTP在选定目录互传文件，可直接将外部文件拖动到+号按钮上传到FTP，或从FTP即时共享。
        </Text>

        <Text font="headline" padding={{ top: 10 }}>
          局限性
        </Text>
        <Text>Scripting暂不支持部分特性，无法从FTP拖出到应用外；</Text>
        <Text>不支持多线程。</Text>

        <Text padding={{ top: 10 }}>密码保存在系统钥匙串中，不参与代码。</Text>
        <Button
          title="Telegram：@Qing_UL"
          systemImage="paperplane"
          action={() => {
            Safari.openURL("https://t.me/Qing_UL").catch(() => {})
          }}
        />
      </VStack>
    </ScrollView>
  )
}
